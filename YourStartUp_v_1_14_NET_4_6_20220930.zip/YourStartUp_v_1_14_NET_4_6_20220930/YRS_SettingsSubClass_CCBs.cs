﻿/* YourStartUp SettingsSubClass
 * 
 * Pur:         ccb-definition and design
 * Toc:         2022 (september <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      kammel@posteo.de
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace YourStartUp
{
    class YRS_SettingsSubClass_CCBs
    {
        SettingsTexts text = new SettingsTexts();

        public YRS_SettingsSubClass_CCBs()
        {
            
        }


        public UIE_CheckboxCanvasButton CCB_backColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_backColor";
            ccb.uie_textblock.Text = text.ccb_background_content().ToString();            
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbGeneral_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;

            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_foreColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_foreColor";
            ccb.uie_textblock.Text = text.ccb_font_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbGeneral_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;

            return ccb;
        }


        public UIE_CheckboxCanvasButton CCB_btnBackColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_btnBackColor";
            ccb.uie_textblock.Text = text.ccb_btnBackColor_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbButtons_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;

            return ccb;
        }


        public UIE_CheckboxCanvasButton CCB_btnForeColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_btnForeColor";
            ccb.uie_textblock.Text = text.ccb_btnForeColor_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbButtons_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;

            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_deleteStateBackColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_deleteStateBackColor";
            ccb.uie_textblock.Text = text.ccb_delete_state_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbDelete_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;


            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_deleteStateFontColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_deleteStateFontColor";
            ccb.uie_textblock.Text = text.ccb_delete_font_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbDelete_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;

            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_CanvasColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_CanvasColor";
            ccb.uie_textblock.Text = text.ccb_canvas_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbCanvas_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;


            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_CanvasMenuColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_CanvasMenuColor";
            ccb.uie_textblock.Text = text.ccb_canvasMenu_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbCanvasMenu_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;

            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_guiMinimizerColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_guiMinimizerColor";
            ccb.uie_textblock.Text = text.ccb_gui_minimizer_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbHideGui_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;


            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_highlightColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_highlightColor";
            ccb.uie_textblock.Text = text.ccb_highlight_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbHighlight_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;

            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_renameStateBackColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_renameStateBackColor";
            ccb.uie_textblock.Text = text.ccb_rename_state_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbRename_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;


            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_renameStateFontColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_renameStateFontColor";
            ccb.uie_textblock.Text = text.ccb_rename_font_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbDelete_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;

            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_resetStateBackColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_resetStateBackColor";
            ccb.uie_textblock.Text = text.ccb_reset_state_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbDelete_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;


            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_resetStateFontColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_resetStateFontColor";
            ccb.uie_textblock.Text = text.ccb_reset_font_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbDelete_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;

            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_sliderBackColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_sliderBackColor";
            ccb.uie_textblock.Text = text.ccb_sliders_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbDelete_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;

            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_textBoxBackColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_textBoxBackColor";
            ccb.uie_textblock.Text = text.ccb_textbox_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbDelete_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;


            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_textBoxFontColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "CCB_textBoxFontColor";
            ccb.uie_textblock.Text = text.ccb_textbox_font_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbDelete_tooltip();
            ccb.uie_ckbcnvbtn_button_border.Height = 20;
            ccb.uie_ckbcnvbtn_button_border.Width = 120;

            return ccb;
        }
    }
}
