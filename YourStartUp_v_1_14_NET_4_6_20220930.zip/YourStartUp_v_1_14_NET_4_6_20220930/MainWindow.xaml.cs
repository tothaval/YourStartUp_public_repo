﻿/* YourStartUp buttonmap tool  
 * 
 * Pur:         main window, collapsable main menu, collapsable button area, user can bind files and urls to buttons,
 *              user can access all main functionalities
 * Toc:         2022 (may <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      kammel@posteo.de
 */
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

/* TO DO s
 * 
 * - replace message box warnings with a custom solution 
 * goal: being able to place the message box alternative over the parent window, to avoid user confusion
 * 
 * - replace mouse over tooltips with custom solution
 * 
 * - update info text class where due
 * 
 * - additional languages support including language selection via settings window
 * 
 * - function to show folder icons, be it via a self created icon or extraction of os folder icon file
 * - function to check whether a folder or a file is selected or bound to configList 
 * 
 * - subclassing of selection button code and code adaption where due
 * 
 * - further development of scetchboard functionality
 * -> audio file player module, video file player module following image element design concepts
 * -> more basic geometry, more textboxes for mathematical values
 * -> integration of brush options for scetch line brush
 * -> integration of stroke thickness options for scetch line brush
 * -> integration of additional brush type radiantBrush
 * -> integration of grouping options for canvas children objects
 * -> integration of rectangle selection for canvas children objects
 * -> integration of group drag move and group deletion
 * -> help window / manual for scetchboard (F1) 
 * 
 * - further development of notes functionality
 * - notes to email function
 * - notes to pdf function
 * - notes to txt function
 * - save and load function for notes
 */



namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // classes
        #region classes
        ConfigData config;
        MainWindowTexts texts = new MainWindowTexts();
        #endregion classes


        // globals _public
        #region globals _public
        public int showCount = 0;

        // globals _public        
        public List<Button> btnSetList = new List<Button>();
        public List<Button> btnMenuList = new List<Button>();


        public List<Border> brdSetList = new List<Border>();
        public List<Border> brdMenuList = new List<Border>();
        #endregion globals _public


        // globals _private
        #region globals _private

        private ImageBrush image = new ImageBrush();

        private int refresh = 0; // counter (_pulse)

        private List<TextBox> txtBoxList = new List<TextBox>();
        private List<string> setList = new List<string>();
        private List<string> configList = new List<string>();
        private List<Button> btnDrvs = new List<Button>();
        private List<StackPanel> spList = new List<StackPanel>();

        private List<System.Windows.Controls.Image> imageUICtrlList = new List<System.Windows.Controls.Image>();

        private readonly System.Windows.Threading.DispatcherTimer _pulse = new System.Windows.Threading.DispatcherTimer();

        private string configuration = "+;path";

        private int _height = 0;
        private int _width = 0;
        #endregion globals _private


        // constructors
        #region constructors
        public MainWindow()
        {
            InitializeComponent();

            _pulse.Interval = TimeSpan.FromSeconds(1);
            _pulse.Tick += _pulse_Tick;
        }
        #endregion constructors


        // time methods
        #region time methods
        private void _pulse_Tick(object sender, EventArgs e)
        {
            refresh++;
            if (refresh == 2)
            {
                for (int i = 0; i < btnDrvs.Count; i++)
                {
                    wrpDrives.Children.Clear();
                    btnDrvs.Clear();
                }

                setupDrives();

                refresh = 0;

                config.newDriveInfo();
            }

            GC.Collect(0);
        }
        #endregion time methods


        // methods _public
        #region methods public
        public void propertyUpdate()
        {
            propertyUpdate_deleteStyle();
            propertyUpdate_guiMinimizerStyle();
            propertyUpdate_menuStyle();
            propertyUpdate_normalStyle();
            propertyUpdate_renameStyle();
            propertyUpdate_resetStyle();

            config.saveConfig(btnSetList, setList, configList);
        }
        public void loadUIConfig()
        {
            propertyUpdate();

            // load data from save.settings
            config.loadConfig();

            // check settings for visibility of drive starter, notes, scetchboard, timer
            loadChxSettings();

            // main window settings
            modulateMainWindow();

            // button map image            
            backgroundImage(config.imageFilePath);

            // menu buttons list assignement and tooltips
            setupMenu();

            // use settings to define buttons
            modulateButtons();

            // use settings to set hide states
            hideStatesOnLoad();
        }
        #endregion methods public


        // methods _private A-L
        #region methods _private A-L

        // image handling
        private void backgroundImage(string imageFilePath)
        {
            try
            {
                if (config.imageFilePath != "" || config.imageFilePath != "-")
                {
                    image.ImageSource = new BitmapImage(new Uri(imageFilePath));
                    image.Stretch = Stretch.UniformToFill;

                    border.Background = image;
                }
                else if (config.imageFilePath == "" || config.imageFilePath == "-")
                {
                    image.ImageSource = new BitmapImage();

                    border.Background = image;

                    border.Background = config.backColor;

                }
            }
            catch
            {
                border.Background = config.backColor;
            }
        }

        // delete state logic
        #region delete state
        private void btnstate_delete()
        {
            propertyUpdate();

            Style normal_style = this.FindResource("buttonStyle") as Style;
            Style delete_style = this.FindResource("deleteStyle") as Style;

            if (config.deleteButtonState == true)
            {
                btnstate_delete_true(normal_style);
            }
            else if (config.deleteButtonState == false)
            {
                btnstate_delete_false(delete_style);
            }
        }
        private void btnstate_delete_false(Style _style)
        {
            config.deleteButtonState = true;

            btnDelete.Style = _style;

            brdBtnDelete.Background = config.deleteState;
            btnDelete.Foreground = config.deleteStateFont;

            for (int i = 0; i < btnSetList.Count; i++)
            {
                Border brdBtnSet;
                Button btnSet;
                TextBox tbSet;

                brdBtnSet = brdSetList[i];
                btnSet = btnSetList[i];
                tbSet = txtBoxList[i];

                btnSet.Style = _style;

                brdBtnSet.Background = config.deleteState;
                btnSet.Foreground = config.deleteStateFont;
                tbSet.Foreground = config.deleteStateFont;
            }
        }
        private void btnstate_delete_true(Style _style)
        {
            config.deleteButtonState = false;

            btnDelete.Style = _style;

            brdBtnDelete.Background = config.btnBackColor;
            btnDelete.Foreground = config.btnForeColor;

            for (int i = 0; i < btnSetList.Count; i++)
            {
                Border brdBtnSet;
                Button btnSet;
                TextBox tbSet;

                brdBtnSet = brdSetList[i];
                btnSet = btnSetList[i];
                tbSet = txtBoxList[i];

                btnSet.Style = _style;

                brdBtnSet.Background = config.btnBackColor;
                btnSet.Foreground = config.btnForeColor;
                tbSet.Foreground = config.btnForeColor;
            }
        }
        #endregion delete state

        // rename state logic
        #region rename state
        private void btnstate_rename()
        {
            propertyUpdate();

            Style normal_style = this.FindResource("buttonStyle") as Style;
            Style rename_style = this.FindResource("renameStyle") as Style;

            if (config.renameButtonState == false)
            {
                btnstate_rename_false(rename_style);
            }
            else if (config.renameButtonState == true)
            {
                btnstate_rename_true(normal_style);
            }
        }
        private void btnstate_rename_false(Style _style)
        {
            config.renameButtonState = true;

            btnRename.Style = _style;

            brdBtnRename.Background = config.renameState;
            btnRename.Foreground = config.renameStateFont;

            for (int i = 0; i < btnSetList.Count; i++)
            {
                Border brdBtnSet;
                Button btnSet;
                StackPanel sp;
                TextBox txtBtnContent;

                brdBtnSet = brdSetList[i];
                btnSet = btnSetList[i];
                sp = spList[i];
                txtBtnContent = txtBoxList[i];

                txtBtnContent.Text = txtBoxList[i].Text;

                btnSet.Style = _style;

                brdBtnSet.Background = config.renameState;
                btnSet.Foreground = config.renameStateFont;
                //btnSet.Height = 0;
                //btnSet.Content = configList[i];

                //txtBtnContent.Visibility = Visibility.Visible;
                //txtBtnContent.Height = config.btnHeight;
                txtBtnContent.Background = new SolidColorBrush(Colors.Transparent);
                txtBtnContent.Foreground = config.renameStateFont;
                txtBtnContent.IsEnabled = true;
                txtBtnContent.IsReadOnly = false;
                //txtBtnContent.Opacity = 50;
                //txtBtnContent.Text = btnSet.Content.ToString();
                //txtBtnContent.HorizontalContentAlignment = HorizontalAlignment.Center;
                //txtBtnContent.VerticalContentAlignment = VerticalAlignment.Center;

                configList[i] = txtBtnContent.Text;

                txtBtnContent.TextChanged += TxtBtnContent_TextChanged;
            }
        }
        private void btnstate_rename_true(Style _style)
        {
            config.renameButtonState = false;

            btnRename.Style = _style;

            brdBtnRename.Background = config.btnBackColor;
            btnRename.Foreground = config.btnForeColor;

            for (int i = 0; i < btnSetList.Count; i++)
            {
                Border brdBtnSet;
                Button btnSet;

                TextBox txtBtnContent;

                brdBtnSet = brdSetList[i];
                btnSet = btnSetList[i];

                txtBtnContent = txtBoxList[i];

                txtBtnContent.Text = txtBoxList[i].Text;
                //btnSet.Content = configList[i];
                btnSet.Style = _style;

                brdBtnSet.Background = config.btnBackColor;
                btnSet.Foreground = config.btnForeColor;
                //btnSet.Height = config.btnHeight;
                if (configList[i] != "+")
                {
                    btnSet.ToolTip = setList[i];
                }
                if (configList[i] != "")
                {
                    btnSet.ToolTip = setList[i];
                }
                if (configList[i] == "+")
                {
                    btnSet.ToolTip = texts.unset_tooltip();
                }
                if (configList[i] == "")
                {
                    btnSet.ToolTip = texts.empty_tooltip();
                }

                txtBtnContent = txtBoxList[i];
                txtBtnContent.IsEnabled = false;
                txtBtnContent.IsReadOnly = true;
                //txtBtnContent.Visibility = Visibility.Hidden;
                //txtBtnContent.Height = 0;
                configList[i] = txtBtnContent.Text;
            }
        }
        #endregion rename state

        // reset state logic
        #region reset state
        private void btnstate_reset()
        {
            propertyUpdate();

            Style normal_style = this.FindResource("buttonStyle") as Style;
            Style reset_style = this.FindResource("resetStyle") as Style;

            if (config.resetButtonState == false)
            {
                btnstate_reset_false(reset_style);
            }
            else if (config.resetButtonState == true)
            {
                btnstate_reset_true(normal_style);
            }
        }
        private void btnstate_reset_false(Style _style)
        {
            config.resetButtonState = true;

            btnReset.Style = _style;

            brdBtnReset.Background = config.resetState;
            btnReset.Foreground = config.resetStateFont;

            for (int i = 0; i < btnSetList.Count; i++)
            {
                Border brdBtnSet;
                Button btnSet;

                brdBtnSet = brdSetList[i];
                btnSet = btnSetList[i];

                btnSet.Style = _style;

                brdBtnSet.Background = config.resetState;
                btnSet.Foreground = config.resetStateFont;

                TextBox txtBtnContent = txtBoxList[i];

                if (btnSet.Content.ToString().StartsWith("http") || btnSet.Content.ToString().StartsWith("www"))
                {
                    brdBtnSet = brdSetList[i];
                    btnSet = btnSetList[i];

                    btnSet.Style = _style;

                    brdBtnSet.Background = config.resetState;
                    btnSet.Foreground = config.resetStateFont;
                    //btnSet.Height = 0;

                    //txtBtnContent.Visibility = Visibility.Visible;
                    //txtBtnContent.Height = config.btnHeight;
                    txtBtnContent.Foreground = config.resetStateFont;
                    //txtBtnContent.Opacity = 50;
                    txtBtnContent.Text = btnSet.Content.ToString();
                    txtBtnContent.HorizontalContentAlignment = HorizontalAlignment.Center;
                    txtBtnContent.VerticalContentAlignment = VerticalAlignment.Center;
                    configList[i] = txtBtnContent.Text;

                    txtBtnContent.TextChanged += TxtBtnContent_TextChanged;
                }
            }
        }
        private void btnstate_reset_true(Style _style)
        {
            config.resetButtonState = false;

            btnReset.Style = _style;

            brdBtnReset.Background = config.btnBackColor;
            btnReset.Foreground = config.btnForeColor;

            for (int i = 0; i < btnSetList.Count; i++)
            {
                Border brdBtnSet;
                Button btnSet; // = new Button();

                brdBtnSet = brdSetList[i];
                btnSet = btnSetList[i];

                //btnSet.Content = configList[i];

                btnSet.Style = _style;

                brdBtnSet.Background = config.btnBackColor;
                btnSet.Foreground = config.btnForeColor;
                //btnSet.Height = config.btnHeight;

                TextBox txtBtnContent; // = new TextBox();
                txtBtnContent = txtBoxList[i];
                //txtBtnContent.Visibility = Visibility.Hidden;
                //txtBtnContent.Height = 0;
            }
        }
        #endregion reset state

        // click state processing
        #region click state processing
        private void delete_click(int counter_)
        {
            brdSetList.RemoveAt(counter_);
            btnSetList.RemoveAt(counter_);
            imageUICtrlList.RemoveAt(counter_);
            txtBoxList.RemoveAt(counter_);
            wrpButtonMap.Children.RemoveAt(counter_);
            setList.RemoveAt(counter_);
        }

        private void normal_click(object sender_, Button btn_, string filepath_, int counter_)
        {
            if (configList[btnSetList.IndexOf(btn_)] == "+")
            {
                filepath_ = setApp(btn_, false);
                setList[counter_] = filepath_;
                txtBoxList[counter_].Text = filepath_;
            }
            else if (configList[btnSetList.IndexOf(btn_)] == "")
            {
                if (setList[counter_] != "path")
                {
                    setList[counter_] = "empty";
                    txtBoxList[counter_].Text = "";
                    btn_.ToolTip = texts.empty_tooltip();
                }
            }
            else if (configList[btnSetList.IndexOf(btn_)] != "+"
                && configList[btnSetList.IndexOf(btn_)] != "")
            {
                filepath_ = setList[counter_].ToString();

                startUp(filepath_);
            }
        }

        private void rename_click(object sender_, RoutedEventArgs e_)
        {
            TextBox txtBtnContent = sender_ as TextBox;

            System.Windows.Controls.Image imageUICtrl;

            int counter = txtBoxList.IndexOf(txtBtnContent);

            imageUICtrl = imageUICtrlList[counter];

            txtBtnContent = txtBoxList[counter];

            txtBtnContent.Text = txtBoxList[counter].Text;

            configList[counter] = txtBtnContent.Text;

            txtBtnContent.TextChanged += TxtBtnContent_TextChanged;
        }

        private void reset_click(Button btnSet, TextBox txtBtnContent, int counter, string filepath)
        {
            if (setList[counter].StartsWith("http:\\") || setList[counter].StartsWith("www.") || setList[counter].StartsWith("https:\\"))
            {
                Border brdBtnSet = brdSetList[counter];
                brdBtnSet.Background = config.resetState;

                btnSet = btnSetList[counter];
                btnSet.Foreground = config.resetStateFont;
                btnSet.BorderBrush = config.resetStateFont;
                btnSet.BorderThickness = new Thickness(1);
                //btnSet.Height = 0;

                txtBtnContent.Visibility = Visibility.Visible;
                //txtBtnContent.Height = config.btnHeight;
                txtBtnContent.Background = new SolidColorBrush(Colors.Transparent);
                txtBtnContent.Foreground = config.resetStateFont;
                //txtBtnContent.Opacity = 50;
                //txtBtnContent.Text = btnSet.Content.ToString();
                txtBtnContent.Text = txtBoxList[counter].Text;
                txtBtnContent.HorizontalContentAlignment = HorizontalAlignment.Center;
                txtBtnContent.VerticalContentAlignment = VerticalAlignment.Center;
                txtBtnContent.BorderBrush = config.resetStateFont;
                txtBtnContent.BorderThickness = new Thickness(1);
                configList[counter] = txtBtnContent.Text;

                txtBtnContent.TextChanged += TxtBtnContent_TextChanged;
            }
            else
            {
                filepath = setApp(btnSet, false);
                setList[counter] = filepath;

            }
        }
        #endregion click state processing

        // menu button configuration
        #region button configuration
        private void button_Add()
        {
            btnAdd.Content = texts.btnAdd_content();
            btnAdd.ToolTip = texts.btnAdd_toolTip();
            btnAdd.Background = new SolidColorBrush(Colors.Transparent);
            btnAdd.Foreground = config.btnForeColor;

            brdBtnAdd.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnAdd.BorderThickness = new Thickness(1);
            brdBtnAdd.BorderBrush = config.btnForeColor;
            brdBtnAdd.Background = config.btnBackColor;
        }
        private void button_Delete()
        {
            btnDelete.Content = texts.btnDelete_content();
            btnDelete.ToolTip = texts.btnDelete_toolTip();

            btnDelete.Background = new SolidColorBrush(Colors.Transparent);
            btnDelete.Foreground = config.btnForeColor;

            brdBtnDelete.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnDelete.BorderThickness = new Thickness(1);
            brdBtnDelete.BorderBrush = config.btnForeColor;
            brdBtnDelete.Background = config.btnBackColor;
        }
        private void button_Info()
        {
            btnInfo.Content = texts.btnInfo_content();
            btnInfo.ToolTip = texts.btnInfo_toolTip();

            btnInfo.Background = new SolidColorBrush(Colors.Transparent);
            btnInfo.Foreground = config.btnForeColor;

            brdBtnInfo.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnInfo.BorderThickness = new Thickness(1);
            brdBtnInfo.BorderBrush = config.btnForeColor;
            brdBtnInfo.Background = config.btnBackColor;
        }
        private void button_Notes()
        {
            btnNotes.Content = texts.btnNotes_content();
            btnNotes.ToolTip = texts.btnNotes_toolTip();

            btnNotes.Background = new SolidColorBrush(Colors.Transparent);
            btnNotes.Foreground = config.btnForeColor;

            brdBtnNotes.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnNotes.BorderThickness = new Thickness(1);
            brdBtnNotes.BorderBrush = config.btnForeColor;
            brdBtnNotes.Background = config.btnBackColor;

            if (config.chxHideNotes == true)
            {
                brdBtnNotes.Visibility = Visibility.Hidden;
            }
        }
        private void button_Minimize()
        {
            btnMinimize.Content = texts.btnMinimize_content();
            btnMinimize.ToolTip = texts.btnMinimize_toolTip();

            btnMinimize.Height = config.btnHeight;

            btnMinimize.Background = new SolidColorBrush(Colors.Transparent);
            btnMinimize.Foreground = config.btnForeColor;

            brdBtnMinimize.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnMinimize.BorderThickness = new Thickness(1);
            brdBtnMinimize.BorderBrush = config.btnForeColor;
            brdBtnMinimize.Background = config.btnBackColor;
        }
        private void button_Quit()
        {
            btnQuit.Content = texts.btnQuit_content();
            btnQuit.ToolTip = texts.btnQuit_toolTip();

            btnQuit.Height = config.btnHeight;

            btnQuit.Background = new SolidColorBrush(Colors.Transparent);
            btnQuit.Foreground = config.btnForeColor;

            brdBtnQuit.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnQuit.BorderThickness = new Thickness(1);
            brdBtnQuit.BorderBrush = config.btnForeColor;
            brdBtnQuit.Background = config.btnBackColor;
        }
        private void button_Rename()
        {
            btnRename.Content = texts.btnRename_content();
            btnRename.ToolTip = texts.btnRename_toolTip();

            btnRename.Background = new SolidColorBrush(Colors.Transparent);
            btnRename.Foreground = config.btnForeColor;

            brdBtnRename.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnRename.BorderThickness = new Thickness(1);
            brdBtnRename.BorderBrush = config.btnForeColor;
            brdBtnRename.Background = config.btnBackColor;
        }
        private void button_Reset()
        {
            btnReset.Content = texts.btnReset_content();
            btnReset.ToolTip = texts.btnReset_toolTip();

            btnReset.Background = new SolidColorBrush(Colors.Transparent);
            btnReset.Foreground = config.btnForeColor;

            brdBtnReset.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnReset.BorderThickness = new Thickness(1);
            brdBtnReset.BorderBrush = config.btnForeColor;
            brdBtnReset.Background = config.btnBackColor;
        }
        private void button_Scetchboard()
        {
            btnScetchboard.Content = texts.btnScetchboard_content();
            btnScetchboard.ToolTip = texts.btnScetchboard_toolTip();

            btnScetchboard.Background = new SolidColorBrush(Colors.Transparent);
            btnScetchboard.Foreground = config.btnForeColor;

            brdBtnScetchboard.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnScetchboard.BorderThickness = new Thickness(1);
            brdBtnScetchboard.BorderBrush = config.btnForeColor;
            brdBtnScetchboard.Background = config.btnBackColor;

            if (config.chxHideScetchboard == true)
            {
                brdBtnScetchboard.Visibility = Visibility.Hidden;
            }
        }
        private void button_Settings()
        {
            btnSettings.Content = texts.btnSettings_content();
            btnSettings.ToolTip = texts.btnSettings_toolTip();

            btnSettings.Background = new SolidColorBrush(Colors.Transparent);
            btnSettings.Foreground = config.btnForeColor;

            brdBtnSettings.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnSettings.BorderThickness = new Thickness(1);
            brdBtnSettings.BorderBrush = config.btnForeColor;
            brdBtnSettings.Background = config.btnBackColor;
        }
        private void button_Shutdown()
        {
            btnShutdown.Content = texts.btnShutdown_content();
            btnShutdown.ToolTip = texts.btnShutdown_toolTip();

            btnShutdown.Height = config.btnHeight;

            btnShutdown.Background = new SolidColorBrush(Colors.Transparent);
            btnShutdown.Foreground = config.btnForeColor;

            brdBtnShutdown.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnShutdown.BorderThickness = new Thickness(1);
            brdBtnShutdown.BorderBrush = config.btnForeColor;
            brdBtnShutdown.Background = config.btnBackColor;
        }
        private void button_Timer()
        {
            btnTimer.Content = texts.btnTimer_content();
            btnTimer.ToolTip = texts.btnTimer_toolTip();

            btnTimer.Background = new SolidColorBrush(Colors.Transparent);
            btnTimer.Foreground = config.btnForeColor;

            brdBtnTimer.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnTimer.BorderThickness = new Thickness(1);
            brdBtnTimer.BorderBrush = config.btnForeColor;
            brdBtnTimer.Background = config.btnBackColor;

            if (config.chxHideTimer == true)
            {
                brdBtnTimer.Visibility = Visibility.Hidden;
            }
        }
        #endregion button configuration

        // button state logic
        private void buttonStates(string state)
        {
            if (state == "hidemenu")
            {
                if (config.hidemenuButtonState == true)
                {
                    config.hidemenuButtonState = false;

                    wrpMenu.Margin = new Thickness(0, 0, 5, 0);
                    wrpMenu.Width = config.btnWidth;

                }
                else
                {
                    config.hidemenuButtonState = true;

                    wrpMenu.Width = 0;
                }
            }

            if (state == "rename")
            {
                btnstate_rename();
            }

            if (state == "reset")
            {
                btnstate_reset();
            }

            if (state == "delete")
            {
                btnstate_delete();
            }
        }

        // button creation
        #region button creation
        private void createDriveButtons(int count, DriveInfo d)
        {
            Style style = this.FindResource("buttonStyle") as Style;

            Button btnDrive = new Button();
            btnDrive.Name = "btnDrive" + btnDrvs.Count.ToString();
            btnDrive.Background = new SolidColorBrush(Colors.Transparent);
            btnDrive.Foreground = config.btnForeColor;
            btnDrive.FontFamily = config.font;
            btnDrive.FontSize = config.fontSize;
            btnDrive.Height = config.btnHeight;
            btnDrive.Width = config.btnWidth;

            btnDrive.Style = style;

            Border brdDrive = new Border();
            brdDrive.CornerRadius = new CornerRadius(config.borderRadius);
            brdDrive.Background = config.btnBackColor;
            brdDrive.BorderBrush = config.btnForeColor;
            brdDrive.BorderThickness = new Thickness(1);
            brdDrive.Margin = new Thickness(2, 0, 2, 5);
            brdDrive.Height = config.btnHeight;
            brdDrive.Width = config.btnWidth;

            brdDrive.Child = btnDrive;

            if (d.IsReady)
            {
                btnDrive.Content = $"{d.Name}{texts.btnDrive_tooltip0()} {d.TotalFreeSpace / config.gigabyte} GB";

                btnDrive.HorizontalContentAlignment = HorizontalAlignment.Left;
                btnDrive.VerticalContentAlignment = VerticalAlignment.Center;

                btnDrive.ToolTip = $"{d.TotalSize / config.gigabyte} {texts.btnDrive_tooltip1()}" +
                    $"{d.Name}{d.VolumeLabel}\n\n" +
                    $"{d.DriveFormat}{d.DriveType} {texts.btnDrive_tooltip2()}";
            }
            else
            {
                btnDrive.Content = $"{d.Name} {texts.btnDrive_tooltip3()}";

                if (d.IsReady == false)
                {
                    string tooltipText = $"{texts.btnDrive_tooltip4()}" +
                        $"{d.Name}\n\n + {d.DriveType}";

                    btnDrive.ToolTip = tooltipText;
                }
            }

            btnDrive.Click += BtnDrive_Click; ;

            wrpDrives.Children.Add(brdDrive);

            btnDrvs.Add(btnDrive);
        }
        private Border createSelectionButton(string configuration)
        {
            Style style = this.FindResource("buttonStyle") as Style;

            Border brd = new Border();
            Button btn = new Button();
            StackPanel stp = new StackPanel();
            TextBox tb = new TextBox();

            System.Windows.Controls.Image imageUICtrl = new System.Windows.Controls.Image();

            // Configuration Data
            string[] configParts = configuration.Split(';');

            configList.Add(configParts[0]);

            btn.ToolTip = configParts[1].ToString();
            if (configParts[0].ToString() == "+")
            {
                btn.ToolTip = texts.unset_tooltip();
            }
            if (configParts[0].ToString() == "")
            {
                btn.ToolTip = texts.empty_tooltip();
            }

            // Border Definition
            brd.CornerRadius = new CornerRadius(config.borderRadius);
            brd.BorderBrush = config.btnForeColor;
            brd.BorderThickness = new Thickness(1);
            brd.Background = config.btnBackColor;
            brd.Margin = new Thickness(2, 0, 2, 5);

            brd.Height = config.btnHeight;
            brd.Width = config.btnWidth;

            brd.Child = btn;

            btn.Content = stp;
            btn.Click += Btn_Click;

            btn.Name = $"btnSet{btnSetList.Count.ToString()}";
            //btn.Content = $"{configParts[0]}";
            btn.Height = config.btnHeight;
            btn.Width = config.btnWidth;
            btn.Background = new SolidColorBrush(Colors.Transparent);
            btn.Padding = new Thickness(5);
            btn.Foreground = config.btnForeColor;
            btn.FontSize = config.fontSize;

            btn.HorizontalContentAlignment = HorizontalAlignment.Center;
            btn.VerticalContentAlignment = VerticalAlignment.Center;

            btn.Style = style;

            if (configParts[0].ToString() != "+" && configParts[0].ToString() != "")
            {
                try
                {

                    imageUICtrl.Source = GetIcon(configParts[1]);
                    //
                    string result = configParts[1].Substring(configParts[1].Length - 4);

                    // MessageBox.Show(result);

                    if (configParts[1].Substring(configParts[1].Length - 4) == ".png")
                    {
                        //MessageBox.Show("buh");

                        System.Windows.Controls.Image finalImage = new System.Windows.Controls.Image();
                        finalImage.Width = 80;

                        BitmapImage logo = new BitmapImage();
                        logo.BeginInit();
                        logo.UriSource = new Uri(configParts[1]);
                        logo.CreateOptions = BitmapCreateOptions.DelayCreation;
                        logo.CacheOption = BitmapCacheOption.OnLoad;
                        logo.EndInit();

                        finalImage.Source = logo;
                        imageUICtrl.Source = logo;


                        imageUICtrl.Margin = new Thickness(config.btnHeight / 20);
                        imageUICtrl.Margin = new Thickness(config.btnWidth / 20);
                        imageUICtrl.Stretch = Stretch.Fill;

                        //imageUICtrl.Source = GetPicture(configParts[1]);
                    }

                    // images in einer Liste speichern und aus der Liste laden, die Liste
                    // muss irgendwie gespeichert werden, bzw. die icons
                }
                catch (Exception)
                {
                    //MessageBox.Show(configParts[1].ToString());
                }
            }


            //tb.Margin = new Thickness(config.btnHeight / 10);
            //tb.Margin = new Thickness(config.btnWidth / 10);


            tb.Height = config.btnHeight;
            tb.Width = config.btnWidth / 2;
            //tb.Visibility = Visibility.Hidden;
            tb.Background = new SolidColorBrush(Colors.Transparent);
            tb.Foreground = config.btnForeColor;
            tb.BorderThickness = new Thickness(0);
            tb.IsReadOnly = true;
            tb.IsEnabled = false;

            tb.HorizontalContentAlignment = HorizontalAlignment.Left;
            tb.VerticalContentAlignment = VerticalAlignment.Center;
            tb.TextWrapping = TextWrapping.Wrap;

            tb.Text = configParts[0];

            tb.MouseDoubleClick += TxtBtnContent_MouseDoubleClick;
            tb.KeyDown += TxtBtnContent_KeyDown;

            stp.Children.Add(imageUICtrl);
            stp.Children.Add(tb);
            stp.Orientation = Orientation.Horizontal;

            brdSetList.Add(brd);
            btnSetList.Add(btn);
            imageUICtrlList.Add(imageUICtrl);
            setList.Add(configParts[1]);
            spList.Add(stp);
            txtBoxList.Add(tb);

            wrpButtonMap.Children.Add(brd);

            return brd;
        }
        #endregion button creation


        // icon extraction
        private ImageSource GetIcon(string fileName)
        {
            Icon icon = System.Drawing.Icon.ExtractAssociatedIcon(fileName);
            return System.Windows.Interop.Imaging.CreateBitmapSourceFromHIcon(
                icon.Handle,
                new Int32Rect(),
                BitmapSizeOptions.FromEmptyOptions()
                );
        }

        // gui minimizer logic
        private void hideButtonMap()
        {
            if (config.hideButtonMapState == false)
            {
                config.hideButtonMapState = true;

                _height = (int)ButtonMap.Height;
                _width = (int)ButtonMap.Width;

                if (config.hidemenuButtonState == false)
                {
                    wrpButtonMap.Visibility = Visibility.Hidden;
                    ButtonMap.Width = config.btnWidth + 190;
                }
                if (config.hidemenuButtonState == true)
                {
                    wrpButtonMap.Visibility = Visibility.Hidden;

                    double btnQuitWidth = btnQuit.ActualWidth;

                    wrpDrives.Visibility = Visibility.Hidden;

                    ButtonMap.Width = 190 + btnQuitWidth;

                    _pulse.Stop();
                }
            }
            else
            {
                config.hideButtonMapState = false;

                if (_width > 150)
                {
                    ButtonMap.Height = _height;
                    ButtonMap.Width = _width;

                    wrpButtonMap.Visibility = Visibility.Visible;
                    wrpDrives.Visibility = Visibility.Visible;

                    _pulse.Start();
                }
            }

            GC.Collect();
        }
        private void hideStatesOnLoad()
        {
            if (config.hidemenuButtonState == true)
            {
                wrpMenu.Width = 0;
            }

            if (config.hideButtonMapState == true)
            {
                if (wrpMenu.Width > 0)
                {
                    wrpButtonMap.Width = 0;
                }
                if (wrpMenu.Width == 0)
                {
                    ButtonMap.Width = 250;
                }

                wrpButtonMap.Visibility = Visibility.Hidden;
            }
        }

        private void infoWindow()
        {
            Info info = new Info() { };
            info.Owner = this;
            info.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            info.Show();
        }

        // path insertion logic
        private void insertUrl()
        {
            if (config.resetButtonState == false)
            {
                TextBox txtInsertUrl = new TextBox();
                txtInsertUrl.Height = config.btnHeight;
                txtInsertUrl.Width = config.btnWidth;
                //txtInsertUrl.Visibility = Visibility.Visible;
                txtInsertUrl.Text = texts.insertUrl().ToString();
                txtInsertUrl.Background = new SolidColorBrush(Colors.Transparent);
                txtInsertUrl.Foreground = config.resetStateFont;
                txtInsertUrl.BorderBrush = config.resetStateFont;
                txtInsertUrl.BorderThickness = new Thickness(1);
                txtInsertUrl.HorizontalContentAlignment = HorizontalAlignment.Center;
                txtInsertUrl.VerticalContentAlignment = VerticalAlignment.Center;
                txtInsertUrl.Margin = new Thickness(2, 0, 2, 5);

                txtInsertUrl.KeyDown += TxtInsertUrl_KeyDown;
                txtInsertUrl.MouseDoubleClick += TxtInsertUrl_MouseDoubleClick;
                txtInsertUrl.MouseDown += TxtInsertUrl_MouseDown;
                txtInsertUrl.TextChanged += TxtInsertUrl_TextChanged;

                wrpButtonMap.Children.Add(txtInsertUrl);
            }
        }

        // load config data from file, create necessary files if no config file is found
        private void loadButtonMap()
        {
            // first use or if save.config was deleted
            if (!File.Exists(config.path_config))
            {
                createSelectionButton(configuration);
            }
            else
            {
                // load previously assigned buttons (load step 1)
                loadButtonMapBindings();

                // handle system drive display
                setupDrives();

                // assign applicational bindings (load step 2)
                for (int i = 0; i < btnSetList.Count(); i++)
                {
                    setApp(btnSetList[i], true);
                    //txtBoxList.Add
                }
            }
        }
        private void loadButtonMapBindings()
        {
            // Read the file line by line.  
            foreach (string line in System.IO.File.ReadLines(config.path_config))
            {
                createSelectionButton(line);
            }
        }

        // handle shown or hidden functionalities(e.g. appearance of timer button)
        private void loadChxSettings()
        {

            // note tool
            if (config.chxHideNotes == true)
            {
                btnNotes.Visibility = Visibility.Hidden;
            }

            // scetchboard tool
            if (config.chxHideScetchboard == true)
            {
                btnScetchboard.Visibility = Visibility.Hidden;
            }

            // timer tool
            if (config.chxHideTimer == true)
            {
                btnTimer.Visibility = Visibility.Hidden;
            }

            // coordinates display
            if (config.chxCoordinates == false)
            {
                tbMouseCoordinates.Visibility = Visibility.Hidden;
            }

            // drives display
            if (config.chxHideDrives == true)
            {
                wrpDrives.Visibility = Visibility.Hidden;
            }
        }


        #endregion methods _private A-L


        // methods _private M-Z
        #region methods _private M-Z

        // ui elements modulation
        private void modulateButtons()
        {
            Style style = this.FindResource("guiMinimizerStyle") as Style;

            btnHideMenu.Style = style;

            btnHideMenu.Background = config.btnHideMenuColor;
            btnHideMenu.Foreground = config.btnHideMenuFont;
            btnHideMenu.BorderBrush = config.btnHideMenuFont;
            btnHideMenu.BorderThickness = new Thickness(1);

            tbBtnHideMenu.Text = texts.hideButtonContent().ToString();
            btnHideMenu.ToolTip = texts.btnHideMenu_toolTip();


            btnHideButtonMap.Background = config.btnHideMenuColor;
            btnHideButtonMap.Foreground = config.btnHideMenuFont;
            btnHideButtonMap.BorderBrush = config.btnHideMenuFont;
            btnHideButtonMap.BorderThickness = new Thickness(1);

            tbBtnHideButtonMap.Text = texts.hideButtonContent().ToString();
            btnHideButtonMap.ToolTip = texts.btnHideButtonMap_toolTip();

            // set colors, dimensions and fonts for menu buttons
            for (int i = 0; i < btnMenuList.Count; i++)
            {
                btnMenuList[i].Foreground = config.btnForeColor;
                btnMenuList[i].FontFamily = config.font;
                btnMenuList[i].FontSize = config.fontSize;
                btnMenuList[i].Height = config.btnHeight;
                btnMenuList[i].Width = config.btnWidth;

                if (config.deleteButtonState == true)
                {
                    brdBtnDelete.Background = config.deleteState;
                    btnDelete.Foreground = config.deleteStateFont;
                }
                if (config.renameButtonState == true)
                {
                    brdBtnRename.Background = config.renameState;
                    btnRename.Foreground = config.renameStateFont;
                }
                if (config.resetButtonState == true)
                {
                    brdBtnReset.Background = config.resetState;
                    btnReset.Foreground = config.resetStateFont;
                }
            }

            // set colors, dimensions and fonts for set buttons
            for (int i = 0; i < btnSetList.Count; i++)
            {
                brdSetList[i].Background = config.btnBackColor;
                btnSetList[i].Foreground = config.btnForeColor;
                btnSetList[i].FontFamily = config.font;
                btnSetList[i].FontSize = config.fontSize;
                btnSetList[i].Height = config.btnHeight;
                btnSetList[i].Width = config.btnWidth;

                if (config.deleteButtonState == true)
                {
                    brdSetList[i].Background = config.deleteStateFont;
                    btnSetList[i].Foreground = config.deleteStateFont;
                }
                if (config.renameButtonState == true)
                {
                    brdSetList[i].Background = config.renameStateFont;
                    btnSetList[i].Foreground = config.renameStateFont;
                }
                if (config.resetButtonState == true)
                {
                    brdSetList[i].Background = config.resetStateFont;
                    btnSetList[i].Foreground = config.resetStateFont;
                }
            }
        }
        private void modulateMainWindow()
        {
            // height and width settings
            MinHeight = 50; MinWidth = 50;
            ButtonMap.Height = config.mainWindowHeight;
            ButtonMap.Width = config.mainWindowWidth;
            Height = config.mainWindowHeight;
            Width = config.mainWindowWidth;
            _height = (int)Height; _width = (int)Width;
            wrpMenu.Width = config.btnWidth;

            // button map width and heigth
            wrpButtonMap.MinHeight = config.btnHeight * 1.55;
            wrpButtonMap.MinWidth = config.btnWidth * 1.55;

            // button map colors
            Background = new SolidColorBrush(Colors.Transparent);
            Foreground = config.foreColor;

            //windowChrome.CornerRadius = new CornerRadius(config.borderRadius);
            border.CornerRadius = new CornerRadius(config.borderRadius);
            border.BorderThickness = new Thickness(3);
            border.BorderBrush = config.foreColor;
            border.Background = config.backColor;
        }

        // style handling
        private void propertyUpdate_deleteStyle()
        {
            // delete style
            ButtonMap.Resources.Remove("deleteColor");
            ButtonMap.Resources.Remove("deleteFont");
            ButtonMap.Resources.Remove("deleteHighlight");

            ButtonMap.Resources.Add("deleteColor", config.deleteState);
            ButtonMap.Resources.Add("deleteFont", config.deleteStateFont);
            ButtonMap.Resources.Add("deleteHighlight", config.btnBackColor);
        }
        private void propertyUpdate_guiMinimizerStyle()
        {
            // gui minimizer style
            ButtonMap.Resources.Remove("hideButton");
            ButtonMap.Resources.Remove("hideButtonFont");
            ButtonMap.Resources.Remove("highlight");
            ButtonMap.Resources.Remove("radius");

            ButtonMap.Resources.Add("hideButton", config.btnHideMenuColor);
            ButtonMap.Resources.Add("hideButtonFont", config.btnHideMenuFont);
            ButtonMap.Resources.Add("highlight", config.highlightColor);
            ButtonMap.Resources.Add("radius", new CornerRadius(config.borderRadius));
        }
        private void propertyUpdate_menuStyle()
        {
            // normal style
            ButtonMap.Resources.Remove("buttonColor");
            ButtonMap.Resources.Remove("buttonFont");
            ButtonMap.Resources.Remove("highlight");
            ButtonMap.Resources.Remove("radius");

            ButtonMap.Resources.Add("buttonColor", config.btnBackColor);
            ButtonMap.Resources.Add("buttonFont", config.btnForeColor);
            ButtonMap.Resources.Add("highlight", config.highlightColor);
            ButtonMap.Resources.Add("radius", new CornerRadius(config.borderRadius));
        }
        private void propertyUpdate_normalStyle()
        {
            // normal style
            ButtonMap.Resources.Remove("buttonColor");
            ButtonMap.Resources.Remove("buttonFont");
            ButtonMap.Resources.Remove("highlight");
            ButtonMap.Resources.Remove("radius");

            ButtonMap.Resources.Add("buttonColor", config.btnBackColor);
            ButtonMap.Resources.Add("buttonFont", config.btnForeColor);
            ButtonMap.Resources.Add("highlight", config.highlightColor);
            ButtonMap.Resources.Add("radius", new CornerRadius(config.borderRadius));
        }
        private void propertyUpdate_renameStyle()
        {
            // rename style
            ButtonMap.Resources.Remove("renameColor");
            ButtonMap.Resources.Remove("renameFont");
            ButtonMap.Resources.Remove("renameHighlight");

            ButtonMap.Resources.Add("renameColor", config.renameState);
            ButtonMap.Resources.Add("renameFont", config.renameStateFont);
            ButtonMap.Resources.Add("renameHighlight", config.btnBackColor);
        }
        private void propertyUpdate_resetStyle()
        {
            // reset style
            ButtonMap.Resources.Remove("resetColor");
            ButtonMap.Resources.Remove("resetFont");
            ButtonMap.Resources.Remove("resetHighlight");

            ButtonMap.Resources.Add("resetColor", config.resetState);
            ButtonMap.Resources.Add("resetFont", config.resetStateFont);
            ButtonMap.Resources.Add("resetHighlight", config.btnBackColor);
        }

        private void scetchboardWindow()
        {
            Scetchboard scetchboard = new Scetchboard() { };
            scetchboard.Owner = this;
            scetchboard.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            scetchboard.Show();
        }

        // binding logic
        private string setApp(Button btnSet, bool formLoad)
        {
            // handle program assignements to buttons
            string filepath;
            string filename;

            int index = btnSetList.IndexOf(btnSet);

            TextBox tb = txtBoxList[index];
            System.Windows.Controls.Image img = imageUICtrlList[index];


            if (formLoad == true)
            {
                filepath = setList[index];
                filename = System.IO.Path.GetFileName(filepath);
                filename = filename.Replace(".exe", "");
                tb.Text = configList[index];

                return filepath;
            }
            else
            {
                OpenFileDialog setPath = new OpenFileDialog();
                setPath.InitialDirectory = Environment.GetEnvironmentVariable("userdir");
                setPath.FilterIndex = 2;
                setPath.RestoreDirectory = true;
                setPath.Filter = "executables (*.exe)|*.exe|All files (*.*)|*.*";

                if (setPath.ShowDialog() == true)
                {
                    filepath = setPath.FileName.ToString();
                    filename = System.IO.Path.GetFileName(filepath);

                    filename = filename.Replace(".exe", "");

                    //TextBox tb = txtBoxList[index];

                    ////btnSet.FontSize = config.fontSize;
                    tb.Text = filename;
                    //btnSet.ToolTip = filename;

                    configList[index] = filename;
                    setList[index] = filepath;
                    img = imageUICtrlList[index];

                    btnSet.ToolTip = filepath;

                    try
                    {

                        img.Source = GetIcon(filepath);
                        //
                        string result = filepath.Substring(filepath.Length - 4);

                        // MessageBox.Show(result);

                        if (result == ".png")
                        {
                            //MessageBox.Show("buh");

                            System.Windows.Controls.Image finalImage = new System.Windows.Controls.Image();
                            finalImage.Width = config.btnWidth / 2;

                            BitmapImage logo = new BitmapImage();
                            logo.BeginInit();
                            logo.UriSource = new Uri(filepath);
                            logo.CreateOptions = BitmapCreateOptions.DelayCreation;
                            logo.CacheOption = BitmapCacheOption.OnLoad;
                            logo.EndInit();

                            finalImage.Source = logo;
                            imageUICtrlList[index].Source = logo;

                            imageUICtrlList[index].Margin = new Thickness(config.btnHeight / 20);
                            imageUICtrlList[index].Margin = new Thickness(config.btnWidth / 20);
                            imageUICtrlList[index].Stretch = Stretch.Fill;

                            //imageUICtrl.Source = GetPicture(configParts[1]);
                        }

                        // images in einer Liste speichern und aus der Liste laden, die Liste
                        // muss irgendwie gespeichert werden, bzw. die icons
                    }
                    catch (Exception)
                    {
                        //MessageBox.Show(configParts[1].ToString());
                    }

                    return filepath;
                }
                else
                {
                    filepath = "path";
                    tb.Text = "+";
                    //btnSet.ToolTip = texts.unset_tooltip();

                    return filepath;
                }

            }
        }

        // system drive determination
        private void setupDrives()
        {
            Button btnAll = new Button();

            config.newDriveInfo();

            Style style = this.FindResource("buttonStyle") as Style;

            btnAll.Content = texts.btnAll_content();
            btnAll.Background = new SolidColorBrush(Colors.Transparent);
            btnAll.Foreground = config.btnForeColor;
            btnAll.FontFamily = config.font;
            btnAll.FontSize = config.fontSize;
            btnAll.Height = config.btnHeight;
            btnAll.Width = config.btnWidth;
            btnAll.ToolTip = $"{texts.btnAll_toolTip0()}" +
                $"{config.readyDrives} / {config.allDrives.Length} {texts.btnAll_toolTip1()}" +
                $"{ config.totalFreeSpace / config.gigabyte} {texts.btnAll_toolTip2()}";
            btnAll.HorizontalContentAlignment = HorizontalAlignment.Center;
            btnAll.VerticalContentAlignment = VerticalAlignment.Center;

            btnAll.Style = style;

            Border brdBtnAll = new Border();
            brdBtnAll.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnAll.BorderBrush = config.btnForeColor;
            brdBtnAll.BorderThickness = new Thickness(1);
            brdBtnAll.Margin = new Thickness(2, 0, 2, 5);
            brdBtnAll.Height = config.btnHeight;
            brdBtnAll.Width = config.btnWidth;

            brdBtnAll.Child = btnAll;

            btnAll.Click += BtnAll_Click;

            wrpDrives.Children.Add(brdBtnAll);

            for (int i = 0; i < config.allDrives.Length; i++)
            {
                createDriveButtons(i, config.allDrives[i]);
            }
        }

        // main menu configuration
        private void setupMenu()
        {
            button_Quit();
            button_Minimize();

            btnMenuList.Clear();

            // menu buttons list assignement
            if (btnMenuList.Count == 0)
            {
                btnMenuList.Add(btnAdd);
                button_Add();

                btnMenuList.Add(btnDelete);
                button_Delete();

                btnMenuList.Add(btnRename);
                button_Rename();

                btnMenuList.Add(btnReset);
                button_Reset();

                btnMenuList.Add(btnSettings);
                button_Settings();

                btnMenuList.Add(btnInfo);
                button_Info();

                btnMenuList.Add(btnNotes);
                button_Notes();
          
                btnMenuList.Add(btnTimer);
                button_Timer();

                btnMenuList.Add(btnScetchboard);
                button_Scetchboard();

                btnMenuList.Add(btnShutdown);
                button_Shutdown();
            }

        }

        // shutdown handling
        private void shutdown()
        {
            string question = texts.shutdownQuestion().ToString();
            string title = texts.shutdownTitle().ToString();

            MessageBoxResult result = MessageBox.Show(question, title, MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                string command = "/C shutdown /p";
                Process.Start("cmd.exe", command);
            }
        }

        // file opening logic
        private void startUp(string filepath)
        {
            try
            {
                if (filepath != "path")
                {
                    ProcessStartInfo start = new ProcessStartInfo(filepath);
                    start.UseShellExecute = true;
                    Process.Start(start);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{texts.pathExcetptionMessage()} {ex.Message}");
            }
        }
        #endregion methods _private M-Z


        // events _private
        #region button events
        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            TextBox tb;

            int counter = btnSetList.IndexOf(btn);
            string filepath = "";

            tb = txtBoxList[counter];

            if (config.resetButtonState == true || config.deleteButtonState == true)
            {
                if (config.resetButtonState == true)
                {
                    reset_click(btn, tb, counter, filepath);
                }

                if (config.deleteButtonState == true)
                {
                    delete_click(counter);
                }
            }
            else if (config.renameButtonState == true)
            {
                rename_click(sender, e);
            }
            else
            {
                normal_click(sender, btn, filepath, counter);
            }
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            insertUrl();

            ////Style style = this.FindResource("buttonStyle") as Style;

            ////SelectionButton sb = new SelectionButton(
            ////    config.btnBackColor, config.btnForeColor, config.backColor, config.btnForeColor,
            ////    config.btnHeight, config.borderRadius, config.btnWidth
            ////    );

            ////Border brd = sb.construct();
            ////Button btn = sb.borderChild;

            ////btn.Style = style;

            ////wrpButtonMap.Children.Add(brd);
        }
        private void BtnAll_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < config.allDrives.Length; i++)
            {
                if (config.allDrives[i].IsReady)
                {
                    Process.Start("explorer.exe", config.allDrives[i].Name);
                }
            }
        }
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (config.renameButtonState == true)
            {
                MessageBox.Show("deactivate rename state first");
            }
            else if (config.resetButtonState == true)
            {
                MessageBox.Show("deactivate reset state first");
            }
            else
            {
                buttonStates("delete");
            }
        }
        private void BtnDrive_Click(object sender, RoutedEventArgs e)
        {
            Button btnDrive = (Button)sender;
            int index = btnDrvs.IndexOf(btnDrive);

            if (config.allDrives[index].IsReady)
            {
                Process.Start("explorer.exe", config.allDrives[index].Name);
            }

            if (!config.allDrives[index].IsReady)
            {
                MessageBox.Show(texts.driveNotReadyMessage().ToString());
            }
        }
        private void btnHideButtonMap_Click(object sender, RoutedEventArgs e)
        {
            hideButtonMap();

            if (_width < 301)
            {
                ButtonMap.Height = _height;
                ButtonMap.Width = 600;

                wrpButtonMap.Visibility = Visibility.Visible;
            }
        }
        private void btnHideMenu_Click(object sender, RoutedEventArgs e)
        {
            buttonStates("hidemenu");
        }
        private void btnInfo_Click(object sender, RoutedEventArgs e)
        {
            infoWindow();
        }
        private void btnMinimize_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.MainWindow.WindowState = WindowState.Minimized;
        }
        private void btnQuit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private void btnRename_Click(object sender, RoutedEventArgs e)
        {
            if (config.deleteButtonState == true)
            {
                MessageBox.Show("deactivate rename state first");
            }
            else if (config.resetButtonState == true)
            {
                MessageBox.Show("deactivate reset state first");
            }
            else
            {
                buttonStates("rename");
            }
        }
        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            if (config.deleteButtonState == true)
            {
                MessageBox.Show("deactivate delete state first");
            }
            else if (config.renameButtonState == true)
            {
                MessageBox.Show("deactivate reset state first");
            }
            else
            {
                buttonStates("reset");
            }
        }
        private void btnNotes_Click(object sender, RoutedEventArgs e)
        {
            Notes notes = new Notes() { };

            notes.Owner = this;
            notes.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            notes.Show();
        }

        private void btnScetchboard_Click(object sender, RoutedEventArgs e)
        {
            scetchboardWindow();
        }
        private void btnSettings_Click(object sender, RoutedEventArgs e)
        {
            YourStartUp_Settings yourStartUp_Settings = new YourStartUp_Settings(ButtonMap) { };

            config.mainWindowHeight = (int)Height;
            config.mainWindowWidth = (int)Width;

            config.saveSettings();

            yourStartUp_Settings.Owner = this;
            yourStartUp_Settings.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            yourStartUp_Settings.Show();
        }
        private void btnShutdown_Click(object sender, RoutedEventArgs e)
        {
            shutdown();
        }
        private void btnTimer_Click(object sender, RoutedEventArgs e)
        {
            Timer timer = new Timer() { };

            timer.Owner = this;
            timer.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            timer.Show();
        }
        #endregion button events

        #region buttonmap events
        private void ButtonMap_Closed(object sender, EventArgs e)
        {

        }
        private void ButtonMap_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            _pulse.Stop();

            config.mainWindowHeight = (int)Height;
            config.mainWindowWidth = (int)Width;

            config.saveConfig(btnSetList, setList, configList);
            config.saveSettings();

            Application.Current.Shutdown();
        }
        private void ButtonMap_Drop(object sender, DragEventArgs e)
        {

        }
        private void ButtonMap_Loaded(object sender, RoutedEventArgs e)
        {
            config = new ConfigData() { };

            loadButtonMap();
            loadUIConfig();

            this.ToolTip = texts.mainWindow_tooltip();

            if (config.chxHideDrives == false)
            {
                _pulse.Start();
            }
        }
        private void ButtonMap_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.F1)
            {
                infoWindow();
            }

            if (e.Key == Key.F4)
            {
                scetchboardWindow();
            }
        }

        private void ButtonMap_KeyUp(object sender, KeyEventArgs e)
        {
            e.Handled = true;
        }
        private void ButtonMap_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
        }
        private void ButtonMap_MouseMove(object sender, MouseEventArgs e)
        {
            tbMouseCoordinates.Text = e.GetPosition(this).ToString();
        }

        private void ButtonMap_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (config.resetButtonState == false)
            {
                if (e.ChangedButton == MouseButton.Right)
                {
                    createSelectionButton(configuration);
                }
            }
        }
        private void ButtonMap_PreviewDragOver(object sender, DragEventArgs e)
        {

        }
        private void ButtonMap_SizeChanged(object sender, SizeChangedEventArgs e)
        {

        }

        #endregion buttonmap events

        #region grdMainWindow events        
        private void grdMainWindow_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = e.Data.GetData(DataFormats.FileDrop) as string[];
                string filename = System.IO.Path.GetFileName(files[0]);
                string configuration = $"{files[0]};{files[0]}";

                //if (files[0] != null && files[0].Length > 0)
                //{
                //    createSelectionButton(configuration);
                //}

                for (int i = 0; i < files.Length; i++)
                {
                    configuration = $"{files[i]};{files[i]}";
                    if (files[i] != null && files[i].Length > 0)
                    {
                        createSelectionButton(configuration);
                    }
                }
            }
        }

        private void grdMainWindow_PreviewDragOver(object sender, DragEventArgs e)
        {
            e.Handled = true;
        }
        #endregion grdMainWindow

        #region textbox events
        private void TxtBtnContent_KeyDown(object sender, KeyEventArgs e)
        {

            TextBox txtBtn = (TextBox)sender;

            int index = txtBoxList.IndexOf(txtBtn);

            Button btnSet = btnSetList[index];

            if (e.Key == Key.Enter)
            {
                Keyboard.ClearFocus();

                if (txtBtn.Text == "+")
                {
                    btnSet.Content = txtBtn.Text;
                    configList[index] = "path";
                    setList[index] = "path";
                    btnSet.ToolTip = texts.unset_tooltip();
                }

                else if (txtBtn.Text == "")
                {
                    btnSet.Content = txtBtn.Text;
                    configList[index] = "empty";
                    setList[index] = "empty";
                    btnSet.ToolTip = texts.empty_tooltip();
                }

                else if (txtBtn.Text != "" && txtBtn.Text != "+")
                {
                    //System.Windows.Controls.Image img = imageUICtrlList[index];

                    configList[index] = txtBtn.Text;

                    if (txtBtn.Text.StartsWith("http") || txtBtn.Text.StartsWith("www"))
                    {
                        setList[index] = txtBtn.Text;
                    }
                }
            }
        }

        private void TxtBtnContent_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            TextBox txtBtn;
            int index = txtBoxList.IndexOf((TextBox)sender);
            txtBtn = txtBoxList[index];
            txtBtn.Text = "";
        }
        private void TxtBtnContent_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TxtInsertUrl_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox txtBtn = (TextBox)sender;

            if (e.Key == Key.Enter)
            {
                Keyboard.ClearFocus();

                string config = $"{txtBtn.Text};{txtBtn.Text}";

                createSelectionButton(config);

                wrpButtonMap.Children.Remove(txtBtn);
            }
        }
        private void TxtInsertUrl_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            TextBox txtBtn = (TextBox)sender;
            txtBtn.Text = "";
        }
        private void TxtInsertUrl_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }
        private void TxtInsertUrl_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        #endregion textbox events
    }
}
/* YourStartUp buttonmap tool  
 * 
 * End of File
 */