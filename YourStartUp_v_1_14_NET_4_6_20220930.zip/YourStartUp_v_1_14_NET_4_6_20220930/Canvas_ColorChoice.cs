﻿/* YourStartUp sub class for color feature class
 * 
 * Pur:         ccb color binding loading and saving logic
 * Toc:         2022 (august <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      kammel@posteo.de
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace YourStartUp
{
    class Canvas_ColorChoice
    {
        public List<Color> colorLST = new List<Color>();

        Color color = Color.FromArgb(0, 0, 0, 0);

        private string absolute_path = $@"{Directory.GetCurrentDirectory()}";

        private string file = @"\files\save.colorChoice";

        string filePath;


        // constructor
        public Canvas_ColorChoice()
        {
            determineFilePath();

            loadColors();
        }


        // publics
        
        public bool checkExistence(string path_)
        {
            if (!Directory.Exists(path_))
            {
                return true;
            }
            else
            {
                createDirectory(path_);
                return false;
            }
        }

        public void loadColors()
        {
            checkExistence(file);

            //MessageBox.Show($"{file} fuck you pc\n{absolute_path}\n{filePath}");

            if (!File.Exists(filePath))
            {
                StreamWriter sw_config = new StreamWriter($"{filePath}", false);

                colorLST = loadDefaults();

                foreach (Color clr in colorLST)
                {
                    sw_config.WriteLine(clr.ToString());
                }

                sw_config.Close();
            }
            else loadColorsFromFile();
        }

        private void createDirectory(string path_)
        {
            Directory.CreateDirectory(path_);
        }

        private bool loadColorsFromFile()
        {
            List<string> stringList = new List<string>();

            StreamReader sr = new StreamReader(filePath);

            string line;

            while ((line = sr.ReadLine()) != null)
            {
                stringList.Add(line);
            }
            sr.Close();

            for (int i = 0; i < stringList.Count; i++)
            {
                colorLST.Add(colorConverter(stringList[i]).Color);
            }

            if (colorLST.Count > 0)
            {
                return true;
            }
            else
            {
                colorLST.Clear();
                colorLST = loadDefaults();

                return false;
            }
        }


        public void saveColorsToFile(List<Color> colors)
        {
            StreamWriter sw_colorChoice = new StreamWriter(filePath, false);

            for (int i = 0; i < colors.Count; i++)
            {
                sw_colorChoice.WriteLine($"{colors[i]}");
            }

            sw_colorChoice.Close();
        }


        // privates


        private SolidColorBrush colorConverter(string color)
        {
            SolidColorBrush convertedColor;
            byte a, r, g, b;

            color.Trim();

            a = byte.Parse(color.Substring(1, 2), System.Globalization.NumberStyles.HexNumber);
            r = byte.Parse(color.Substring(3, 2), System.Globalization.NumberStyles.HexNumber);
            g = byte.Parse(color.Substring(5, 2), System.Globalization.NumberStyles.HexNumber);
            b = byte.Parse(color.Substring(7, 2), System.Globalization.NumberStyles.HexNumber);

            Color argb = Color.FromArgb(a, r, g, b);
            convertedColor = new SolidColorBrush(argb);

            return convertedColor;
        }

        private void determineFilePath()
        {
            filePath = $@"{absolute_path}{file}";
        }


        private List<Color> loadDefaults()
        {
            List<Color> colorList = new List<Color>();

            for (int i = 0; i < 28; i++)
            {
                byte colorIncrement = (byte)(i * 8);

                if (i < 9)
                {
                    colorList.Add(Color.FromArgb(175, colorIncrement, 0, 0));
                }

                else if (i < 19)
                {
                    colorList.Add(Color.FromArgb(175, 0, colorIncrement, 0));
                }

                else if (i < 29)
                {
                    colorList.Add(Color.FromArgb(175, 0, 0, colorIncrement));
                }
            }


            return colorList;
        }
    }
}
