﻿/* YourStartUp ui class - obsolete, 
 *                        developed on the fly for the scetchboard tool because
 *                        the config class wasn't available as scetchboard
 *                        development started outside the main project
 * 
 * Pur:         drawing logic for scetchboard functions
 * Toc:         2022 (august <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      kammel@posteo.de
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace YourStartUp
{
    class Canvas_UIConfig
    {
        public SolidColorBrush background { get; set; }
        public SolidColorBrush border { get; set; }
        public SolidColorBrush borderBrush { get; set; }
        public SolidColorBrush button { get; set; }

        public SolidColorBrush foreground { get; set; }

        public SolidColorBrush highlight { get; set; }

        public SolidColorBrush transparent { get; set; }

        public SolidColorBrush white { get; set; }

        public double borderThickness { get; set; }

        public int cornerRadius { get; set; }

        public double buttonHeight { get; set; }

        public double buttonWidth { get; set; }


        private bool savedConfig = false;


        // constructor
        public Canvas_UIConfig()
        {

            if (checkForSavedConfig() == true)
            {
                savedConfig = true;
            }


            if (savedConfig == false)
            {
                setStandard();
            }
        }

        public bool setStandard()
        {
            background = new SolidColorBrush(Colors.AntiqueWhite);

            border = new SolidColorBrush(Color.FromArgb(155, 22, 22, 44));

            borderBrush = new SolidColorBrush(Colors.DarkGoldenrod);

            button = new SolidColorBrush(Colors.AliceBlue);

            foreground = new SolidColorBrush(Colors.WhiteSmoke);

            highlight = new SolidColorBrush(Colors.Silver);

            transparent = new SolidColorBrush(Colors.Transparent);

            white = new SolidColorBrush(Color.FromArgb(255, 255, 255, 255));

            borderThickness = 3;

            cornerRadius = 25;

            //buttonHeight = 30;

            //buttonWidth = 40;

            return true;
        }


        private bool checkForSavedConfig()
        {

            return false;
        }
    }
}
