﻿/* YourStartUp notes tool (not yet developed)
 * 
 * Pur:         opens a window with a text editor functionality, notes should be saveable to file
 * Toc:         2022 (may <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      taranis.sk@gmail.com
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace YourStartUp
{
    /*     
     * TO DO
     * 
     * saveable content, loadable content
     * 
     * richtextbox instead of textbox
     * 
     * some basic format options
     * 
     * text to email
     * text to pdf
     * text to rtf
     * 
     * text to odt,docx?
     * 
     */


    /// <summary>
    /// Interaktionslogik für Notes.xaml
    /// </summary>
    public partial class Notes : Window
    {
        ConfigData config = new ConfigData() { };
        NotesTexts notes = new NotesTexts() { };

        NoteTemplateClass noteTemplateClass;

        //UserControl1 userControl1;

        private List<FlowDocument> lstFlowDocuments = new List<FlowDocument>();
        private List<RichTextBox> lstNoteTexts = new List<RichTextBox>();
        private List<TextBox> lstNoteTitles = new List<TextBox>();
        //private List<UserControl1> userControl1s = new List<UserControl1>();

        bool test = false;

        public double btnWidth;

        System.Windows.Threading.DispatcherTimer _notes_timer = new System.Windows.Threading.DispatcherTimer();

        string path = @"\files\notes.txt";

        public Notes(string schnullimist)
        {

        }

        public Notes()
        {
            InitializeComponent();
            _notes_timer.Tick += _notes_timer_Tick;
            _notes_timer.Interval = TimeSpan.FromSeconds(0.3);
            _notes_timer.Start();
        }

        private void _notes_timer_Tick(object sender, EventArgs e)
        {
            txtTime.Text = $"{getDateTimeString()}{notes.headline()}";


            //if (test == false)
            //{
            //    for (int i = 0; i < userControl1s.Count; i++)
            //    {
            //        userControl1s[i].Background = userControl1.Background = config.textBox();
            //    }
            //    test = true;
            //}
            //else { for (int i = 0; i < userControl1s.Count; i++)
            //{
            //    userControl1s[i].Background = userControl1.Background = config.backColor();
            //        test = false;
            //}
            //}

        }

        private void createNote()
        {

            //userControl1 = new UserControl1();

            //userControl1s.Add(userControl1);
            //wrpNotes.Children.Add(userControl1);

            //userControl1.Background = config.textBox();
            //userControl1.Foreground = config.textBoxFont();

            //userControl1.VerticalContentAlignment = VerticalAlignment.Top;

            //WrapPanel noteBlock = new WrapPanel() { };            

            //TextBox noteTitle = new TextBox() { };
            //noteTitle.Height = config.getButtonHeight();
            //noteTitle.Width = config.getButtonWidth() * 2 + 20;
            //noteTitle.FontFamily = config.font();
            //noteTitle.FontSize = config.getFontSize();
            //noteTitle.Background = config.textBox();
            //noteTitle.Foreground = config.textBoxFont();
            //noteTitle.Margin = new Thickness(0,2,5,0);
            //noteTitle.Text = txtTime.Text + "\n";
            //lstNoteTitles.Add(noteTitle);            

            //RichTextBox noteText = new RichTextBox() { };
            //noteText.Height = config.getButtonHeight()*5;
            //noteText.Width = config.getButtonWidth() * 2 + 20;
            //noteText.FontFamily = config.font();
            //noteText.FontSize = config.getFontSize();
            //noteText.Background = config.textBox();
            //noteText.Foreground = config.textBoxFont();
            //noteText.Margin = new Thickness(0, 2, 5, 0);            
            //lstNoteTexts.Add(noteText);

            //// line spacing within noteText
            //noteText.SetValue(Paragraph.LineHeightProperty, 5.0);

            //noteBlock.Children.Add(noteTitle);
            //noteBlock.Children.Add(noteText);
            //noteBlock.Orientation = Orientation.Vertical;
            //noteBlock.FlowDirection = FlowDirection.LeftToRight;            

            //wrpNotes.Children.Add(noteBlock);

            //noteText.AppendText(txtTime.Text + "\n");

            //// nice
            //TextRange textRange = new TextRange(noteText.Document.ContentStart, noteText.Document.ContentEnd);
            ////MessageBox.Show(textRange.Text);

        }
        private void generateNotesTemplateUC()
        {
            noteTemplateClass = new NoteTemplateClass(txtTime.Text);

            Border fuckDrecksMistXAMLSCHEISSE = new Border();
            fuckDrecksMistXAMLSCHEISSE.CornerRadius = new CornerRadius(config.borderRadius);
            noteTemplateClass.Background = new SolidColorBrush(Colors.Transparent);
            fuckDrecksMistXAMLSCHEISSE.Background = config.textBox;
            fuckDrecksMistXAMLSCHEISSE.Margin = new Thickness(5);

            fuckDrecksMistXAMLSCHEISSE.Child = noteTemplateClass;

            wrpNotes.Children.Add(fuckDrecksMistXAMLSCHEISSE);

        }

        private string getDateTimeString()
        {
            DateTime dateTime = DateTime.Now;

            string dateTimeString = dateTime.ToString("yyyy|MM|dd||HH|mm\n");

            return dateTimeString;
        }
        private void shiftNotification(RichTextBox _noteText)
        {


            //string note = _noteText.
            //string notiz = rtbNotiz.Text;
            //rtbNotiz.Text = tbxZeit.Text + "\n" + notiz;
        }

        private void createFlowDocument(RichTextBox _noteText)
        {
            //_noteText.AppendText(txtTime.Text + "\n");


            Paragraph flowLine = new Paragraph();
            if (lstFlowDocuments.Count < 1)
            {
                _noteText.AppendText(txtTime.Text);

                // Create a FlowDocument  
                FlowDocument flowText = new FlowDocument();
                // Create a paragraph with text  
                flowLine.Inlines.Add(new Bold(new Run($"{getDateTimeString()}{notes.headline()}")));
                // Add the paragraph to blocks of paragraph  
                flowText.Blocks.Add(flowLine);
                // Create RichTextBox, set its hegith and width  
                RichTextBox flowContainer = _noteText;
                // Set contents  
                flowContainer.Document = flowText;
                // Add RichTextbox to the container 
                lstFlowDocuments.Add(flowText);
            }
            if (lstFlowDocuments.Count >= 1)
            {
                _noteText.AppendText(txtTime.Text);
            }
        }

        private void loadConfig()
        {
            config.loadConfig();

            yrs_notes.Resources.Remove("buttonColor");
            yrs_notes.Resources.Remove("buttonFont");
            yrs_notes.Resources.Remove("highlight");
            yrs_notes.Resources.Remove("radius");

            yrs_notes.Resources.Add("buttonColor", config.btnBackColor);
            yrs_notes.Resources.Add("buttonFont", config.btnForeColor);
            yrs_notes.Resources.Add("highlight", config.highlightColor);
            yrs_notes.Resources.Add("radius", new CornerRadius(config.borderRadius));
        }

        private void setUI()
        {
            wrpNotes.Margin = new Thickness(5, config.btnHeight + 10, 5, 0);

            yrs_notes.FontFamily = config.font;
            yrs_notes.FontSize = config.fontSize;

            Background = new SolidColorBrush(Colors.Transparent);
            Foreground = config.foreColor;

            brdGrid.CornerRadius = new CornerRadius(config.borderRadius);
            brdGrid.BorderThickness = new Thickness(3);
            brdGrid.BorderBrush = config.foreColor;
            brdGrid.Background = config.backColor;

            Style style = this.FindResource("buttonStyle") as Style;

            btnNew.Height = config.btnHeight;
            btnNew.Width = config.btnWidth;
            btnNew.Background = new SolidColorBrush(Colors.Transparent);
            btnNew.Foreground = config.btnForeColor;

            brdBtnNew.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnNew.BorderThickness = new Thickness(1);
            brdBtnNew.BorderBrush = config.btnForeColor;
            brdBtnNew.Background = config.btnBackColor;

            btnNew.Style = style;

            txtTime.Height = config.btnHeight;
            txtTime.Width = config.btnWidth;
            txtTime.Background = config.textBox;
            txtTime.Foreground = config.textBoxFont;

            txtTime.Text = $"{getDateTimeString()}{notes.headline()}";

            yrs_notes.Width = 2 * config.btnWidth + 40;
        }


        private void yrs_notes_Loaded(object sender, RoutedEventArgs e)
        {
            loadConfig();

            setUI();
        }

        private void btnNew_Click(object sender, RoutedEventArgs e)
        {
            //createNote();
            generateNotesTemplateUC();
            btnNew.IsEnabled = false;
        }

        private void txtTime_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                //if (lstNoteTexts.Count == 0)
                //{
                //    //createNote();
                //}
                //else
                //{
                //    int index_Texts = lstNoteTexts.Count - 1;
                //    int index_Titles = lstNoteTitles.Count - 1;

                //    createFlowDocument(lstNoteTexts[index_Texts]);
                //}
            }
        }

        private void txtTime_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void txtTime_MouseDown(object sender, MouseButtonEventArgs e)
        {
            txtTime.Text = $"{getDateTimeString()}{notes.headline()}";

            //shiftNotification();
        }

        private void yrs_notes_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                this.Close();
            }
        }

        private void yrs_notes_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            for (int i = 0; i < lstFlowDocuments.Count; i++)
            {
                TextRange tr = new TextRange(lstFlowDocuments[i].ContentStart,
                                    lstFlowDocuments[i].ContentEnd);
                FileStream file = new FileStream(config.path_notes, FileMode.Create);
                tr.Save(file, System.Windows.DataFormats.Text);
                file.Close();

                TextRange tr_rtf = new TextRange(lstFlowDocuments[i].ContentStart,
                      lstFlowDocuments[i].ContentEnd);
                FileStream file_rtf = new FileStream($"files/{i.ToString()}", FileMode.Create);
                tr_rtf.Save(file_rtf, System.Windows.DataFormats.Rtf);
                file_rtf.Close();


            }

            //StreamWriter sw_notes = new StreamWriter(config.getNotesTitlesPath(), false);

            //for (int i = 0; i < lstNoteTitles.Count; i++)
            //{
            //    lstNoteTexts[i]..WriteLine(lstNoteTitles[i]);
            //}
            //sw_notes_titles.Close();

            StreamWriter sw_notes_titles = new StreamWriter(config.path_notes_titles, false);

            for (int i = 0; i < lstNoteTitles.Count; i++)
            {
                sw_notes_titles.WriteLine(lstNoteTitles[i]);
            }
            sw_notes_titles.Close();


            GC.Collect(0);
        }
    }
}
/* YourStartUp timer tool  
 * 
 * End of File
 */