﻿/* YourStartUp basic geometry class
 * 
 * Pur:         drawing logic for scetchboard functions
 * Toc:         2022 (august <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      kammel@posteo.de
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;

namespace YourStartUp
{
    class Canvas_BasicGeometry
    {
        // properties
        //public SolidColorBrush fillColor { get; set; }
        //public SolidColorBrush strokeColor { get; set; }

        // constructor
        public Canvas_BasicGeometry()
        {

        }


        // methods
        //public Polyline A(double width, double height)
        //{
        //    Polyline letter = new Polyline();


        //    // diesen dummen Scheiß werde ich später weiter machen.

        //    //System.Windows.Point Point1 = new System.Windows.Point(0, 0);
        //    //System.Windows.Point Point1 = new System.Windows.Point(width * 0.5, height);
        //    //System.Windows.Point Point2 = new System.Windows.Point(height * 0.25, width * 0.5);
        //    //System.Windows.Point Point3 = new System.Windows.Point(height, width);

        //    //System.Windows.Point Point2 = new System.Windows.Point( height * 0.5, width * 0.25);
        //    //System.Windows.Point Point3 = new System.Windows.Point( height * 0.5, width * 0.75);
        //    //System.Windows.Point Point4 = new System.Windows.Point( height * 0.5, width * 0.25);
        //    //System.Windows.Point Point5 = new System.Windows.Point(-height, width * 0.5);
        //    //System.Windows.Point Point6 = new System.Windows.Point( 0, width);

        //    double toppoint_center_x = height * 2;
        //    double toppoint_center_y = width / 2;

        //    double middlepoint_right_x = toppoint_center_x / 2;
        //    double middlepoint_right_y = toppoint_center_y / 4 * 3;

        //    double middlepoint_left_x = toppoint_center_x / 2;
        //    double middlepoint_left_y = toppoint_center_y / 4 * 1;

        //    System.Windows.Point Point00 = new System.Windows.Point(toppoint_center_y *3, toppoint_center_x);
        //    System.Windows.Point Point0 = new System.Windows.Point(-toppoint_center_y, toppoint_center_x);
        //    System.Windows.Point Point1 = new System.Windows.Point(0, 0);
        //    System.Windows.Point Point2 = new System.Windows.Point(toppoint_center_y, -toppoint_center_x);



        //    System.Windows.Point Point3 = new System.Windows.Point(-toppoint_center_y , toppoint_center_x / 3);



        //    System.Windows.Point Point4 = new System.Windows.Point(middlepoint_right_y, -middlepoint_right_x);
        //    System.Windows.Point Point5 = new System.Windows.Point(middlepoint_left_y, -middlepoint_left_x);



        //    //System.Windows.Point Point5 = new System.Windows.Point(middlepoint_left_y, -middlepoint_left_x);


        //    //System.Windows.Point Point2 = new System.Windows.Point(middlepoint_left_y, middlepoint_left_x);
        //    //System.Windows.Point Point3 = new System.Windows.Point(height * 0.75, width * 0.5);
        //    //System.Windows.Point Point4 = new System.Windows.Point(middlepoint_left_y, middlepoint_left_x);
        //    //System.Windows.Point Point5 = new System.Windows.Point(toppoint_center_y, toppoint_center_x);
        //    //System.Windows.Point Point6 = new System.Windows.Point(height, 0);
                        
        //    letter.Points.Add(Point0);
        //    letter.Points.Add(Point1);
        //    letter.Points.Add(Point2);            
        //    letter.Points.Add(Point00);
        //    letter.Points.Add(Point3);
        //    //letter.Points.Add(Point4);
        //    //letter.Points.Add(Point5);
        //    //letter.Points.Add(Point6);

        //    return letter;
        //}

            public double avoidNegativity(double value)
        {
            if (value < 0)
            {
                value = value * (-1);
            }

            return value;
        }

        public Polygon drawSimpleHourglass(double width, double height) 
        {
            Polygon pol = new Polygon();

            System.Windows.Point Point2 = new System.Windows.Point(0, 0);
            System.Windows.Point Point3 = new System.Windows.Point(-0.5 * width, 0.5*height);
            System.Windows.Point Point4 = new System.Windows.Point(0.5 * width, 0.5 * height);
            System.Windows.Point Point5 = new System.Windows.Point(0, 0);
            System.Windows.Point Point6 = new System.Windows.Point(-0.5 * width, -0.5 * height);
            System.Windows.Point Point7 = new System.Windows.Point(0.5 * width, -0.5 * height);
            System.Windows.Point Point8 = new System.Windows.Point(0, 0);

            pol.Points.Add(Point2);
            pol.Points.Add(Point2);
            pol.Points.Add(Point3);
            pol.Points.Add(Point4);
            pol.Points.Add(Point5);
            pol.Points.Add(Point6);
            pol.Points.Add(Point7);
            pol.Points.Add(Point8);

            return pol;
        }
            

        public Ellipse drawSimpleEllipse(double width, double height)
        {
            Ellipse ell = new Ellipse();

            ell.Height = avoidNegativity(height);
            ell.Width = avoidNegativity(width);

            return ell;
        }

        public Polygon drawSimpleLine(double width, double height)
        {
            Polygon pol = new Polygon();

            System.Windows.Point Point1 = new System.Windows.Point(0, 0);
            System.Windows.Point Point2 = new System.Windows.Point(0, 0);
            System.Windows.Point Point3 = new System.Windows.Point(0, 0);
            System.Windows.Point Point4 = new System.Windows.Point(0, 0);
            System.Windows.Point Point5 = new System.Windows.Point(0, 0);

            if (avoidNegativity(width) > avoidNegativity(height))
            {
                Point1 = new System.Windows.Point(0, 0);
                Point2 = new System.Windows.Point(width, 0);
                Point3 = new System.Windows.Point(width, 4);
                Point4 = new System.Windows.Point(0, 4);
                Point5 = new System.Windows.Point(0, 0);

            }
            else if (avoidNegativity(width) < avoidNegativity(height))
            {
                Point1 = new System.Windows.Point(0, 0);
                Point2 = new System.Windows.Point(0, height);
                Point3 = new System.Windows.Point(4, height);
                Point4 = new System.Windows.Point(4, 0);
                Point5 = new System.Windows.Point(0, 0);
            }
            else if (avoidNegativity(width) == avoidNegativity(height) && (width > 0 || height > 0))
            {
                Point1 = new System.Windows.Point(0, 2);
                Point2 = new System.Windows.Point(width, height);
                Point3 = new System.Windows.Point(width + 3, height - 2);
                Point4 = new System.Windows.Point(0 + 3, 0);
                Point5 = new System.Windows.Point(0, 2);
            }
            else if (avoidNegativity(width) == avoidNegativity(height) && (width < 0 || height < 0))
            {
                Point1 = new System.Windows.Point(width * (-1) - 3, 0);
                Point2 = new System.Windows.Point(0, height * (-1));
                Point3 = new System.Windows.Point(0, (height * (-1)) - 2);
                Point4 = new System.Windows.Point(0 - 3, (height * (-1)) - 2);
                Point5 = new System.Windows.Point((width * (-1)) - 3, 0);
            }

            pol.Points.Add(Point1);
            pol.Points.Add(Point2);
            pol.Points.Add(Point3);
            pol.Points.Add(Point4);
            pol.Points.Add(Point5);

            return pol;
        }

        public Rectangle drawSimpleRectangle(double width, double height)
        {
            Rectangle rec = new Rectangle();

            rec.Height = avoidNegativity(height);
            rec.Width = avoidNegativity(width);

            return rec;
        }

        public Polygon drawSimpleTriangle_equilateral(double width, double height)
        {
            Polygon pol = new Polygon();


            double factor = (width + height) / 3;



            double equilateral_factor = 0.8660254;



            System.Windows.Point Point1 = new System.Windows.Point(0, 0);
            System.Windows.Point Point2 = new System.Windows.Point(
                factor * 0.5, factor * equilateral_factor
                );
            System.Windows.Point Point3 = new System.Windows.Point(factor, 0);
            System.Windows.Point Point4 = new System.Windows.Point(0, 0);

            pol.Points.Add(Point4);
            pol.Points.Add(Point3);
            pol.Points.Add(Point2);
            pol.Points.Add(Point1);

            return pol;
        }

        public Polygon drawSimpleTriangle_isosceles(double width, double height)
        {
            Polygon pol = new Polygon();

            System.Windows.Point Point1 = new System.Windows.Point(0, 0);
            System.Windows.Point Point2 = new System.Windows.Point(width * 0.5, height);
            System.Windows.Point Point3 = new System.Windows.Point(width, 0);
            System.Windows.Point Point4 = new System.Windows.Point(0, 0);

            pol.Points.Add(Point4);
            pol.Points.Add(Point3);
            pol.Points.Add(Point2);
            pol.Points.Add(Point1);

            return pol;
        }

        public Polygon drawSimpleTriangle_rectangular(double width, double height)
        {
            Polygon pol = new Polygon();

            System.Windows.Point Point1 = new System.Windows.Point(0, 0);
            System.Windows.Point Point2 = new System.Windows.Point(0, height);
            System.Windows.Point Point3 = new System.Windows.Point(width, height);
            System.Windows.Point Point4 = new System.Windows.Point(0, 0);

            pol.Points.Add(Point4);
            pol.Points.Add(Point3);
            pol.Points.Add(Point2);
            pol.Points.Add(Point1);

            return pol;
        }
    }
}
