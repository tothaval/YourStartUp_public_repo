﻿/* YourStartUp text class for Notes class
 * 
 * Pur:         handling of language elements for the notes class
 * Toc:         2022 (august <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      kammel@posteo.de
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YourStartUp
{
    class NotesTexts
    {
        public string language { get; set; }

        public NotesTexts(string _language = "english")
        {
            language = _language;
        }

        public StringBuilder headline()
        {
            if (language == "english")
            {
                string value = "# headline";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }

        }
    }

}
