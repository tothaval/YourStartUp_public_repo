﻿/* YourStartUp UserInterfaceElement Main Window Menu  
 * 
 * Pur:         organizing main menu necessities
 * Int:         moveable menu interface
 * Toc:         2022 (may <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      kammel@posteo.de
 */

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für UIE_MainWindowMenuElement.xaml
    /// </summary>
    public partial class UIE_MainWindowMenuElement : UserControl
    {
        private MainWindow parent;

        #region globals
        List<UIE_CascadeButton> menu_element_list = new List<UIE_CascadeButton>();
        #endregion globals


        #region classes

        ConfigData config = new ConfigData();        
        MainWindowTexts texts = new MainWindowTexts();

        #endregion classes


        #region menu buttons

        // empty button
        #region empty button
        private UIE_CascadeButton createEmptyButton()
        {
            UIE_CascadeButton cb = new UIE_CascadeButton();
            //UIE_ImageElement ie; shutdown symbol poweronoff

            cb.changeIconTo_Text("");
            cb.uie_cascade_button.IsEnabled = false;

            double hei = config.btnHeight * 0.4;

            style_MenuElement(cb);

            cb.uie_cascade_button_border.Height = hei;            

            //cb.uie_cascade_button.Click += executeAddLinkButton_Click;

            menu_element_list.Add(cb);

            return cb;
        }
        #endregion empty button

        // link button
        #region link button
        private UIE_CascadeButton createAddLinkButton()
        {
            UIE_CascadeButton cb = new UIE_CascadeButton();
            //UIE_ImageElement ie; shutdown symbol poweronoff

            cb.changeIconTo_Text("text not written yet");
            cb.uie_cascade_button_border.ToolTip = "text not written yet";

            cb = style_MenuElement(cb);

            cb.uie_cascade_button.Click += executeAddLinkButton_Click;

            menu_element_list.Add(cb);

            return cb;
        }
        private void executeAddLinkButton_Click(object sender, RoutedEventArgs e)
        {
            processAddLinkButton_Click();

            e.Handled = true;
        }

        private void processAddLinkButton_Click()
        {

        }
        #endregion link button

        // info button
        #region info button
        private UIE_CascadeButton createInfoButton()
        {
            UIE_CascadeButton cb = new UIE_CascadeButton();
            //UIE_ImageElement ie; shutdown symbol poweronoff

            cb.changeIconTo_Text(texts.btnInfo_content().ToString());
            cb.uie_cascade_button_border.ToolTip = texts.btnInfo_toolTip().ToString();

            cb = style_MenuElement(cb);

            cb.uie_cascade_button.Click += executeInfoButton_Click;

            menu_element_list.Add(cb);

            return cb;
        }
        private void executeInfoButton_Click(object sender, RoutedEventArgs e)
        {
            processInfoButton_Click();

            e.Handled = true;
        }

        private void processInfoButton_Click()
        {
            Info info = new Info() { };

            info.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            info.Show();
        }
        #endregion info button

        // license button
        #region license button
        private UIE_CascadeButton createLicenseButton()
        {
            UIE_CascadeButton cb = new UIE_CascadeButton();
            //UIE_ImageElement ie; shutdown symbol poweronoff

            cb.changeIconTo_Text("license");
            cb.uie_cascade_button_border.ToolTip = texts.btnInfo_toolTip().ToString();

            cb = style_MenuElement(cb);

            cb.uie_cascade_button.Click += executeLicenseButton_Click;

            menu_element_list.Add(cb);

            return cb;
        }
        private void executeLicenseButton_Click(object sender, RoutedEventArgs e)
        {
            processLicenseButton_Click();

            e.Handled = true;
        }

        private void processLicenseButton_Click()
        {
            Info license = new Info() { }; // still not set on the terms

            license.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            license.Show();
        }
        #endregion license button

        // minimize button
        #region minimize button
        private UIE_CascadeButton createMinimizeButton()
        {
            UIE_CascadeButton cb = new UIE_CascadeButton();
            //UIE_ImageElement ie; shutdown symbol poweronoff
            TimerTexts tt = new TimerTexts();


            cb.changeIconTo_Text(tt.btnMinimize_content().ToString());
            cb.uie_cascade_button_border.ToolTip = tt.btnMinimize_toolTip().ToString();

            cb = style_MenuElement(cb);

            cb.uie_cascade_button.Click += executeMinimizeButton_Click;

            menu_element_list.Add(cb);

            return cb;
        }
        private void executeMinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            processMinimizeButton_Click();

            e.Handled = true;
        }

        private void processMinimizeButton_Click()
        {
            Application.Current.MainWindow.WindowState = WindowState.Minimized;
        }
        #endregion minimize button

        // notes button
        #region notes button
        private UIE_CascadeButton createNotesButton()
        {
            UIE_CascadeButton cb = new UIE_CascadeButton();
            //UIE_ImageElement ie; shutdown symbol poweronoff

            cb.changeIconTo_Text(texts.btnNotes_content().ToString());
            cb.uie_cascade_button_border.ToolTip = texts.btnNotes_toolTip().ToString();

            cb = style_MenuElement(cb);

            cb.uie_cascade_button.Click += executeNotesButton_Click;

            menu_element_list.Add(cb);

            return cb;
        }
        private void executeNotesButton_Click(object sender, RoutedEventArgs e)
        {
            processNotesButton_Click();

            e.Handled = true;
        }

        private void processNotesButton_Click()
        {
            Notes notes = new Notes() { };

            //notes.Owner = this;
            notes.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            notes.Show();
        }
        #endregion notes button

        // plus button
        #region plus button
        private UIE_CascadeButton createPlusButton()
        {
            UIE_CascadeButton cb = new UIE_CascadeButton();
            //UIE_ImageElement ie; shutdown symbol poweronoff

            cb.changeIconTo_Text(texts.btnAdd_content().ToString());
            cb.uie_cascade_button_border.ToolTip = texts.btnAdd_toolTip().ToString();

            cb = style_MenuElement(cb);

            cb.uie_cascade_button.Click += executePlusButton_Click;

            menu_element_list.Add(cb);

            return cb;
        }

        public void executePlusButton_Click(object sender, RoutedEventArgs e)
        {
            processPlusButton_Click();

            e.Handled = true;
        }

        private void processPlusButton_Click()
        {
            parent.MainWindowCanvas.Children.Add(parent.modul_SelectionBindingElement());
        }
        #endregion plus button

        // quit button
        #region quit button
        private UIE_CascadeButton createQuitButton()
        {
            UIE_CascadeButton cb = new UIE_CascadeButton();
            //UIE_ImageElement ie; shutdown symbol poweronoff

            cb.changeIconTo_Text(texts.btnQuit_content().ToString());
            cb.uie_cascade_button_border.ToolTip = texts.btnQuit_toolTip().ToString();

            cb = style_MenuElement(cb);

            cb.uie_cascade_button.Click += executeQuitButton_Click;

            menu_element_list.Add(cb);

            return cb;
        }

        private void executeQuitButton_Click(object sender, RoutedEventArgs e)
        {
            processQuitButton_Click();
        }
        private void processQuitButton_Click()
        {
            parent.mainWindow_Shutdown_processing();
        }
        #endregion quit button

        // options button
        #region option buttons
        private UIE_CascadeButton createOptionsButton()
        {
            UIE_CascadeButton cb = new UIE_CascadeButton();
            //UIE_ImageElement ie; shutdown symbol poweronoff

            cb.changeIconTo_Text(texts.btnSettings_content().ToString());
            cb.uie_cascade_button_border.ToolTip = texts.btnSettings_toolTip().ToString();

            cb = style_MenuElement(cb);

            cb.uie_cascade_button.Click += executeOptionsButton_Click;

            menu_element_list.Add(cb);

            return cb;
        }

        private void executeOptionsButton_Click(object sender, RoutedEventArgs e)
        {
            processOptionsButton_Click();

            e.Handled = true;
        }

        private void processOptionsButton_Click()
        {
            YourStartUp_Settings yourStartUp_Settings = new YourStartUp_Settings() { };

            config.mainWindowHeight = (int)Height;
            config.mainWindowWidth = (int)Width;

            config.saveSettings();

            yourStartUp_Settings.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            yourStartUp_Settings.Show();
        }
        #endregion options button

        // scetchboard button
        #region scetchboard button
        private UIE_CascadeButton createScetchboardButton()
        {
            UIE_CascadeButton cb = new UIE_CascadeButton();
            //UIE_ImageElement ie; shutdown symbol poweronoff

            cb.changeIconTo_Text(texts.btnScetchboard_content().ToString());
            cb.uie_cascade_button_border.ToolTip = texts.btnScetchboard_toolTip().ToString();

            cb = style_MenuElement(cb);

            cb.uie_cascade_button.Click += executeScetchboardButton_Click;

            menu_element_list.Add(cb);

            return cb;
        }

        private void executeScetchboardButton_Click(object sender, RoutedEventArgs e)
        {
            processScetchboardButton_Click();

            e.Handled = true;
        }

        private void processScetchboardButton_Click()
        {
            parent.MainWindowCanvas.Children.Add(parent.modul_ScetchboardElement());
        }
        #endregion scetchboard button

        // shutdown button
        #region shutdown button
        private UIE_CascadeButton createShutdownButton()
        {
            UIE_CascadeButton cb = new UIE_CascadeButton();
            //UIE_ImageElement ie; shutdown symbol poweronoff

            cb.changeIconTo_Text(texts.btnShutdown_content().ToString());
            cb.uie_cascade_button_border.ToolTip = texts.btnShutdown_toolTip().ToString();

            cb = style_MenuElement(cb);

            cb.uie_cascade_button.Click += executeShutdownButton_Click;

            menu_element_list.Add(cb);

            return cb;
        }

        private void executeShutdownButton_Click(object sender, RoutedEventArgs e)
        {
            processShutdownButton_Click();

            e.Handled = true;
        }

        private void processShutdownButton_Click()
        {
            string question = texts.shutdownQuestion().ToString();
            string title = texts.shutdownTitle().ToString();

            MessageBoxResult result = MessageBox.Show(question, title, MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                string command = "/C shutdown /p";
                Process.Start("cmd.exe", command);
            }
        }
        #endregion shutdown button

        // timer button
        #region timer button
        private UIE_CascadeButton createTimerButton()
        {
            UIE_CascadeButton cb = new UIE_CascadeButton();
            //UIE_ImageElement ie; shutdown symbol poweronoff

            cb.changeIconTo_Text(texts.btnTimer_content().ToString());
            cb.uie_cascade_button_border.ToolTip = texts.btnTimer_toolTip().ToString();

            cb = style_MenuElement(cb);

            cb.uie_cascade_button.Click += executeTimerButton_Click;

            menu_element_list.Add(cb);

            return cb;
        }

        private void executeTimerButton_Click(object sender, RoutedEventArgs e)
        {
            processTimerButton_Click();

            e.Handled = true;
        }
        private void processTimerButton_Click()
        {
            parent.MainWindowCanvas.Children.Add(parent.modul_TimerElement());
        }
        #endregion timer button

        #endregion menu buttons


        public void generate_Menu_Module()
        {
            wrapPanel.Children.Clear();

            //wrapPanel.Children.Add(());
            wrapPanel.Children.Add(createLicenseButton());

            wrapPanel.Children.Add(createEmptyButton());

            wrapPanel.Children.Add(createQuitButton());
            wrapPanel.Children.Add(createShutdownButton());
            wrapPanel.Children.Add(createMinimizeButton());

            wrapPanel.Children.Add(createEmptyButton());

            wrapPanel.Children.Add(createAddLinkButton());
            wrapPanel.Children.Add(createPlusButton());

            wrapPanel.Children.Add(createEmptyButton());

            wrapPanel.Children.Add(createNotesButton());                 
            wrapPanel.Children.Add(createScetchboardButton());            
            wrapPanel.Children.Add(createTimerButton());

            wrapPanel.Children.Add(createEmptyButton());

            wrapPanel.Children.Add(createOptionsButton());
            wrapPanel.Children.Add(createInfoButton());

            //for (int i = 0; i < menu_element_list.Count; i++)
            //{
            //    UIE_CascadeButton ucb = menu_element_list[i];

            //    ucb.uie_cascade_button_border.Height = config.btnHeight;
            //    ucb.uie_cascade_button_border.Width = config.btnWidth;

            //    wrapPanel.Children.Add(ucb);
            //}
        }


        // design
        #region design
        private void propertyUpdate_buttonStyle()
        {
            // normal style
            Resources.Remove("buttonColor");
            Resources.Remove("buttonFont");
            Resources.Remove("highlight");
            Resources.Remove("radius");

            Resources.Add("buttonColor", config.btnBackColor);
            Resources.Add("buttonFont", config.btnForeColor);
            Resources.Add("highlight", config.highlightColor);
            Resources.Add("radius", new CornerRadius(config.borderRadius));
        }
        private void styleMainMenuElement()
        {
            //wrapPanel.Background = new SolidColorBrush(Colors.Transparent);            

            // button map colors
            Background = new SolidColorBrush(Colors.Transparent);
            Foreground = config.foreColor;

            //windowChrome.CornerRadius = new CornerRadius(config.borderRadius);
            border.CornerRadius = new CornerRadius(config.borderRadius);
            border.BorderThickness = new Thickness(3);
            border.BorderBrush = config.foreColor;
            border.Background = config.backColor;
        }
        private UIE_CascadeButton style_MenuElement(UIE_CascadeButton ucb)
        {
            Style style = this.FindResource("buttonStyle") as Style;

            ucb.uie_cascade_button_canvas.Height = config.btnHeight;
            ucb.uie_cascade_button_canvas.Width = config.btnWidth;

            ucb.uie_cascade_button_border.CornerRadius = new CornerRadius(config.borderRadius);

            ucb.uie_cascade_button_border.Background = config.btnBackColor;
            ucb.uie_cascade_button.Background = new SolidColorBrush(Colors.Transparent);
            ucb.Background = new SolidColorBrush(Colors.Transparent);
            ucb.BorderBrush = config.btnForeColor;
            ucb.BorderThickness = new Thickness(1);

            ucb.uie_cascade_button.Style = style;

            return ucb;
        }
        #endregion design

        //constructor & load events
        #region element loading
        public UIE_MainWindowMenuElement()
        {
            InitializeComponent();

            parent = (MainWindow)Window.GetWindow(MainWindowMenuElement);
        }

        private void MainWindowMenuElement_Loaded(object sender, RoutedEventArgs e)
        {
            propertyUpdate_buttonStyle();

            styleMainMenuElement();

            generate_Menu_Module();

            parent = (MainWindow)Window.GetWindow(MainWindowMenuElement);
        }
        #endregion element loading
    }
}
/* YourStartUp UIE Main Window MenuElement
 * 
 * End of File
 */