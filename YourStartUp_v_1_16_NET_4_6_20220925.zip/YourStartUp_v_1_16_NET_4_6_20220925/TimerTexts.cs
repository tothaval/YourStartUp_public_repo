﻿/*  purpose: managing language elements of timer window
 * 
 * written: september 2022
 * by: stephan kammel
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YourStartUp
{
    class TimerTexts
    {
        public string language { get; set; }

        public TimerTexts(string _language = "english")
        {
            language = _language;
        }

        // content
        #region content
        public StringBuilder btnMinimize_content()
        {
            string value = "___";

            StringBuilder sb = new StringBuilder(value);

            return sb;
        }
        public StringBuilder btnTakeABreak_content()
        {
            if (language == "english")
            {
                string value = "\ntake a break\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }            
        }
        public StringBuilder endBreak_content()
        {
            if (language == "english")
            {
                string value = "\nend break\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        #endregion content

        // tooltips
        #region tooltips
        public StringBuilder breakStateFalse_toolTip()
        {
            if (language == "english")
            {
                string value = "break duration ::: time passed since timer start ::: local time";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder breakStateTrue_toolTip()
        {
            if (language == "english")
            {
                string value = "break number\n" +
                    "local time ::: time passed since timer start ::: time passed since last break";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder btnMinimize_toolTip()
        {
            if (language == "english")
            {
                string value = "hit button to minimize timer window";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder btnTakeABreak_toolTip()
        {
            if (language == "english")
            {
                string value = "hit button to halt above stopwatch\nhit again to keep it running again";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }


        public StringBuilder tbDate_toolTip()
        {
            if (language == "english")
            {
                string value = "date\n" +
                    "year-month-day";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder tbLastBreak_tooltip()
        {
            if (language == "english")
            {
                string value = "resetable stopwatch";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
}

        public StringBuilder tbSinceStart_tooltip()
        {
            if (language == "english")
            {
                string value = "stopwatch running since timer activation";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder tbTimer_toolTip()
        {
            if (language == "english")
            {
                string value = "local system time";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }       

        #endregion tooltips

    }
}
