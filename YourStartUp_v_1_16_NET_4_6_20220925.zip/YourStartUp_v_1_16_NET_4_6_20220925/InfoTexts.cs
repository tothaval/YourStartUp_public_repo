﻿/*  purpose: managing language elements of info window
 * 
 * written: september 2022
 * by: stephan kammel
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YourStartUp
{
    class InfoTexts
    {
        public string language { get; set; }

        public InfoTexts(string _language = "english")
        {
            language = _language;
        }


        public StringBuilder tbLicense()
        {
            // if(config.language == "english"){ value = "...";}

            if (language == "english")
            {
                string value = "license:\n" +
                    "No decision for a license has been made yet.\n" +
                    "Final terms may most likely cover:\n" +
                    "Free and unlimited use of this software.\n" +
                    "No guarantee, no support.\n" +
                    "Acknowledgement of authorship.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }

        }

        public StringBuilder tbManual()
        {
            if (language == "english")
            {
                string value = "\n" +
               "manual:\n" +
               "\n" +
               "button 'Quit':\n" +
               "close YourStartUp application and all of its sub windows\n" +
               "\n" +
               "button 'Shutdown':\n" +
               "a messagebox will show, upon confirmation, your\n" +
               "computer will shutdown, cancel to prevent shutdown\n" +
               "\n" +
               "click on that button\n" +
               "button 'add':\n" +
               "create new and empty button, click on button to bind\n" +
               "a file to it by selecting one via the file dialog window,\n" +
               "once confirmed, you may open that file with a single\n" +
               "click on that button\n" +
               "\n" +
               "button 'rename':\n" +
               "enter a different button state, it enables you to rename\n" +
               "buttons, double click will delete the previous text,\n" +
               "enter will confirm the new name, while the file binding\n" +
               "will not be affected unless you make it an url, beginning\n" +
               "its name with www, http, https\n" +
               "click button 'rename' again to leave rename state\n" +
               "\n" +
               "button 'reset':\n" +
               "enter a different button state, it enables you to reset\n" +
               "buttons if the button you click when in reset state\n" +
               "represents an url, you can enter a different url,\n" +
               "confirm with enter.\n" +
               "If the button represents any file or if it's blank(no text)\n" +
               "or unset(+), then a file dialog will appear upon click\n" +
               "click button 'reset' again to leave reset state\n" +
               "\n" +
               "button 'delete':\n" +
               "enter a different button state, it enables you to delete\n" +
               "buttons, just click on the buttons you wish to delete\n" +
               "click button 'delete' again to leave delete state\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }

        }

        public StringBuilder tbManual_()
        {
            if (language == "english")
            {
                string value = "\n" +
                "\n" +
                "\n" +
                "button 'settings':\n" +
                "a new window will open it allows you to change the\n" +
                "appearance of this app and most of its elements\n" +
                "\n" +
                "button 'quit':\n" +
                "quit this application and its open components\n" +
                "\n" +
                "button 'notes':\n" +
                "a new window will open, it offers the option to\n" +
                "write down notes, click on 'new note' to generate\n" +
                "a new note\n" +
                "\n" +
                "button 'timer':\n" +
                "a small window will open, it displays the current\n" +
                "time, as well as the time since activation and since\n" +
                "last break\n" +
                "\n" +
                "button 'scetchboard':\n" +
                "a window will open, it offers the option to draw a\n" +
                "mindmap or a scetch with basic drawing tools\n" +
                "\n" +
                "vertical buttons:\n" +
                "click them to hide parts of the interface,\n" +
                "click again to unhide\n" +
                "\n" +
                "drag click:\n" +
                "upon continous left click until you release the\n" +
                "mouse you can move the windows of this application,\n" +
                "the click area must not be a button nor a textbox\n" +
                "\n" +
                "right close:\n" +
                "all sub windows can be closed with a right click\n" +
                "caution: it is best to close them above the main\n" +
                "window area, because the right click menu of the\n" +
                "gui surface below will show\n" +
                "\n" +
                "drag'n'drop:\n" +
                "select multiple files and drag'n'drop them unto\n" +
                "the main window, a button per file will be generated.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder tbVersion()
        {
            if (language == "english")
            {
                string value = "ver: 1.1.6_NET4.6(still in developement)\n" +
                "dev: Stephan Kammel\n" +
                "toc: 2022\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }

            else
            {
                return new StringBuilder("language selection error");
            }
        }
    }
}
