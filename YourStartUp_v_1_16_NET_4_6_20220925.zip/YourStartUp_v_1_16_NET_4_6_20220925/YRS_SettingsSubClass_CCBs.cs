﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace YourStartUp
{
    class YRS_SettingsSubClass_CCBs
    {
        SettingsTexts text = new SettingsTexts();

        public YRS_SettingsSubClass_CCBs()
        {
            
        }


        public UIE_CheckboxCanvasButton CCB_backColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "ccb_backColor";
            ccb.uie_textblock.Text = text.rbGeneral_content().ToString();            
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbGeneral_tooltip();

            return ccb;
        }


        public UIE_CheckboxCanvasButton CCB_btnBackColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "ccb_btnBackColor";
            ccb.uie_textblock.Text = text.rbButtons_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbButtons_tooltip();

            return ccb;
        }


        public UIE_CheckboxCanvasButton CCB_btnForeColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "ccb_btnForeColor";
            ccb.uie_textblock.Text = text.rbButtons_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbButtons_tooltip();
            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_deleteStateBackColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "ccb_deleteStateBackColor";
            ccb.uie_textblock.Text = text.rbDelete_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbDelete_tooltip();

            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_deleteStateFontColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "ccb_deleteStateFontColor";
            ccb.uie_textblock.Text = text.rbDelete_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbDelete_tooltip();

            return ccb;
        }

        public UIE_CheckboxCanvasButton CCB_foreColor(SolidColorBrush brush_color)
        {
            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton(brush_color.Color);

            ccb.Name = "ccb_foreColor";
            ccb.uie_textblock.Text = text.rbGeneral_content().ToString();
            ccb.uie_ckbcnvbtn_button.ToolTip = text.rbGeneral_tooltip();

            return ccb;
        }
    }
}
