﻿/* YourStartUp settings tool  
 * 
 * Pur:         allows user to change some of the properties, like gui colors and button dimensions, font size etc.
 * Toc:         2022 (may <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      taranis.sk@gmail.com
 */
using Microsoft.Win32;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für YourStartUp_Settings.xaml
    /// </summary>
    public partial class YourStartUp_Settings : Window
    {
        ConfigData config = new ConfigData();
        MainWindow buttonMap;
        SettingsTexts settings = new SettingsTexts();

        bool loaded = false;

        // globals _public

        // globals _private
        #region globals _private
        private List<Button> btnList = new List<Button>();
        private List<CheckBox> chxList = new List<CheckBox>();
        private List<Label> lblList = new List<Label>();
        private List<Slider> sldList = new List<Slider>();
        private List<TextBox> txtList = new List<TextBox>();

        private Color color = new Color();
        private SolidColorBrush brush = new SolidColorBrush();

        private bool load = true;

        private byte default_red = 100;
        private byte default_green = 100;
        private byte default_blue = 100;
        private byte default_grey = 100;
        private double default_contrast = 0;
        private byte default_alpha = 255;

        private byte red = 0;
        private byte green = 0;
        private byte blue = 0;
        private byte grey = 0;
        private double contrast = 0;
        private byte alpha = 0;
        #endregion globals _private

        // constructors
        public YourStartUp_Settings()
        {
            InitializeComponent();
        }

        public YourStartUp_Settings(MainWindow _mainWindow)
        {
            buttonMap = _mainWindow;

            InitializeComponent();
        }

        // methods
        #region methods A-L

        // lists of ui control objects handling
        #region objectLists
        private void add_btnList()
        {
            btnList.Add(btnBackgroundImage);
            btnList.Add(btnChangeColor);
            btnList.Add(btnLeave);
            btnList.Add(btnRestoreDefault);
            btnList.Add(btnfont);
        }
        private void add_chxList()
        {
            chxList.Add(chxCoordinates);
            chxList.Add(chxHideDrives);
            chxList.Add(chxHideNotes);
            chxList.Add(chxHideScetchboard);
            chxList.Add(chxHideTimer);
            chxList.Add(chxTimerTopmost);
            chxList.Add(chxMoreOptions);
        }
        private void add_lblList()
        {
            lblList.Add(lblARGB);
            lblList.Add(lblARGBhex);
            lblList.Add(lblBorderRadius);
            lblList.Add(lblButtonHeight);
            lblList.Add(lblButtonSettings);
            lblList.Add(lblButtonWidth);
            lblList.Add(lblFont);
            lblList.Add(lblFontSettings);
            lblList.Add(lblFontSize);
            lblList.Add(lblRGB);
            lblList.Add(lblRGBhex);
            lblList.Add(lblSelectGuiElement);
        }
        private void add_sldList()
        {
            sldList.Add(sldAlpha);
            sldList.Add(sldBlue);
            sldList.Add(sldContrast);
            sldList.Add(sldGreen);
            sldList.Add(sldGrey);
            sldList.Add(sldRed);
        }
        private void add_txtList()
        {
            txtList.Add(txtARGB);
            txtList.Add(txtARGBhex);
            txtList.Add(txtBackgroundImage);
            txtList.Add(txtBorderRadius);
            txtList.Add(txtButtonHeight);
            txtList.Add(txtButtonWidth);
            txtList.Add(txtFont);
            txtList.Add(txtFontSize);
            txtList.Add(txtRGB);
            txtList.Add(txtRGBhex);
        }
        private void addUIElementsToLists()
        {
            add_btnList();

            add_chxList();

            add_lblList();

            add_sldList();

            add_txtList();
        }
        #endregion objectLists

        private string argb(byte alpha, byte red, byte green, byte blue)
        {
            return $"{alpha.ToString()},{red.ToString()},{green.ToString()},{blue.ToString()}";
        }
        private string argbhex(byte alpha, byte red, byte green, byte blue)
        {
            return $"{alpha.ToString("X")},{red.ToString("X")},{green.ToString("X")},{blue.ToString("X")}";
        }
        private void closeSettings()
        {
            setCheckBoxState();
            config.saveSettings();
            //buttonMap.loadUIConfig();
        }

        private Color colorCanvas(byte alpha, byte red, byte green, byte blue)
        {
            color.A = alpha;
            color.R = red;
            color.G = green;
            color.B = blue;

            brush.Color = color;
            canvas.Background = brush;

            colorChanged(alpha, red, green, blue);

            return color;
        }
        private void colorChanged(byte alpha, byte red, byte green, byte blue)
        {
            if (alpha == 255)
            {
                txtARGB.Text = argb(alpha, red, green, blue);
                txtARGBhex.Text = argbhex(alpha, red, green, blue);

                txtRGB.Text = rgb(red, green, blue);
                txtRGBhex.Text = rgbhex(red, green, blue);
            }
            if (alpha < 255)
            {
                txtARGB.Text = argb(alpha, red, green, blue);
                txtARGBhex.Text = argbhex(alpha, red, green, blue);

                txtRGB.Text = settings.alphaDeviation().ToString();
                txtRGBhex.Text = settings.alphaDeviation().ToString();
            }
        }
        private void convertARGB(string _color)
        {
            try
            {
                string[] _fragments = _color.Split(',');

                alpha = Byte.Parse(_fragments[0]);
                red = Byte.Parse(_fragments[1]);
                green = Byte.Parse(_fragments[2]);
                blue = Byte.Parse(_fragments[3]);

                sldAlpha.Value = alpha;
                sldRed.Value = red;
                sldGreen.Value = green;
                sldBlue.Value = blue;
            }
            catch (Exception)
            {
                MessageBox.Show(
                    settings.argbTextboxException().ToString()
                    );
            }
        }
        private void convertARGBhex(string _color)
        {
            try
            {
                string[] _fragments = _color.Split(',');

                alpha = Byte.Parse(_fragments[0], System.Globalization.NumberStyles.HexNumber);
                red = Byte.Parse(_fragments[1], System.Globalization.NumberStyles.HexNumber);
                green = Byte.Parse(_fragments[2], System.Globalization.NumberStyles.HexNumber);
                blue = Byte.Parse(_fragments[3], System.Globalization.NumberStyles.HexNumber);

                sldAlpha.Value = alpha;
                sldRed.Value = red;
                sldGreen.Value = green;
                sldBlue.Value = blue;
            }
            catch (Exception)
            {
                MessageBox.Show(
                    settings.argbTextboxHexValueException().ToString()
                    );
            }
        }
        private void convertRGB(string _color)
        {
            try
            {
                string[] _fragments = _color.Split(',');

                alpha = 255;
                red = Byte.Parse(_fragments[0]);
                green = Byte.Parse(_fragments[1]);
                blue = Byte.Parse(_fragments[2]);

                sldAlpha.Value = 255;
                sldRed.Value = red;
                sldGreen.Value = green;
                sldBlue.Value = blue;
            }
            catch (Exception)
            {
                MessageBox.Show(
                    settings.rgbTextboxException().ToString()
                    );
            }
        }
        private void convertRGBhex(string _color)
        {
            try
            {
                string[] _fragments = _color.Split(',');

                alpha = 255;
                red = Byte.Parse(_fragments[0], System.Globalization.NumberStyles.HexNumber);
                green = Byte.Parse(_fragments[1], System.Globalization.NumberStyles.HexNumber);
                blue = Byte.Parse(_fragments[2], System.Globalization.NumberStyles.HexNumber);

                sldAlpha.Value = 255;
                sldRed.Value = red;
                sldGreen.Value = green;
                sldBlue.Value = blue;
            }
            catch (Exception)
            {
                MessageBox.Show(
                    settings.rgbTextboxHexValueException().ToString()
                    );
            }
        }
        private void getCheckBoxState()
        {
            chxCoordinates.IsChecked = config.chxCoordinates;
            chxHideDrives.IsChecked = config.chxHideDrives;
            chxHideNotes.IsChecked = config.chxHideNotes;
            chxHideScetchboard.IsChecked = config.chxHideScetchboard;
            chxHideTimer.IsChecked = config.chxHideTimer;
            chxTimerTopmost.IsChecked = config.chxTimerTopmost;
            chxMoreOptions.IsChecked = config.chxMoreOptions;
        }

        private void hideCoordinates()
        {
            //if (chxCoordinates.IsChecked == false)
            //{
            //    buttonMap.tbMouseCoordinates.Visibility = Visibility.Hidden;
            //    config.chxCoordinates = false;
            //}
            //if (chxCoordinates.IsChecked == true)
            //{
            //    buttonMap.tbMouseCoordinates.Visibility = Visibility.Visible;
            //}
        }

        private void hideDrives()
        {
            //if (chxHideDrives.IsChecked == true)
            //{
            //    buttonMap.wrpDrives.Visibility = Visibility.Hidden;
            //    config.chxHideDrives = true;
            //}
            //if (chxHideDrives.IsChecked == false)
            //{
            //    buttonMap.wrpDrives.Visibility = Visibility.Visible;
            //}
        }
        private void hideNotes()
        {
            //if (chxHideNotes.IsChecked == true)
            //{
            //    buttonMap.btnNotes.Visibility = Visibility.Hidden;
            //    config.chxHideNotes = true;
            //}
            //if (chxHideNotes.IsChecked == false)
            //{
            //    buttonMap.btnNotes.Visibility = Visibility.Visible;
            //}
        }
        private void hideScetchboard()
        {
            //if (chxHideScetchboard.IsChecked == true)
            //{
            //    buttonMap.btnScetchboard.Visibility = Visibility.Hidden;
            //    config.chxHideScetchboard = true;
            //}
            //if (chxHideScetchboard.IsChecked == false)
            //{
            //    buttonMap.btnScetchboard.Visibility = Visibility.Visible;
            //}
        }
        private void hideTimer()
        {
            //if (chxHideTimer.IsChecked == true)
            //{
            //    buttonMap.btnTimer.Visibility = Visibility.Hidden;
            //    config.chxHideTimer = true;
            //}
            //if (chxHideTimer.IsChecked == false)
            //{
            //    buttonMap.btnTimer.Visibility = Visibility.Visible;
            //}
        }
        private void setTopmostStateOnTimer()
        {
            if (chxTimerTopmost.IsChecked == true)
            {              
                config.chxTimerTopmost = true;
            }
            if (chxTimerTopmost.IsChecked == false)
            {              
            }
        }


        public bool ccb_backcolor { get; set; }
        public bool ccb_btnBackColor { get; set; }
        public bool ccb_btnForeColor { get; set; }
        public bool ccb_deleteStateBackColor { get; set; }
        public bool ccb_deleteStateFontColor { get; set; }
        public bool ccb_forecolor { get; set; }
        public bool ccb_guiMinimizerBackColor { get; set; }
        public bool ccb_guiMinimizerFontColor { get; set; }
        public bool ccb_renameStateBackColor { get; set; }
        public bool ccb_renameStateFontColor { get; set; }
        public bool ccb_resetStateBackColor { get; set; }
        public bool ccb_resetStateFontColor { get; set; }
        public bool ccb_textboxBackColor { get; set; }
        public bool ccb_textboxFontColor { get; set; }


        public bool ccb_CanvasBackColor { get; set; }
        public bool ccb_CanvasMenuBackColor { get; set; }
        public bool ccb_SliderBackColor { get; set; }
        public bool ccb_HighlightColor { get; set; }


        private void initColorFeatureButtons()
        {
            sp_MainColors.Children.Clear();

            sp_MainColors.Orientation = Orientation.Vertical;

            YRS_SettingsSubClass_CCBs yrs;

            UIE_CheckboxCanvasButton ccb;

            // general back color button
            yrs = new YRS_SettingsSubClass_CCBs();
            ccb_backcolor = false;            
            ccb = yrs.CCB_backColor(config.backColor);            
            ccb.uie_ckbcnvbtn_button.Click += CCB_backColor_Click;
            sp_MainColors.Children.Add(ccb);

            // button back color button
            yrs = new YRS_SettingsSubClass_CCBs();
            ccb_btnBackColor = false;
            ccb = yrs.CCB_btnBackColor(config.btnBackColor);            
            ccb.uie_ckbcnvbtn_button.Click += CCB_btnBackColor_Click;
            sp_MainColors.Children.Add(ccb);


            // button font/fore color button
            yrs = new YRS_SettingsSubClass_CCBs();
            ccb_btnForeColor = false;
            ccb = yrs.CCB_btnForeColor(config.btnForeColor);            
            ccb.uie_ckbcnvbtn_button.Click += CCB_btnForeColor_Click;
            sp_MainColors.Children.Add(ccb);

            // deleteState back color button
            yrs = new YRS_SettingsSubClass_CCBs();
            ccb_deleteStateBackColor = false;
            ccb = yrs.CCB_deleteStateBackColor(config.deleteState);
            ccb.uie_ckbcnvbtn_button.Click += CCB_deleteStateBackColor_Click;
            sp_MainColors.Children.Add(ccb);

            // deleteState font/fore color button
            yrs = new YRS_SettingsSubClass_CCBs();
            ccb_deleteStateFontColor = false;
            ccb = yrs.CCB_deleteStateFontColor(config.deleteStateFont);
            ccb.uie_ckbcnvbtn_button.Click += CCB_deleteStateFontColor_Click;
            sp_MainColors.Children.Add(ccb);

            // general font/fore color button
            yrs = new YRS_SettingsSubClass_CCBs();
            ccb_forecolor = false;
            ccb = yrs.CCB_foreColor(config.foreColor);            
            ccb.uie_ckbcnvbtn_button.Click += CCB_foreColor_Click;
            sp_MainColors.Children.Add(ccb);

        }

        private void CCB_click_process(Button btn_, bool condition_, SolidColorBrush solidcolorbrush_)
        {
            UIE_CheckboxCanvasButton ccb_ = new UIE_CheckboxCanvasButton();

            ccb_.uie_ckbcnvbtn_button = btn_;

            if (condition_ == true)
            {
                ccb_.uie_ckbcnvbtn_button_border.Background = returnColor();
            }
            else if (condition_ == false)
            {
                brush = solidcolorbrush_;
                canvas.Background = brush;

                processColorDisplay(brush);
            }
        }


        // CCB clicks
        private void CCB_backColor_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;

            CCB_click_process(btn, ccb_backcolor, config.backColor);
        }

        private void CCB_btnBackColor_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;            

            CCB_click_process(btn, ccb_btnBackColor, config.btnBackColor);
        }

        private void CCB_btnForeColor_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;

            CCB_click_process(btn, ccb_btnForeColor, config.btnForeColor);
        }

        private void CCB_deleteStateBackColor_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;

            CCB_click_process(btn, ccb_deleteStateBackColor, config.deleteState);
        }

        private void CCB_deleteStateFontColor_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;

            CCB_click_process(btn, ccb_deleteStateFontColor, config.deleteStateFont);
        }
        private void CCB_foreColor_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;

            CCB_click_process(btn, ccb_forecolor, config.foreColor);
        }


        private void initUI()
        {
            uiSettings_Buttons();

            //uiSettings_Canvas();

            uiSettings_Checkboxes();

            uiSettings_Labels();

            //uiSettings_Sliders();

            uiSettings_Textboxes();

            Background = new SolidColorBrush(Colors.Transparent);
            Foreground = config.foreColor;
            FontFamily = config.font;
            FontSize = config.fontSize;

            border.CornerRadius = new CornerRadius(config.borderRadius);
            border.BorderThickness = new Thickness(3);
            border.BorderBrush = config.foreColor;
            border.Background = config.backColor;

            config = new ConfigData();

            initColorFeatureButtons();
        }
        private void loadConfig()
        {
            config.loadConfig();

            yrs_settings.Resources.Remove("buttonColor");
            yrs_settings.Resources.Remove("buttonFont");
            yrs_settings.Resources.Remove("highlight");
            yrs_settings.Resources.Remove("radius");

            yrs_settings.Resources.Add("buttonColor", config.btnBackColor);
            yrs_settings.Resources.Add("buttonFont", config.btnForeColor);
            yrs_settings.Resources.Add("highlight", config.highlightColor);
            yrs_settings.Resources.Add("radius", new CornerRadius(config.borderRadius));
        }
        private void loadLanguage()
        {
            // buttons
            loadLanguage_buttons();

            // checkboxes
            loadLanguage_checkboxes();

            // labels            
            loadLanguage_labels();

            // radiobuttons
            loadLanguage_radiobuttons();
        }
        private void loadLanguage_buttons()
        {
            btnBackgroundImage.Content = settings.btnBackgroundImage_content();
            btnBackgroundImage.ToolTip = settings.btnBackgroundImage_tooltip();

            btnChangeColor.Content = settings.btnChangeColor_content();
            btnChangeColor.ToolTip = settings.btnChangeColor_tooltip();

            btnfont.Content = settings.btnFont_content();
            btnfont.ToolTip = settings.btnFont_tooltip();

            btnLeave.Content = settings.btnLeave_content();
            btnLeave.ToolTip = settings.btnLeave_tooltip();

            btnRestoreDefault.Content = settings.btnRestoreDefault_content();
            btnRestoreDefault.ToolTip = settings.btnRestoreDefault_tooltip();
        }
        private void loadLanguage_checkboxes()
        {
            chxCoordinates.Content = settings.chxCoordinates_content();
            chxCoordinates.ToolTip = settings.chxCoordinates_tooltip();

            chxHideDrives.Content = settings.chxHideDrives_content();
            chxHideDrives.ToolTip = settings.chxHideDrives_tooltip();

            chxHideNotes.Content = settings.chxHideNotes_content();
            chxHideNotes.ToolTip = settings.chxHideNotes_tooltip();

            chxHideScetchboard.Content = settings.chxHideScetchboard_content();
            chxHideScetchboard.ToolTip = settings.chxHideScetchboard_tooltip();

            chxHideTimer.Content = settings.chxHideTimer_content();
            chxHideTimer.ToolTip = settings.chxHideTimer_tooltip();

            chxMoreOptions.Content = settings.chxMoreOptions_content();
            chxMoreOptions.ToolTip = settings.chxMoreOptions_tooltip();
        }
        private void loadLanguage_labels()
        {
            lblAlphaValue.ToolTip = settings.lblAlphaValue_tooltip();

            lblBlueValue.ToolTip = settings.lblBlueValue_tooltip();

            lblBorderRadius.Content = settings.lblBorderRadius_content();
            lblBorderRadius.ToolTip = settings.lblBorderRadius_tooltip();

            lblButtonHeight.Content = settings.lblButtonHeight_content();
            lblButtonHeight.ToolTip = settings.lblButtonHeight_tooltip();

            lblButtonSettings.Content = settings.lblButtonSettings_content();
            lblButtonSettings.ToolTip = settings.lblButtonSettings_tooltip();

            lblButtonWidth.Content = settings.lblButtonWidth_content();
            lblButtonWidth.ToolTip = settings.lblButtonWidth_tooltip();

            lblContrastValue.Content = settings.lblContrastValue_content();
            lblContrastValue.ToolTip = settings.lblContrastValue_tooltip();

            lblFont.Content = settings.lblFont_content();
            lblFont.ToolTip = settings.lblFont_tooltip();

            lblFontSettings.Content = settings.lblFontSettings_content();
            lblFontSettings.ToolTip = settings.lblFontSettings_tooltip();

            lblFontSize.Content = settings.lblFontSize_content();
            lblFontSize.ToolTip = settings.lblFontSize_tooltip();

            lblGreenValue.ToolTip = settings.lblGreenValue_tooltip();

            lblGreyValue.ToolTip = settings.lblGreyValue_tooltip();

            lblRedValue.ToolTip = settings.lblRedValue_tooltip();

            lblSelectGuiElement.Content = settings.lblSelectGuiElement_content();
            lblSelectGuiElement.ToolTip = settings.lblSelectGuiElement_tooltip();
        }
        private void loadLanguage_radiobuttons()
        {
            //rbBackground.Content = settings.rbBackground_content();
            //rbBackground.ToolTip = settings.rbBackground_tooltip();

            //rbButtons.Content = settings.rbButtons_content();
            //rbButtons.ToolTip = settings.rbButtons_tooltip();

            //rbCanvas.Content = settings.rbCanvas_content();
            //rbCanvas.ToolTip = settings.rbCanvas_tooltip();

            //rbCanvasMenu.Content = settings.rbCanvasMenu_content();
            //rbCanvasMenu.ToolTip = settings.rbCanvasMenu_tooltip();

            //rbDelete.Content = settings.rbDelete_content();
            //rbDelete.ToolTip = settings.rbDelete_tooltip();

            //rbFont.Content = settings.rbFont_content();
            //rbFont.ToolTip = settings.rbFont_tooltip();

            //rbGeneral.Content = settings.rbGeneral_content();
            //rbGeneral.ToolTip = settings.rbGeneral_tooltip();

            //rbHideGui.Content = settings.rbHideGui_content();
            //rbHideGui.ToolTip = settings.rbHideGui_tooltip();

            //rbHighlight.Content = settings.rbHighlight_content();
            //rbHighlight.ToolTip = settings.rbHighlight_tooltip();

            //rbRename.Content = settings.rbRename_content();
            //rbRename.ToolTip = settings.rbRename_tooltip();

            //rbReset.Content = settings.rbReset_content();
            //rbReset.ToolTip = settings.rbReset_tooltip();

            //rbSliders.Content = settings.rbSliders_content();
            //rbSliders.ToolTip = settings.rbSliders_tooltip();

            //rbTextboxes.Content = settings.rbTextboxes_content();
            //rbTextboxes.ToolTip = settings.rbTextboxes_tooltip();
        }
        #endregion methods A-L

        #region methods M-Z
        private void moreOptions()
        {
            if (chxMoreOptions.IsChecked == true)
            {
                grdOptions.Visibility = Visibility.Visible;
                Height = 725 + 120;
            }

            else
            {
                grdOptions.Visibility = Visibility.Hidden;
                Height = 725;
            }
        }
        private void processColorChange(string color)
        {
            if (color != "contrast")
            {
                if (color == "red")
                {
                    byte _red = Byte.Parse(lblRedValue.Content.ToString());
                    colorCanvas(alpha, _red, green, blue);
                }
                if (color == "green")
                {
                    byte _green = Byte.Parse(lblGreenValue.Content.ToString());
                    colorCanvas(alpha, red, _green, blue);
                }
                if (color == "blue")
                {
                    byte _blue = Byte.Parse(lblBlueValue.Content.ToString());
                    colorCanvas(alpha, red, green, _blue);
                }
                else
                {
                    colorCanvas(alpha, red, green, blue);
                }

            }
            else
            {
                colorCanvas(alpha, red, green, blue);
            }
        }

        private void processColorDisplay(SolidColorBrush brush)
        {
            color = brush.Color;

            alpha = brush.Color.A;
            blue = brush.Color.B;
            green = brush.Color.G;
            red = brush.Color.R;

            sldAlpha.Value = alpha;
            sldBlue.Value = blue;
            sldGreen.Value = green;
            sldRed.Value = red;
        }

        // radio button management
        #region radio button management
        private void rbCheck()
        {
            if (loaded == true)
            {
               
            }
        }
     
        private void rbCheck_rbHideGui(SolidColorBrush brush)
        {
            //if (rbBackground.IsChecked == true)
            //{
            //    brush = config.btnHideMenuColor;
            //    canvas.Background = brush;

            //    processColorDisplay(brush);
            //}

            //else if (rbFont.IsChecked == true)
            //{
            //    brush = config.btnHideMenuFont;
            //    canvas.Background = brush;

            //    processColorDisplay(brush);
            //}
        }
        private void rbCheck_rbRename(SolidColorBrush brush)
        {
            //if (rbBackground.IsChecked == true)
            //{
            //    brush = config.renameState;
            //    canvas.Background = brush;

            //    processColorDisplay(brush);
            //}

            //else if (rbFont.IsChecked == true)
            //{
            //    brush = config.renameStateFont;
            //    canvas.Background = brush;

            //    processColorDisplay(brush);
            //}
        }
        private void rbCheck_rbReset(SolidColorBrush brush)
        {
            //if (rbBackground.IsChecked == true)
            //{
            //    brush = config.resetState;
            //    canvas.Background = brush;

            //    processColorDisplay(brush);
            //}

            //else if (rbFont.IsChecked == true)
            //{
            //    brush = config.resetStateFont;
            //    canvas.Background = brush;

            //    processColorDisplay(brush);
            //}
        }
        private void rbCheck_rbTextboxes(SolidColorBrush brush)
        {
            //if (rbBackground.IsChecked == true)
            //{
            //    brush = config.textBox;
            //    canvas.Background = brush;

            //    processColorDisplay(brush);
            //}

            //else if (rbFont.IsChecked == true)
            //{
            //    brush = config.textBoxFont;
            //    canvas.Background = brush;

            //    processColorDisplay(brush);
            //}
        }
        private void rbCheckSpecialOptions()
        {
            //if (rbCanvas.IsChecked == true)
            //{
            //    rbCheckSpecialOptions_rbCanvas();
            //}

            //if (rbCanvasMenu.IsChecked == true)
            //{
            //    rbCheckSpecialOptions_rbCanvasMenu();
            //}

            //if (rbHighlight.IsChecked == true)
            //{
            //    rbCheckSpecialOptions_rbHighlight();
            //}

            //if (rbSliders.IsChecked == true)
            //{
            //    rbCheckSpecialOptions_rbSliders();
            //}
        }
        //private void rbCheckSpecialOptions_rbCanvas()
        //{
        //    brush = config.canvasColor;
        //    canvas.Background = brush;

        //    processColorDisplay(brush);
        //}
        //private void rbCheckSpecialOptions_rbCanvasMenu()
        //{
        //    brush = config.canvasMenuColor;
        //    canvas.Background = brush;

        //    processColorDisplay(brush);
        //}
        //private void rbCheckSpecialOptions_rbHighlight()
        //{
        //    brush = config.highlightColor;
        //    canvas.Background = brush;

        //    processColorDisplay(brush);
        //}
        //private void rbCheckSpecialOptions_rbSliders()
        //{
        //    brush = config.sliderBackground;
        //    canvas.Background = brush;

        //    processColorDisplay(brush);
        //}
        #endregion radio button management


        private SolidColorBrush returnColor()
        {
            return new SolidColorBrush(color);
        }
        private string rgb(byte red, byte green, byte blue)
        {
            return $"{red.ToString()},{green.ToString()},{blue.ToString()}";
        }
        private string rgbhex(byte red, byte green, byte blue)
        {
            return $"{red.ToString("X")},{green.ToString("X")},{blue.ToString("X")}";
        }


        // color customization handling
        #region save color choices
        private void saveColorChoice()
        {
            if (loaded == true)
            {
                //brush = returnColor();

                //if (rbButtons.IsChecked == true)
                //{
                //    saveColorChoice_rbButtons();
                //}

                //else if (rbDelete.IsChecked == true)
                //{
                //    saveColorChoice_deleteState();
                //}

                //else if (rbGeneral.IsChecked == true)
                //{
                //    saveColorChoice_rbGeneral();
                //}

                //else if (rbHideGui.IsChecked == true)
                //{
                //    saveColorChoice_rbHideGui();
                //}

                //else if (rbRename.IsChecked == true)
                //{
                //    saveColorChoice_rbRename();
                //}

                //else if (rbReset.IsChecked == true)
                //{
                //    saveColorChoice_rbReset();
                //}

                //else if (rbTextboxes.IsChecked == true)
                //{
                //    saveColorChoice_rbTextBoxes();
                //}
            }
        }

        private void saveSpecialColors()
        {
            //if (rbCanvas.IsChecked == true)
            //{
            //    saveSpecialColors_rbCanvas();
            //}

            //else if (rbCanvasMenu.IsChecked == true)
            //{
            //    saveSpecialColors_rbCanvasMenu();
            //}

            //else if (rbHighlight.IsChecked == true)
            //{
            //    saveSpecialColors_rbHighlight();
            //}

            //else if (rbSliders.IsChecked == true)
            //{
            //    saveSpecialColors_rbSliders();
            //}
        }
        private void saveSpecialColors_rbCanvas()
        {
            config.canvasColor = brush;
            //rbCanvas.IsChecked = false;
        }

        private void saveSpecialColors_rbCanvasMenu()
        {
            config.canvasMenuColor = brush;
            //rbCanvasMenu.IsChecked = false;
        }
        private void saveSpecialColors_rbHighlight()
        {
            config.canvasColor = brush;
            //rbHighlight.IsChecked = false;
        }
        private void saveSpecialColors_rbSliders()
        {
            config.sliderBackground = brush;
            //rbSliders.IsChecked = false;
        }
        #endregion save color choices

        // manage checkbox states
        #region checkbox mangement
        private void setCheckBoxState()
        {
            // coordinates and drives
            setCheckBoxState_chxCoordinates();

            // hide notes
            setCheckBoxState_chxHideNotes();

            // hide scetchboard
            setCheckBoxState_chxHideScetchboard();

            // hide timer
            setCheckBoxState_chxHideTimer();

            setCheckBoxState_chxTimerTopmost();

            // more options
            setCheckBox_chxMoreOptions();
        }
        private void setCheckBoxState_chxCoordinates()
        {
            // coordinates and drives
            if (chxCoordinates.IsChecked == true)
            {
                config.chxCoordinates = true;
            }
            if (chxHideDrives.IsChecked == false)
            {
                config.chxHideDrives = false;
            }
        }
        private void setCheckBoxState_chxHideNotes()
        {
            // hide notes
            if (chxHideNotes.IsChecked == true)
            {
                config.chxHideNotes = true;
            }
            if (chxHideNotes.IsChecked == false)
            {
                config.chxHideNotes = false;
            }
        }
        private void setCheckBoxState_chxHideScetchboard()
        {
            // hide scetchboard
            if (chxHideScetchboard.IsChecked == true)
            {
                config.chxHideScetchboard = true;
            }
            if (chxHideScetchboard.IsChecked == false)
            {
                config.chxHideScetchboard = false;
            }
        }
        private void setCheckBoxState_chxHideTimer()
        {
            // hide timer
            if (chxHideTimer.IsChecked == true)
            {
                config.chxHideTimer = true;
            }
            if (chxHideTimer.IsChecked == false)
            {
                config.chxHideTimer = false;
            }
        }
        private void setCheckBox_chxMoreOptions()
        {
            // more options
            if (chxMoreOptions.IsChecked == true)
            {
                config.chxMoreOptions = true;
            }
            if (chxMoreOptions.IsChecked == false)
            {
                config.chxMoreOptions = false;
            }
        }
        private void setCheckBoxState_chxTimerTopmost()
        {
            // hide timer
            if (chxTimerTopmost.IsChecked == true)
            {
                config.chxTimerTopmost = true;
            }
            if (chxTimerTopmost.IsChecked == false)
            {
                config.chxTimerTopmost = false;
            }
        }
        #endregion checkbox mangement


        // button ui configuration
        #region button ui configuration
        private void uiSettings_btnBackgroundImage(Style _style)
        {
            btnBackgroundImage.Background = new SolidColorBrush(Colors.Transparent);
            btnBackgroundImage.Foreground = config.btnForeColor;

            brdBtnBackgroundImage.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnBackgroundImage.BorderThickness = new Thickness(1);
            brdBtnBackgroundImage.BorderBrush = config.btnForeColor;
            brdBtnBackgroundImage.Background = config.btnBackColor;

            btnBackgroundImage.Style = _style;
        }

        private void uiSettings_btnChangeColor(Style _style)
        {
            btnChangeColor.Background = new SolidColorBrush(Colors.Transparent);
            btnChangeColor.Foreground = config.btnForeColor;

            brdBtnChangeColor.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnChangeColor.BorderThickness = new Thickness(1);
            brdBtnChangeColor.BorderBrush = config.btnForeColor;
            brdBtnChangeColor.Background = config.btnBackColor;

            btnChangeColor.Style = _style;
        }

        private void uiSettings_btnfont(Style _style)
        {
            btnfont.Background = new SolidColorBrush(Colors.Transparent);
            btnfont.Foreground = config.btnForeColor;

            brdBtnfont.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnfont.BorderThickness = new Thickness(1);
            brdBtnfont.BorderBrush = config.btnForeColor;
            brdBtnfont.Background = config.btnBackColor;

            btnfont.Style = _style;
        }
        private void uiSettings_btnLeave(Style _style)
        {
            btnLeave.Background = new SolidColorBrush(Colors.Transparent);
            btnLeave.Foreground = config.btnForeColor;

            brdBtnLeave.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnLeave.BorderThickness = new Thickness(1);
            brdBtnLeave.BorderBrush = config.btnForeColor;
            brdBtnLeave.Background = config.btnBackColor;

            btnLeave.Style = _style;
        }

        private void uiSettings_btnRestoreDefault(Style _style)
        {
            btnRestoreDefault.Background = new SolidColorBrush(Colors.Transparent);
            btnRestoreDefault.Foreground = config.btnForeColor;

            brdBtnRestoreDefault.CornerRadius = new CornerRadius(config.borderRadius);
            brdBtnRestoreDefault.BorderThickness = new Thickness(1);
            brdBtnRestoreDefault.BorderBrush = config.btnForeColor;
            brdBtnRestoreDefault.Background = config.btnBackColor;

            btnRestoreDefault.Style = _style;
        }
        private void uiSettings_Buttons()
        {

            Style style = this.FindResource("buttonStyle") as Style;

            for (int i = 0; i < btnList.Count; i++)
            {
                btnList[i].Foreground = config.btnForeColor;
                btnList[i].FontFamily = config.font;
                btnList[i].FontSize = config.fontSize;
            }

            // background image button
            uiSettings_btnBackgroundImage(style);

            // color change button
            uiSettings_btnChangeColor(style);

            // font change button
            uiSettings_btnfont(style);

            // leave button
            uiSettings_btnLeave(style);

            // restore defaults button
            uiSettings_btnRestoreDefault(style);
        }
        #endregion button ui configuration


        // other ui configuration
        #region other ui controls configuration
        private void uiSettings_Checkboxes()
        {

            for (int i = 0; i < chxList.Count; i++)
            {
                chxList[i].Background = config.foreColor;
                chxList[i].Foreground = config.foreColor;
                chxList[i].BorderBrush = config.foreColor;
                chxList[i].FontFamily = config.font;
                chxList[i].FontSize = config.fontSize;
                chxList[i].IsChecked = false;
            }
            getCheckBoxState();
        }

        private void uiSettings_Canvas()
        {
            color = colorCanvas(default_alpha, default_red, default_green, default_blue);

            txtRGB.Text = rgb(default_red, default_green, default_blue);
            txtRGBhex.Text = rgbhex(default_red, default_green, default_blue);

            txtARGB.Text = argb(default_alpha, default_red, default_green, default_blue);
            txtARGBhex.Text = argbhex(default_alpha, default_red, default_green, default_blue);
        }

        private void uiSettings_Labels()
        {
            for (int i = 0; i < lblList.Count; i++)
            {
                lblList[i].Background = config.backColor;
                lblList[i].Foreground = config.foreColor;
                lblList[i].FontFamily = config.font;
                lblList[i].FontSize = config.fontSize;
            }
        }

        private void uiSettings_Radiobuttons()
        {
            //if (cbxGuiElements.Items.Count == 0)
            //{
            //    cbxGuiElements.Items.Add(settings.background());
            //    cbxGuiElements.Items.Add(settings.button_background());
            //    cbxGuiElements.Items.Add(settings.button_font());
            //    cbxGuiElements.Items.Add(settings.delete_font());
            //    cbxGuiElements.Items.Add(settings.delete_state());
            //    cbxGuiElements.Items.Add(settings.font());
            //    cbxGuiElements.Items.Add(settings.hideGuiButtons_background());
            //    cbxGuiElements.Items.Add(settings.hideGuiButtons_font());
            //    cbxGuiElements.Items.Add(settings.rename_font());
            //    cbxGuiElements.Items.Add(settings.rename_state());
            //    cbxGuiElements.Items.Add(settings.reset_font());
            //    cbxGuiElements.Items.Add(settings.reset_state());
            //    cbxGuiElements.Items.Add(settings.sliders());
            //    cbxGuiElements.Items.Add(settings.textbox_background());
            //    cbxGuiElements.Items.Add(settings.textbox_font());
            //}

            //cbxGuiElements.FontFamily = config.font;
            //cbxGuiElements.FontSize = config.fontSize;
        }
        private void uiSettings_Sliders()
        {
            // adjust  RGB slider
            sldContrast.Value = default_contrast;
            sldContrast.Background = config.sliderBackground;
            contrast = default_contrast;

            // slider alpha
            sldAlpha.Value = default_alpha;
            sldAlpha.Background = config.sliderBackground;
            alpha = default_alpha;
            lblAlphaValue.Content = alpha;
            lblAlphaValue.FontFamily = config.font;
            lblAlphaValue.FontSize = config.fontSize;

            // slider blue
            sldBlue.Value = default_blue;
            sldBlue.Background = config.sliderBackground;
            blue = default_blue;
            lblBlueValue.Content = blue;
            lblBlueValue.FontFamily = config.font;
            lblBlueValue.FontSize = config.fontSize;

            // slider green
            sldGreen.Value = default_green;
            sldGreen.Background = config.sliderBackground;
            green = default_green;
            lblGreenValue.Content = green;
            lblGreenValue.FontFamily = config.font;
            lblGreenValue.FontSize = config.fontSize;

            // slider grey
            sldGrey.Value = default_grey;
            sldGrey.Background = config.sliderBackground;
            grey = default_grey;
            lblGreyValue.Content = grey;
            lblGreyValue.FontFamily = config.font;
            lblGreyValue.FontSize = config.fontSize;

            // slider red
            sldRed.Value = default_red;
            sldRed.Background = config.sliderBackground;
            red = default_red;
            lblRedValue.Content = red;
            lblRedValue.FontFamily = config.font;
            lblRedValue.FontSize = config.fontSize;
        }

        private void uiSettings_Textboxes()
        {
            txtBackgroundImage.Text = System.IO.Path.GetFileName(config.imageFilePath);
            txtBackgroundImage.ToolTip = settings.txtBackgroundImage_tooltip();

            txtBorderRadius.Text = config.borderRadius.ToString();
            txtButtonHeight.Text = config.btnHeight.ToString();
            txtButtonWidth.Text = config.btnWidth.ToString();

            txtFontSize.Text = config.fontSize.ToString();
            txtFont.Text = config.font.ToString();

            for (int i = 0; i < txtList.Count; i++)
            {
                txtList[i].Background = config.textBox;
                txtList[i].Foreground = config.textBoxFont;
                txtList[i].FontFamily = config.font;
                txtList[i].FontSize = config.fontSize;
            }
        }
        #endregion other ui controls configuration
        #endregion M-Z


        // events
        #region button events
        private void btnBackgroundImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog setImage = new OpenFileDialog();
            string imageFilename;
            string imageFilepath;
            setImage.InitialDirectory = Environment.GetEnvironmentVariable("userdir");
            setImage.Filter = "PNG (*.png)|*.png|" +
                              "JPG (*.jpg)|*.jpg|" +
                              "JPEG (*.jpeg)|*.jpeg|" +
                              "All files (*.*)|*.*";
            setImage.FilterIndex = 1;
            setImage.RestoreDirectory = true;

            if (setImage.ShowDialog() == true)
            {
                imageFilename = setImage.FileName.ToString();
                imageFilepath = System.IO.Path.GetFileName(imageFilename);

                txtBackgroundImage.Text = imageFilepath;
                txtBackgroundImage.ToolTip = imageFilename;

                config.imageFilePath = imageFilename;

                config.saveSettings();

                //buttonMap.loadUIConfig();
            }
        }
        private void btnChangeColor_Click(object sender, RoutedEventArgs e)
        {
            saveColorChoice();
            saveSpecialColors();
            config.saveSettings();


            //processCbxGuiElements(cbxGuiElements.Text, "-");
            initUI();
        }
        private void btnLeave_Click(object sender, RoutedEventArgs e)
        {
            closeSettings();

            Close();
        }
        private void btnRestoreDefault_Click(object sender, RoutedEventArgs e)
        {
            default_red = 100;
            default_green = 100;
            default_blue = 100;
            default_grey = 100;
            default_contrast = 0;
            default_alpha = 255;

            red = 100;
            green = 100;
            blue = 100;
            grey = 100;
            contrast = 0;
            alpha = 100;

            config.resetDefaults();
            config.saveSettings();
            //buttonMap.loadUIConfig();

            initUI();
        }
        private void btnfont_Click(object sender, RoutedEventArgs e)
        {
            if (txtFont.Text != "")
            {
                config.font = new FontFamily(txtFont.Text);
                config.fontSize = Int32.Parse(txtFontSize.Text);

                initUI();
            }
        }
        #endregion button events

        #region checkbox events
        private void chxCoordinates_Checked(object sender, RoutedEventArgs e)
        {
            hideCoordinates();
        }

        private void chxCoordinates_Click(object sender, RoutedEventArgs e)
        {
            hideCoordinates();
        }
        private void chxHideDrives_Checked(object sender, RoutedEventArgs e)
        {
            hideDrives();
        }

        private void chxHideDrives_Click(object sender, RoutedEventArgs e)
        {
            hideDrives();
        }

        private void chxHideNotes_Checked(object sender, RoutedEventArgs e)
        {
            hideNotes();
        }

        private void chxHideNotes_Click(object sender, RoutedEventArgs e)
        {
            hideNotes();
        }

        private void chxHideScetchboard_Checked(object sender, RoutedEventArgs e)
        {
            hideScetchboard();
        }

        private void chxHideScetchboard_Click(object sender, RoutedEventArgs e)
        {
            hideScetchboard();
        }

        private void chxHideTimer_Checked(object sender, RoutedEventArgs e)
        {
            hideTimer();
        }

        private void chxHideTimer_Click(object sender, RoutedEventArgs e)
        {
            hideTimer();
        }

        private void chxTimerTopmost_Checked(object sender, RoutedEventArgs e)
        {
            setTopmostStateOnTimer();
        }

        private void chxTimerTopmost_Click(object sender, RoutedEventArgs e)
        {
            setTopmostStateOnTimer();
        }
        
        private void chxMoreOptions_Checked(object sender, RoutedEventArgs e)
        {
            moreOptions();
        }
        private void chxMoreOptions_Click(object sender, RoutedEventArgs e)
        {
            moreOptions();
        }
        #endregion checkbox events

        #region combobox events
        // empty
        #endregion combobox events

        #region radiobutton events
        private void rbBackground_checked(object sender, RoutedEventArgs e)
        {
            rbCheck();
        }
        private void rbFont_checked(object sender, RoutedEventArgs e)
        {
            rbCheck();
        }
        private void rbGeneral_checked(object sender, RoutedEventArgs e)
        {
            rbCheck();
        }
        private void rbHideGui_checked(object sender, RoutedEventArgs e)
        {
            rbCheck();
        }
        private void rbHighlight_checked(object sender, RoutedEventArgs e)
        {
            rbCheckSpecialOptions();
        }
        private void rbButtons_checked(object sender, RoutedEventArgs e)
        {
            rbCheck();
        }
        private void rbDelete_checked(object sender, RoutedEventArgs e)
        {
            rbCheck();
        }
        private void rbRename_checked(object sender, RoutedEventArgs e)
        {
            rbCheck();
        }
        private void rbReset_checked(object sender, RoutedEventArgs e)
        {
            rbCheck();
        }
        private void rbSliders_checked(object sender, RoutedEventArgs e)
        {
            rbCheckSpecialOptions();
        }
        private void rbTextboxes_checked(object sender, RoutedEventArgs e)
        {
            rbCheck();
        }

        #endregion radiobutton events

        #region slider events
        private void sldAlpha_MouseEnter(object sender, MouseEventArgs e)
        {
            sldAlpha.Background = new SolidColorBrush(Color.FromArgb(100, 238, 221, 136));
        }
        private void sldAlpha_MouseLeave(object sender, MouseEventArgs e)
        {
            sldAlpha.Background = config.sliderBackground;
        }
        private void sldAlpha_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (load == false)
            {
                var sld_alpha = sender as Slider;

                alpha = (byte)sld_alpha.Value;
                colorCanvas(alpha, red, green, blue);
                lblAlphaValue.Content = alpha.ToString();
            }
        }
        private void sldBlue_MouseEnter(object sender, MouseEventArgs e)
        {
            sldBlue.Background = new SolidColorBrush(Color.FromArgb(100, 100, 100, 255));
        }
        private void sldBlue_MouseLeave(object sender, MouseEventArgs e)
        {
            sldBlue.Background = config.sliderBackground;
        }
        private void sldBlue_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (load == false)
            {
                var sld_blue = sender as Slider;

                blue = (byte)sld_blue.Value;

                lblBlueValue.Content = blue.ToString();

                processColorChange("blue");
            }
        }
        private void sldContrast_MouseEnter(object sender, MouseEventArgs e)
        {
            sldContrast.Background = new SolidColorBrush(Color.FromArgb(150, 0, 0, 0));
        }
        private void sldContrast_MouseLeave(object sender, MouseEventArgs e)
        {
            sldContrast.Background = config.sliderBackground;
        }
        private void sldContrast_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (load == false)
            {
                double _contrast;

                var sld_contrast = sender as Slider;
                double lblValue = contrast;

                _contrast = sld_contrast.Value;

                int _red, _green, _blue;
                _red = (int)(red + contrast);
                _green = (int)(green + contrast);
                _blue = (int)(blue + contrast);

                lblRedValue.Content = _red;
                lblGreenValue.Content = _green;
                lblBlueValue.Content = _blue;

                contrast = _contrast;

                if (sldContrast.Value > lblValue)
                {
                    sldRed.Value += 1;
                    sldGreen.Value += 1;
                    sldBlue.Value += 1;
                }
                else
                {
                    sldRed.Value -= 1;
                    sldGreen.Value -= 1;
                    sldBlue.Value -= 1;
                }

                processColorChange("contrast");

                //lblContrastValue.Content = contrast.ToString();
            }
        }
        private void sldGreen_MouseEnter(object sender, MouseEventArgs e)
        {
            sldGreen.Background = new SolidColorBrush(Color.FromArgb(100, 100, 255, 100));
        }
        private void sldGreen_MouseLeave(object sender, MouseEventArgs e)
        {
            sldGreen.Background = config.sliderBackground;
        }
        private void sldGreen_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (load == false)
            {
                var sld_green = sender as Slider;

                green = (byte)sld_green.Value;
                lblGreenValue.Content = green.ToString();

                processColorChange("green");
            }
        }
        private void sldGrey_MouseEnter(object sender, MouseEventArgs e)
        {
            sldGrey.Background = new SolidColorBrush(Color.FromArgb(50, 100, 100, 100));
        }
        private void sldGrey_MouseLeave(object sender, MouseEventArgs e)
        {
            sldGrey.Background = config.sliderBackground;
        }
        private void sldGrey_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (load == false)
            {
                var sld_grey = sender as Slider;

                grey = (byte)sld_grey.Value;

                lblGreyValue.Content = grey.ToString();

                sldRed.Value = grey;
                sldGreen.Value = grey;
                sldBlue.Value = grey;

                colorCanvas(alpha, grey, grey, grey);
                lblGreyValue.Content = grey.ToString();
            }
        }
        private void sldRed_MouseEnter(object sender, MouseEventArgs e)
        {
            sldRed.Background = new SolidColorBrush(Color.FromArgb(100, 255, 100, 100));
        }
        private void sldRed_MouseLeave(object sender, MouseEventArgs e)
        {
            sldRed.Background = config.sliderBackground;
        }
        private void sldRed_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (load == false)
            {
                var sld_red = sender as Slider;
                red = (byte)sld_red.Value;
                lblRedValue.Content = red.ToString();

                processColorChange("red");
            }
        }
        #endregion slider events

        #region textbox events
        private void txtARGB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                convertARGB(txtARGB.Text);
            }
        }
        private void txtARGBhex_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                convertARGBhex(txtARGBhex.Text);
            }
        }
        private void txtBackgroundImage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                string imagePath = txtBackgroundImage.Text;
                txtBackgroundImage.ToolTip = imagePath;
                config.imageFilePath = imagePath;

                if (!File.Exists(config.imageFilePath))
                {
                    config.imageFilePath = "-";
                }

                Keyboard.ClearFocus();

                config.saveSettings();

                //buttonMap.loadUIConfig();
            }
        }
        private void txtBorderRadius_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                int result;
                bool success = Int32.TryParse(txtBorderRadius.Text, out result);
                if (success)
                {
                    config.borderRadius = result;
                }
                Keyboard.ClearFocus();
            }
        }
        private void txtButtonHeight_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                int result;
                bool success = Int32.TryParse(txtButtonHeight.Text, out result);
                if (success)
                {
                    config.btnHeight = result;
                }
                Keyboard.ClearFocus();
            }
        }
        private void txtButtonWidth_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.Key == Key.Enter)
            {
                int result;
                bool success = Int32.TryParse(txtButtonWidth.Text, out result);
                if (success)
                {
                    config.btnWidth = result;
                    txtButtonHeight.Focus();
                }
            }
        }
        private void txtFont_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (txtFont.Text != "")
                {
                    FontFamily font = new FontFamily(txtFont.Text);
                    config.font = font;
                    txtFontSize.Focus();
                }
                //Keyboard.ClearFocus();
            }
        }
        private void txtFontSize_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                int result;
                bool success = Int32.TryParse(txtFontSize.Text, out result);
                if (success)
                {
                    config.fontSize = result;
                }
                Keyboard.ClearFocus();
            }
        }
        private void txtRGB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                convertRGB(txtRGB.Text);
                Keyboard.ClearFocus();
            }
        }
        private void txtRGBhex_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                convertRGBhex(txtRGBhex.Text);
                Keyboard.ClearFocus();
            }
        }
        #endregion textbox events

        #region yrs_settings events
        private void yrs_settings_Loaded(object sender, RoutedEventArgs e)
        {
            uiSettings_Canvas();
            uiSettings_Sliders();

            loadConfig();
            loadLanguage();

            addUIElementsToLists();
            initUI();

            load = false;
            loaded = true;
        }
        private void yrs_settings_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {

            int result_radius;
            bool success_radius = Int32.TryParse(txtBorderRadius.Text, out result_radius);
            if (success_radius)
            {
                config.borderRadius = result_radius;
            }

            int result_height;
            bool success_height = Int32.TryParse(txtButtonHeight.Text, out result_height);
            if (success_height)
            {
                config.btnHeight = result_height;
            }

            int result_width;
            bool success_width = Int32.TryParse(txtButtonWidth.Text, out result_width);
            if (success_width)
            {
                config.btnWidth = result_width;
            }

            if (txtFont.Text != "")
            {
                FontFamily font = new FontFamily(txtFont.Text);
                config.font = font;
            }

            int result_fontSize;
            bool success_fontSize = Int32.TryParse(txtFontSize.Text, out result_fontSize);
            if (success_fontSize)
            {
                config.fontSize = result_fontSize;
            }

            closeSettings();

            GC.Collect(0);
        }
        private void yrs_settings_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                closeSettings();

                this.Close();
            }
        }
        #endregion yrs_settings events

        private void sldRed_MouseWheel(object sender, MouseWheelEventArgs e)
        {

        }

        private void btnChangeLanguage_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
/* YourStartUp settings tool  
 * 
 * End of File
 */