﻿/*  purpose: managing language elemnts of settings window
 * 
 * written: september 2022
 * by: stephan kammel
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YourStartUp
{
    class SettingsTexts
    {
        public string language { get; set; }

        public SettingsTexts(string _language = "english")
        {
            language = _language;
        }

        // content
        #region content
        //buttons
        public StringBuilder btnBackgroundImage_content()
        {
            if (language == "english")
            {
                string value = "image";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Bild";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnChangeColor_content()
        {
            if (language == "english")
            {
                string value = "change color";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            if (language == "deutsch")
            {
                string value = "Farbe ändern";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnFont_content()
        {
            if (language == "english")
            {
                string value = "change font";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Schrift ändern";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnLeave_content()
        {
            if (language == "english")
            {
                string value = "leave";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            if (language == "deutsch")
            {
                string value = "Verlassen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnRestoreDefault_content()
        {
            if (language == "english")
            {
                string value = "reset";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Zurücksetzen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        // checkboxes
        public StringBuilder chxCoordinates_content()
        {
            if (language == "english")
            {
                string value =
                    "mouse coordinates";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Mauskoordinaten";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder chxHideDrives_content()
        {
            if (language == "english")
            {
                string value =
                    "hide drives";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "verberge Laufwerke";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder chxHideNotes_content()
        {if (language == "english")
            {
                string value = "hide notes";
                StringBuilder sb = new StringBuilder(value);
                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "verberge Notizen";
                StringBuilder sb = new StringBuilder(value);
                 return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder chxHideScetchboard_content()
        {
            if (language == "english")
            {
                string value =
                    "hide scetchboard";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "verberge Skizzen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder chxHideTimer_content()
        {if (language == "english")
            {
                string value = "hide timer";
                StringBuilder sb = new StringBuilder(value);
                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "verberge Uhr";
                StringBuilder sb = new StringBuilder(value);
                 return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder chxMoreOptions_content()
        {
            if (language == "english")
            {
                string value =
                    "more options";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "mehr Optionen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        // radiobuttons
        public StringBuilder rbBackground_content()
        {
            if (language == "english")
            {
                string value =
                    "background";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            if (language == "deutsch")
            {
                string value =
                    "Hintergrund";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbButtons_content()
        {
            if (language == "english")
            {
                string value =
                    "buttons";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Schaltflächen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbCanvas_content()
        {
            if (language == "english")
            {
                string value =
                    "scetchboard canvas";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Skizzen Hintergrund";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbCanvasMenu_content()
        {
            if (language == "english")
            {
                string value =
                    "scetchboard menu";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            if (language == "deutsch")
            {
                string value =
                    "Skizzen Menü";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbDelete_content()
        {
            if (language == "english")
            {
                string value = "delete state";
                StringBuilder sb = new StringBuilder(value);
                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Löschen";
                StringBuilder sb = new StringBuilder(value);
                 return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbFont_content()
        {
            if (language == "english")
            {
                string value = "font";
                StringBuilder sb = new StringBuilder(value);
                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Schrift";
                StringBuilder sb = new StringBuilder(value);
                 return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbGeneral_content()
        {
            if (language == "english")
            {
                string value = "general";
                StringBuilder sb = new StringBuilder(value);
                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "allgemein";
                StringBuilder sb = new StringBuilder(value);
                 return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder rbHideGui_content()
        {
            if (language == "english")
            {
                string value =
                    "gui minimizers";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Minimierer";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbHighlight_content()
        {
            if (language == "english")
            {
                string value = "button highlight";
                StringBuilder sb = new StringBuilder(value);
                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Aufhellung";
                StringBuilder sb = new StringBuilder(value);
                 return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbRename_content()
        {
            if (language == "english")
            {
                string value =
                    "rename state";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Umbenennen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbReset_content()
        {
            if (language == "english")
            {
                string value =
                    "reset state";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Neubelegen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder rbSliders_content()
        {
            if (language == "english")
            {
                string value =
                    "slider background";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Schieber";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder rbTextboxes_content()
        {
            if (language == "english")
            {
                string value =
                    "textboxes";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            if (language == "deutsch")
            {
                string value =
                    "Textboxen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }


        // labels
        public StringBuilder lblBorderRadius_content()
        {
            if (language == "english")
            {
                string value =
                    "border radius";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Randradius";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblButtonHeight_content()
        {
            if (language == "english")
            {
                string value =
                    "button height";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Höhe";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblButtonSettings_content()
        {
            if (language == "english")
            {
                string value =
                    "button settings";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Schaltflächen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblButtonWidth_content()
        {
            if (language == "english")
            {
                string value =
                    "button width";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Breite";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblContrastValue_content()
        {
            if (language == "english")
            {
                string value =
                    "adjust RGB";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Farbe anpassen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblFont_content()
        {
            if (language == "english")
            {
                string value =
                    "font family";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Schriftart";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblFontSettings_content()
        {
            if (language == "english")
            {
                string value =
                    "font settings";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Schrift einstellen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblFontSize_content()
        {
            if (language == "english")
            {
                string value =
                    "font size";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Schriftgröße";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblSelectGuiElement_content()
        {
            if (language == "english")
            {
                string value =
                    "select gui element";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "wähle Oberflächenelement";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        #endregion content

        // exceptions
        #region exceptions
        public StringBuilder argbTextboxException()
        {
            if (language == "english")
            {
                string value = "Format error: " +
                    "\n" +
                    "\n\t- 4 numbers only," +
                    "\n\t- number range must be 0..255," +
                    "\n\t- numbers must be separated by comma.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Eingabefehler: " +
                    "\n" +
                    "\n\t- nur 4 Zahlen erlaubt" +
                    "\n\t- im Bereich 0..255," +
                    "\n\t- kommagetrennt.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder argbTextboxHexValueException()
        {
            if (language == "english")
            {
                string value = "Format error: " +
                    "\n" +
                    "\n\t- 4 hexadecimal numbers only," +
                    "\n\t- number range must be 0..FF," +
                    "\n\t- numbers must be separated by comma.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Eingabefehler: " +
                    "\n" +
                    "\n\t- nur 4 hexadezimale Zahlen erlaubt" +
                    "\n\t- im Bereich 0..FF," +
                    "\n\t- kommagetrennt.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder rgbTextboxException()
        {
            if (language == "english")
            {
                string value = "Format error: " +
                    "\n" +
                    "\n\t- 3 numbers only," +
                    "\n\t- number range must be 0..255," +
                    "\n\t- numbers must be separated by comma.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Eingabefehler: " +
                    "\n" +
                    "\n\t- nur 3 Zahlen erlaubt" +
                    "\n\t- im Bereich 0..255," +
                    "\n\t- kommagetrennt.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rgbTextboxHexValueException()
        {
            if (language == "english")
            {
                string value = "Format error: " +
                    "\n" +
                    "\n\t- 3 hexadecimal numbers only," +
                    "\n\t- number range must be 0..FF," +
                    "\n\t- numbers must be separated by comma.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Eingabefehler: " +
                    "\n" +
                    "\n\t- nur 3 hexadezimale Zahlen erlaubt" +
                    "\n\t- im Bereich 0..FF," +
                    "\n\t- kommagetrennt.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        #endregion exceptions

        // texts
        #region
        public StringBuilder alphaDeviation()
        {
            if (language == "english")
            {
                string value = "- alpha deviation -";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "- alpha Abweichung -";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        #endregion

        // tooltip
        #region tooltip
        // buttons
        public StringBuilder btnBackgroundImage_tooltip()
        {
            if (language == "english")
            {
                string value = "select a background image and confirm";                    

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Hintergrundbild auswählen und bestätigen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnChangeColor_tooltip()
        {
            if (language == "english")
            {
                string value = 
                    "select a ui element to see its color on the canvas\n" +
                    "change the color value using the sliders, then hit\n" +
                    "this button to confirm the new color for the ui element";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            if (language == "deutsch")
            {
                string value =
                    "wähle ein Oberflächenelement aus, um die Farbe angezeigt\n" +
                    "zu bekommen die akuell ausgewählt ist, ändere diese mit\n" +
                    "den Schiebern, klicke zum Bestätigen auf diesen Button";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnFont_tooltip()
        {
            if (language == "english")
            {
                string value = "choose a font and its size, hit this button to confirm";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Schrift wählen, Größe festsetzen und anschließend\n" +
                    "durch das klicken auf diese Schaltfläche bestätigen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnLeave_tooltip()
        {
            if (language == "english")
            {
                string value = "close this window, changes will be saved";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "beim Schließen dieses Fensters werden die meisten Änderungen gespeichert";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnRestoreDefault_tooltip()
        {
            if (language == "english")
            {
                string value = "change all ui elements to standard configuration";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            if (language == "deutsch")
            {
                string value = "stelle Standardwerte wieder her";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        // checkboxes
        public StringBuilder chxCoordinates_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "show or hide mouse coordinates on main window";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Sichtbarkeit der Mauskoordinaten im Hauptfenster festlegen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder chxHideDrives_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "hide or show button 'all' and drive buttons";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Schaltflächensichtbarkeit 'Alle' und Laufwerke";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder chxHideNotes_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "hide or show button 'notes'";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Schaltflächensichtbarkeit 'Notizen'";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder chxHideScetchboard_tooltip()
        {
            if (language == "english")
            {
                string value = "hide or show button 'scetchboard'";
                StringBuilder sb = new StringBuilder(value);
                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Schaltflächensichtbarkeit 'Skizzen'";
                StringBuilder sb = new StringBuilder(value);
                 return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder chxHideTimer_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "hide or show button 'timer'";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Schaltflächensichtbarkeit 'Uhr'";
                StringBuilder sb = new StringBuilder(value);
                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder chxMoreOptions_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "check for more options, uncheck to hide additional options";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            if (language == "deutsch")
            {
                string value =
                    "zeige mehr Optionen, verberge mehr Optionen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        // labels
        public StringBuilder lblAlphaValue_tooltip()
        {
            if (language == "english")
            {
                string value = 
                    "alpha value channel\n" +
                    "use slider on the right\n" +
                    "to change transparency";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Alphawertkanal\n" +
                    "mit dem Schieber rechts den Transparenzwert einstellen\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblBlueValue_tooltip()
        {
            if (language == "english")
            {
                string value = 
                    "blue value color channel\n" +
                    "use slider on the right\n" +
                    "to change blue color value";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Blauer Kanal\n" +
                    "mit dem Schieber rechts das Blau regulieren\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblBorderRadius_tooltip()
        {
            if (language == "english")
            {
                string value = 
                    "border radius value, if 0 corners will be sharp,\n" +
                    "values higher than 0 will round off ui element corners";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Randradiuswert festlegen, harte Kanten beim Wert 0,\n" +
                    "höhere Werte runden die Kanten immer weiter ab";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblButtonHeight_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "button height value, insert an integer value higher than 0,\n" +
                    "every button will change its height to this value";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Schaltflächenhöhe festlegen durch Eingabe einer ganzen Zahl größer 0,\n" +
                    "jede Schaltfläche wird diesen Wert als neuen Höhenwert übernehmen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblButtonSettings_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "configurate button appearence";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "die Erscheinug der Schaltflächen konfigurieren";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblButtonWidth_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "button width value, insert an integer value higher than 0,\n" +
                    "buttons will change their width to this value";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Schaltflächenbreite festlegen durch Eingabe einer ganzen Zahl größer 0,\n" +
                    "jede Schaltfläche wird diesen Wert als neuen Breitenwert übernehmen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblContrastValue_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "change all three color sliders at once";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "alle drei Farbregler(rot, grün und blau) auf einmal verschieben";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblFont_tooltip()
        {
            if (language == "english")
            {
                string value = "choose a font family by entering the font name";
                StringBuilder sb = new StringBuilder(value);
                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "Schriftart per Eingabe des Schriftnamens auswählen";
                StringBuilder sb = new StringBuilder(value);
                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblFontSettings_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "configurate font family and font size";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Schriftart- und -größeneinstellung";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblFontSize_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "enter desired font size";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "gewünschte Schriftgröße eingeben";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblGreenValue_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "green value color channel\n" +
                    "use slider on the right\n" +
                    "to change green color value";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if(language == "deutsch")
            {
                string value = 
                    "Grüner Kanal\n" +
                    "mit dem Schieber rechts das Grün regulieren\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblGreyValue_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "black and white value channel\n" +
                    "use slider on the right\n" +
                    "to change greyscale value";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Grauer Kanal\n" +
                    "mit dem Schieber rechts zwischen Schwarz und Weiß regulieren\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblRedValue_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "red value color channel\n" +
                    "use slider on the right\n" +
                    "to change red color value";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Roter Kanal\n" +
                    "mit dem Schieber rechts das Rot regulieren\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder lblSelectGuiElement_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "select an ui feature to change its color";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Oberflächenelement zum Wechseln der Farbe auswählen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        // radiobuttons
        public StringBuilder rbBackground_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "select this and a gui element from the selection below\n" +
                    "to change background colors on that element";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "zwischen Hintergrund und Schrift entscheiden, anschließend das zu ändernde\n" +
                    "Oberflächenelement aus der Auswahl unten auswählen um dessen Farbe zu ändern\n";
                    
                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbButtons_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "select this to change either the back color or font color\n" +
                    "on every button within the program";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "bei Auswahl dieser Schaltfläche kann entweder deren Hintergrund\n" +
                    "oder Schrift geändert werden";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbCanvas_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "change background color of scetchboard canvas";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Hintergrund der Skizzenmalfläche ändern";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbCanvasMenu_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "change background color of scetchboard menu areas";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Hintergrund des Skizzenmenüs ändern";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbDelete_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "change delete state colors on buttons";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Hintergrund- und Schriftfarben des Löschmodus ändern";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbFont_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "select this and a gui element from the selection below\n" +
                    "to change font colors on that element";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "zwischen Hintergrund und Schrift entscheiden, anschließend das zu ändernde\n" +
                    "Oberflächenelement aus der Auswahl unten auswählen um dessen Farbe zu ändern\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbGeneral_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "select this to change either the back color or font color\n" +
                    "on general gui elements within the program";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Schrift- oder Hintergrundfarbe allgemeiner Oberflächenlemente anpassen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder rbHideGui_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "select this to change either the back color or font color\n" +
                    "on gui minimizer elements within the main window";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Schrift- oder Hintergrundfarbe der Oberflächenminimierer ändern";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbHighlight_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "select this to change the highlight colors on buttons when\n" +
                    "mouse enters button area";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Aufhellungsfarbe wenn der Mauszeiger in einen Schaltflächenbereich wandert";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbRename_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "change rename state colors on buttons";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Hintergrund- und Schriftfarben des Umbenennungsmodus ändern";
                
                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbReset_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "change reset state colors on buttons";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Hintergrund- und Schriftfarben des Wechselmodus ändern";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbSliders_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "select this to change the background colors on sliders";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Hintergrundfarbe der Schieber ändern";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder rbTextboxes_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "select this to change either the back color or font color\n" +
                    "on textboxes within the program";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Hintergrund- und Schriftfarbe der Textboxen ändern";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        // textboxes
        public StringBuilder txtBackgroundImage_tooltip()
        {
            if (language == "english")
            {
                string value =
                    "choose a backgroundimage for the main window";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value =
                    "Hintergrundbild für das Hauptfenster auswählen";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        #endregion tooltip        
    }
}
