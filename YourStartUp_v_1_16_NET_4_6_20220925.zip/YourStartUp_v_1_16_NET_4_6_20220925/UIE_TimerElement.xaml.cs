﻿/* YourStartUp UserInterfaceElement Timer Element
 * 
 * Purpose:     display time, date, runtime of application and measure activity and break times up to ten times
 * Intend:      learn the time, learn how long your concentration can last while working or hobbying
 *              
 * Content:     user element class structure containing methods and/or properties
 *              
 * ToC:         2022 (september_14 <> september_14)
 * Dev:         Stephan Kammel
 * E-Mail:      kammel@posteo.de
 */
using Microsoft.Win32;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;


namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für UIE_TimerElement.xaml
    /// </summary>
    public partial class UIE_TimerElement : UserControl
    {
        private ConfigData config = new ConfigData();

        private MainWindow parent;

        private TimerTexts timer = new TimerTexts();

        private YRS_Time_Jobs tj = new YRS_Time_Jobs();

        private System.Windows.Threading.DispatcherTimer _timer = new System.Windows.Threading.DispatcherTimer();

        private bool breakState = false;

        private int counter;

        private string breakDurationString;


        // constructor(s)
        public UIE_TimerElement()
        {
            InitializeComponent();
            _timer.Tick += _timer_Tick;
            _timer.Interval = TimeSpan.FromSeconds(0.28);
            _timer.Start();

            tj.start_stopwatch();
        }


        // methods private
        #region methods private A-L
        private void addConfiguratedUIElements()
        {
            tbDate.FontFamily = config.font;
            tbDate.FontSize = 12;
            tbDate.Background = config.backColor;
            tbDate.Foreground = config.foreColor;
            tbDate.HorizontalAlignment = HorizontalAlignment.Center;
            tbLastBreak.VerticalAlignment = VerticalAlignment.Center;
            tbDate.TextAlignment = TextAlignment.Center;
            tbDate.Padding = new Thickness(5, 10, 5, 0);
            tbDate.ToolTip = timer.tbDate_toolTip();

            border.CornerRadius = new CornerRadius(config.borderRadius);
            border.BorderThickness = new Thickness(3);
            border.BorderBrush = config.foreColor;
            border.Background = config.backColor;

            tbLastBreak.FontSize = config.fontSize * 3;
            tbLastBreak.VerticalAlignment = VerticalAlignment.Center;
            tbLastBreak.ToolTip = timer.tbLastBreak_tooltip();

            tbLastBreak.TextAlignment = TextAlignment.Center;
            tbLastBreak.Padding = new Thickness(5, 0, 5, 0);

            tbSinceStart.FontSize = config.fontSize * 3;
            tbSinceStart.VerticalAlignment = VerticalAlignment.Center;
            tbSinceStart.ToolTip = timer.tbSinceStart_tooltip();
            tbSinceStart.TextAlignment = TextAlignment.Center;
            tbSinceStart.Padding = new Thickness(5, 0, 5, 0);

            tbTimer.FontSize = config.fontSize * 3;
            tbTimer.VerticalAlignment = VerticalAlignment.Center;
            tbTimer.ToolTip = timer.tbTimer_toolTip();
            tbTimer.TextAlignment = TextAlignment.Center;
            tbTimer.Padding = new Thickness(5, 0, 5, 0);

            btnTakeABreak.FontSize = config.fontSize;
            btnTakeABreak.ToolTip = timer.btnTakeABreak_toolTip();
            btnTakeABreak.Content = timer.btnTakeABreak_content();
        }

        private void addRessources()
        {
            this.DataContext = this;

            Resources.Add("backgroundColors", config.btnBackColor);
            Resources.Add("borderRadius", new CornerRadius(config.borderRadius));
            Resources.Add("buttonHeight", Convert.ToDouble(config.btnHeight));
            Resources.Add("foregroundColors", config.btnForeColor);

            Resources.Add("highlight", config.highlightColor);

            Resources.Add("breakButtonColor", config.renameState);
            Resources.Add("breakButtonFont", config.renameStateFont);
        }

        private void loadUIConfig()
        {
            addRessources();

            FontFamily = config.font;
            FontSize = config.fontSize;
            Height = 4 * config.btnHeight + 75;
            MinHeight = 4 * config.btnHeight + 75;
            Width = config.btnWidth + 75;
            MinWidth = config.btnWidth + 75;

            Background = new SolidColorBrush(Colors.Transparent);
            Foreground = config.foreColor;

            addConfiguratedUIElements();

            wrpTimeLog.Orientation = Orientation.Vertical;
        }

        private void sessionSwitchOff()
        {
            SystemEvents.SessionSwitch -= SystemEvents_SessionSwitch;
        }

        private void sessionSwitchOn() // name anders, code zum checken ob der bildschirm gesperrt ist.
        {
            SystemEvents.SessionSwitch += SystemEvents_SessionSwitch;
            /* Do something you need to do, block thread, or do a quick check
             * just be sure to unregister when you are done.
             */
            //SystemEvents.SessionSwitch -= SystemEvents_SessionSwitch;
        }

        private TextBlock timeCalculation()
        {
            TextBlock tb = new TextBlock();

            tb.TextAlignment = TextAlignment.Center;
            tb.FontFamily = config.font;
            tb.FontSize = 12;
            tb.Margin = new Thickness(5, 2, 5, 0);
            tb.Padding = new Thickness(5, 0, 5, 0);

            if (breakState == true)
            {
                counter++;
                tj.reset_break_stopwatch();
                tj.start_break_stopwatch();
                tb.Text = $"#{counter} ::: {tbTimer.Text}\n{tbSinceStart.Text} ::: {tbLastBreak.Text}";

                tb.Foreground = config.btnForeColor;

                tb.ToolTip = timer.breakStateTrue_toolTip();
                counter--;
            }
            else
            {
                tj.stop_break_stopwatch();
                calculateBreakDuration();
                tb.Text = $"{breakDurationString} ::: {tbSinceStart.Text} \n {tbTimer.Text}";

                tb.Foreground = config.renameStateFont;

                tb.ToolTip = timer.breakStateFalse_toolTip();
                counter++;
            }
            return tb;
        }

        private TextBlock timeLog()
        {
            if (counter > 9)
            {
                wrpTimeLog.Children.Clear();
                counter = 0;
            }

            return timeCalculation();
        }

        private void calculateBreak()
        {
            if (breakState == false)
            {
                tbLastBreak.Text = tj.get_stopwatch_time().ToString();
            }
        }

        private void calculateBreakDuration()
        {
            breakDurationString = tj.get_break_time().ToString();
        }


        private void calculateTimerRuntime()
        {
            tbSinceStart.Text = tj.get_active_time().ToString();

            tbDate.Text = config.dateString();

        }

        private void handleBreak()
        {
            calculateBreak();

            processBreakButtonAction();
        }
        #endregion methods private A-L

        #region methods private M-Z
        private void processBreakButtonAction()
        {
            if (breakState == false)
            {
                breakState = true;
                btnTakeABreak.Background = config.btnBackColor;
                btnTakeABreak.Foreground = config.renameStateFont;
                btnTakeABreak.Content = timer.endBreak_content();

                tj.stop_stopwatch();
            }
            else
            {
                tj.restart_stopwatch();
                breakState = false;

                btnTakeABreak.Background = config.renameState;
                btnTakeABreak.Foreground = config.renameStateFont;
                btnTakeABreak.Content = timer.btnTakeABreak_content();
            }
        }
        #endregion methods private M-Z

        // events private

        // button events
        #region button events

        private void btnTakeABreak_Click(object sender, RoutedEventArgs e)
        {
            Button change_me = (Button)sender;

            handleBreak();
            wrpTimeLog.Children.Add(timeLog());
            wrpTimeLog.HorizontalAlignment = HorizontalAlignment.Center;


            parent = (MainWindow)Window.GetWindow(TimerElement);
            parent.resizeTimerModule(change_me);
        }
        #endregion button events

        public void SystemEvents_SessionSwitch(object sender, SessionSwitchEventArgs e)
        {
            if (e.Reason == SessionSwitchReason.SessionLock)
            {
                handleBreak();
                wrpTimeLog.Children.Add(timeLog());
                wrpTimeLog.HorizontalAlignment = HorizontalAlignment.Center;
            }

            else if (e.Reason == SessionSwitchReason.SessionUnlock)
            {
                handleBreak();
                wrpTimeLog.Children.Add(timeLog());
                wrpTimeLog.HorizontalAlignment = HorizontalAlignment.Center;
            }
        }

        private void _timer_Tick(object sender, EventArgs e)
        {
            tbTimer.Text = tj.get_time_string().ToString();

            //tbTimer.Text = DateTime.Now.ToLongTimeString();
            calculateBreak();
            calculateTimerRuntime();

            GC.Collect(0);
        }

        // timer window events
        #region timer window events
        private void yrs_timer_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            tj.stop_active_time();

            sessionSwitchOff();

            GC.Collect(0);
        }
        #endregion timer window events

        private void TimerElement_Loaded(object sender, RoutedEventArgs e)
        {
            loadUIConfig();
            calculateBreak();
            calculateTimerRuntime();
            tbTimer.Text = DateTime.Now.ToLongTimeString();

            sessionSwitchOn();
        }

        private void TimerElement_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {

            }
            if (e.ChangedButton == MouseButton.Right)
            {

            }
        }
    }
}
/* UIE_TimerElement
 * 
 * End of File
 */