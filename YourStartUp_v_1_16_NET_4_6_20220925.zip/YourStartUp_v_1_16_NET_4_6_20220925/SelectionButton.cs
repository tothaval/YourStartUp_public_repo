﻿/* YourStartUp SelectionButton class
 * 
 * Pur:         logic prototype
 * Toc:         2022 (august <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      taranis.sk@gmail.com
 */

using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace YourStartUp
{
    class SelectionButton
    {
        public Button borderChild { get; set; }

        private Border brd = new Border();
        private Button btn = new Button();
        private StackPanel stp = new StackPanel();
        private TextBox tb = new TextBox();

        private System.Windows.Controls.Image imageUICtrl = new System.Windows.Controls.Image();

        private ImageBrush image = new ImageBrush();

        private SolidColorBrush background_;
        private SolidColorBrush foreground_;
        private SolidColorBrush highlight_;
        private SolidColorBrush borderBrush_;

        private double height_;
        private double radius_;
        private double width_;

        private string filepath;
        private string filename;

        // constructor
        public SelectionButton()
        {

        }

        // code snippets

        //private Style normalButtons()
        //{
        //    // Create a new style for a button
        //    var buttonStyle = new Style(typeof(Button));

        //    // Set the properties of the style
        //    buttonStyle.Setters.Add(new Setter(Control.BackgroundProperty, config.backColor));
        //    buttonStyle.Setters.Add(new Setter(Control.ForegroundProperty, config.foreColor));
        //    //buttonStyle.Setters.Add(new Setter(Control.BorderBrushProperty, config.foreColor)); // geht, aber jetzt sinnlos wegen border
        //    //buttonStyle.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(1))); // geht, aber jetzt sinnlos wegen border
        //    //buttonStyle.Setters.Add(new Setter(Control.FontSizeProperty,  config.fontSize)); // geht nicht
        //    //buttonStyle.Setters.Add(new Setter(Control.FontFamilyProperty, config.font)); // geht nicht
        //    // height und width gehen auch nicht.

        //    // Set this style as a resource. Any DynamicResource tied to this key will be updated.
        //    //this.Resources["allMayRemainInVainForEver"] = buttonStyle;

        //    return buttonStyle;            
        //}

        //System.Windows.Point Point4 = new System.Windows.Point(250, 200);
        //System.Windows.Point Point5 = new System.Windows.Point(200, 150);

        //PointCollection polygonPoints = new PointCollection();
        //polygonPoints.Add(Point1);
        //polygonPoints.Add(Point2);
        //polygonPoints.Add(Point3);
        //polygonPoints.Add(Point4);
        //polygonPoints.Add(Point5);
        //pygon.Points = polygonPoints;


        //BitmapImage BitmapToImageSource(Bitmap bitmap)
        //{
        //    using (MemoryStream memory = new MemoryStream())
        //    {
        //        bitmap.Save(memory, System.Drawing.Imaging.ImageFormat.Bmp);
        //        memory.Position = 0;
        //        BitmapImage bitmapimage = new BitmapImage();
        //        bitmapimage.BeginInit();
        //        bitmapimage.StreamSource = memory;
        //        bitmapimage.CacheOption = BitmapCacheOption.OnLoad;
        //        bitmapimage.EndInit();

        //        return bitmapimage;
        //    }
        //}


        // RadioButton rb = (sender as RadioButton);

        //btnMenuList[i].OpacityMask = new VisualBrush() { Visual = border };

        //this.Activate();      

        //App.Current.Resources["BlueBrush"] = new SolidColorBrush(Colors.Pink); //just 4 info

        //foreach (var window in OwnedWindows)
        //{
        //    window.
        //}

        //Style style = new Style(typeof(System.Windows.Controls.Border));
        //style.Setters.Add(
        //    new Setter(
        //        System.Windows.Controls.Border.CornerRadiusProperty,
        //        new CornerRadius(config.borderRadius)
        //        )
        //    );
        //style.Setters.Add(
        //    new Setter(
        //        System.Windows.Controls.Border.BorderThicknessProperty,
        //        new Thickness(1)
        //        )
        //    );
        //btnTakeABreak.Resources.Add(typeof(System.Windows.Controls.Border), style);
        //btnMinimize.Resources.Add(typeof(System.Windows.Controls.Border), style);

        public Border construct()
        {
            brd.Child = btn;
            btn.Content = stp;
            btn.Click += Btn_Click;

            stp.Children.Add(imageUICtrl);
            stp.Children.Add(tb);
            stp.Orientation = Orientation.Horizontal;

            brd.BorderThickness = new Thickness(1);
            brd.CornerRadius = new CornerRadius(radius_);

            brd.Height = height_;
            brd.Width = width_;

            brd.Background = background_;
            brd.BorderBrush = borderBrush_;

            btn.Background = new SolidColorBrush(Colors.Transparent);
            btn.Padding = new Thickness(5);

            tb.Background = new SolidColorBrush(Colors.Transparent);
            tb.Foreground = foreground_;
            tb.BorderThickness = new Thickness(0);
            tb.IsReadOnly = true;
            tb.IsEnabled = false;

            borderChild = btn;

            return brd;
        }

        // createURLButton????

        private ImageSource GetIcon(string fileName)
        {
            Icon icon = Icon.ExtractAssociatedIcon(fileName);
            return System.Windows.Interop.Imaging.CreateBitmapSourceFromHIcon(
                icon.Handle,
                new Int32Rect(),
                BitmapSizeOptions.FromEmptyOptions()
                );
        }

        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;

            //MessageBox.Show($"{filepath}\n{filename}");

            try
            {
                ProcessStartInfo start = new ProcessStartInfo(filepath);
                start.UseShellExecute = true;
                Process.Start(filepath);
            }
            catch
            {
                if (filepath != null)
                {
                    MessageBox.Show($"{filepath}\n\npath could not be opened");
                }
            }

            if (filepath is null)
            {
                OpenFileDialog setPath = new OpenFileDialog();
                setPath.InitialDirectory = Environment.GetEnvironmentVariable("userdir");
                setPath.Filter = "executables (*.exe)|*.exe|All files (*.*)|*.*";
                setPath.FilterIndex = 2;
                setPath.RestoreDirectory = true;

                if (setPath.ShowDialog() == true)
                {
                    filepath = setPath.FileName.ToString();
                    filename = System.IO.Path.GetFileName(filepath);
                    filename = filename.Replace(".exe", "");

                    //image.ImageSource = GetIcon(filepath);

                    imageUICtrl.Source = GetIcon(filepath);

                    //MessageBox.Show(filepath);

                    tb.Text = filename;
                    tb.HorizontalContentAlignment = HorizontalAlignment.Center;
                    tb.VerticalContentAlignment = VerticalAlignment.Center;

                    btn.ToolTip = filename;
                }
            }
        }
    }
}
