﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UtilityLibrary
{
    public class YrsConfig
    {
        // prop ging nicht
        public static int testProp { get; set; }

        public FuckOff fuckOff = new FuckOff();

        public string memberJolliVisuals()
        {
            return fuckOff.die;
        }

    }

    public class FuckOff
        {
        public string die = "just do it";
        }
}
