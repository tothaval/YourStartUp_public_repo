﻿/* YourStartUp UserInterfaceElement Selection Binding Element
 * 
 * Purpose:     bind files to clickable object to open them with one click, representing a core idea behind this application(YRS)
 * Intend:      easy application or work/hobby related files opening, a start up functionality from hour 0.
 *              
 * Content:     user element class structure containing methods and/or properties
 *              
 * ToC:         2022 (september_13 <> september_13)
 * Dev:         Stephan Kammel
 * E-Mail:      kammel@posteo.de
 */
using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;


namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für UIE_SelectionBindingElement.xaml
    /// </summary>
    public partial class UIE_SelectionBindingElement : UserControl
    {
        private Canvas_UIConfig uic = new Canvas_UIConfig();
        private ConfigData config = new ConfigData();

        private MainWindowTexts text = new MainWindowTexts();

        public TextBox tb = new TextBox();

        private UIE_CheckboxCanvasButton CCB = new UIE_CheckboxCanvasButton();
        private UIE_CheckboxCanvasButton CCB_reset = new UIE_CheckboxCanvasButton();
        private UIE_CheckboxCanvasButton CCB_rename = new UIE_CheckboxCanvasButton();
        private UIE_CheckboxCanvasButton CCB_relink = new UIE_CheckboxCanvasButton();
        private UIE_CheckboxCanvasButton CCB_resize = new UIE_CheckboxCanvasButton();

        // binding logic
        public System.Windows.Controls.Image imageUICtrl = new System.Windows.Controls.Image();

        private ImageBrush image = new ImageBrush();

        public string filepath;
        public string filename;


        public UIE_SelectionBindingElement()
        {
            InitializeComponent();
        }

                       
        public Border construct_SB()
        {
            btn.Click += Btn_Click;
            btn.Content = imageUICtrl;
            
            brd.BorderThickness = new Thickness(1);
            brd.CornerRadius = new CornerRadius(config.borderRadius);

            btn.Height = config.btnHeight;
            btn.Width = config.btnWidth;

            brd.Background = config.btnBackColor;
            brd.BorderBrush = config.btnForeColor;

            btn.Background = new SolidColorBrush(Colors.Transparent);
            btn.Padding = new Thickness(7);

            tb.Background = new SolidColorBrush(Colors.Transparent);            
            tb.Foreground = config.btnForeColor;            
            
            //tb.IsReadOnly = true;
            tb.IsEnabled = false;
                        
            return brd;
        }

        // createURLButton????

        public ImageSource GetIcon(string fileName)
        {
            Icon icon = Icon.ExtractAssociatedIcon(fileName);
            return System.Windows.Interop.Imaging.CreateBitmapSourceFromHIcon(
                icon.Handle,
                new Int32Rect(),
                BitmapSizeOptions.FromEmptyOptions()
                );
        }

        private void openFileDialog()
        {
            OpenFileDialog setPath = new OpenFileDialog();
            setPath.InitialDirectory = Environment.GetEnvironmentVariable("userdir");
            setPath.Filter = "executables (*.exe)|*.exe|All files (*.*)|*.*";
            setPath.FilterIndex = 2;
            setPath.RestoreDirectory = true;

            if (setPath.ShowDialog() == true)
            {
                filepath = setPath.FileName.ToString();
                filename = System.IO.Path.GetFileName(filepath);
                filename = filename.Replace(".exe", "");

                //image.ImageSource = GetIcon(filepath);

                imageUICtrl.Source = GetIcon(filepath);

                //MessageBox.Show(filepath);

                tb.Text = filename;
                tb.TextAlignment = TextAlignment.Center;

                btn.ToolTip = $"{filepath}{filename}";
            }
        }


        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;

            //MessageBox.Show($"{filepath}\n{filename}");

            try
            {
                ProcessStartInfo start = new ProcessStartInfo(filepath);
                start.UseShellExecute = true;
                Process.Start(filepath);
            }
            catch
            {
                if (filepath != null)
                {
                    MessageBox.Show(text.pathExcetptionMessage().ToString());
                }
            }

            if (filepath is null)
            {
                openFileDialog();
            }
        }

        //private Border createSelectionButton(string configuration)
        //{
        //    Style style = this.FindResource("buttonStyle") as Style;

        //    Border brd = new Border();
        //    Button btn = new Button();
        //    StackPanel stp = new StackPanel();
        //    TextBox tb = new TextBox();

        //    System.Windows.Controls.Image imageUICtrl = new System.Windows.Controls.Image();

        //    // Configuration Data
        //    string[] configParts = configuration.Split(';');

        //    configList.Add(configParts[0]);

        //    btn.ToolTip = configParts[1].ToString();
        //    if (configParts[0].ToString() == "+")
        //    {
        //        btn.ToolTip = texts.unset_tooltip();
        //    }
        //    if (configParts[0].ToString() == "")
        //    {
        //        btn.ToolTip = texts.empty_tooltip();
        //    }

        //    // Border Definition
        //    brd.CornerRadius = new CornerRadius(config.borderRadius);
        //    brd.BorderBrush = config.btnForeColor;
        //    brd.BorderThickness = new Thickness(1);
        //    brd.Background = config.btnBackColor;
        //    brd.Margin = new Thickness(2, 0, 2, 5);

        //    brd.Height = config.btnHeight;
        //    brd.Width = config.btnWidth;

        //    brd.Child = btn;

        //    btn.Content = stp;
        //    btn.Click += Btn_Click;

        //    btn.Name = $"btnSet{btnSetList.Count.ToString()}";
        //    //btn.Content = $"{configParts[0]}";
        //    btn.Height = config.btnHeight;
        //    btn.Width = config.btnWidth;
        //    btn.Background = new SolidColorBrush(Colors.Transparent);
        //    btn.Padding = new Thickness(5);
        //    btn.Foreground = config.btnForeColor;
        //    btn.FontSize = config.fontSize;

        //    btn.HorizontalContentAlignment = HorizontalAlignment.Center;
        //    btn.VerticalContentAlignment = VerticalAlignment.Center;

        //    btn.Style = style;

        //    if (configParts[0].ToString() != "+" && configParts[0].ToString() != "")
        //    {
        //        try
        //        {

        //            imageUICtrl.Source = GetIcon(configParts[1]);
        //            //
        //            string result = configParts[1].Substring(configParts[1].Length - 4);

        //            // MessageBox.Show(result);

        //            if (configParts[1].Substring(configParts[1].Length - 4) == ".png")
        //            {
        //                //MessageBox.Show("buh");

        //                System.Windows.Controls.Image finalImage = new System.Windows.Controls.Image();
        //                finalImage.Width = 80;

        //                BitmapImage logo = new BitmapImage();
        //                logo.BeginInit();
        //                logo.UriSource = new Uri(configParts[1]);
        //                logo.CreateOptions = BitmapCreateOptions.DelayCreation;
        //                logo.CacheOption = BitmapCacheOption.OnLoad;
        //                logo.EndInit();

        //                finalImage.Source = logo;
        //                imageUICtrl.Source = logo;

        //                //imageUICtrl.Source = GetPicture(configParts[1]);
        //            }

        //            // images in einer Liste speichern und aus der Liste laden, die Liste
        //            // muss irgendwie gespeichert werden, bzw. die icons
        //        }
        //        catch (Exception)
        //        {
        //            //MessageBox.Show(configParts[1].ToString());
        //        }
        //    }

        //    stp.Children.Add(imageUICtrl);
        //    stp.Children.Add(tb);
        //    stp.Orientation = Orientation.Horizontal;

        //    tb.Height = config.btnHeight;
        //    tb.Width = config.btnWidth;
        //    //tb.Visibility = Visibility.Hidden;
        //    tb.Background = new SolidColorBrush(Colors.Transparent);
        //    tb.Foreground = config.btnForeColor;
        //    tb.BorderThickness = new Thickness(1);
        //    tb.IsReadOnly = true;
        //    tb.IsEnabled = false;

        //    tb.HorizontalContentAlignment = HorizontalAlignment.Left;
        //    tb.VerticalContentAlignment = VerticalAlignment.Center;
        //    tb.TextWrapping = TextWrapping.WrapWithOverflow;

        //    tb.Text = configParts[0];

        //    tb.MouseDoubleClick += TxtBtnContent_MouseDoubleClick;
        //    tb.KeyDown += TxtBtnContent_KeyDown;


        //    brdSetList.Add(brd);
        //    btnSetList.Add(btn);
        //    setList.Add(configParts[1]);
        //    txtBoxList.Add(tb);

        //    wrpButtonMap.Children.Add(brd);

        //    return brd;
        //}

        //// icon extraction
        //private ImageSource GetIcon(string fileName)
        //{
        //    Icon icon = System.Drawing.Icon.ExtractAssociatedIcon(fileName);
        //    return System.Windows.Interop.Imaging.CreateBitmapSourceFromHIcon(
        //        icon.Handle,
        //        new Int32Rect(),
        //        BitmapSizeOptions.FromEmptyOptions()
        //        );
        //}



        private void activate_state_CCBs()
        {
            bottomPanel.Orientation = Orientation.Horizontal;
            topPanel.Orientation = Orientation.Horizontal;

            CCB_reset.Name = "CCB_reset";
            //CCB_reset.uie_textblock.Text = text.btnReset_content().ToString();
            CCB_reset.uie_textblock.Text = "bind";
            //CCB_reset.uie_ckbcnvbtn_button_border.ToolTip = $"reset the file binding\n{text.btnReset_toolTip()}";
            CCB_reset.uie_ckbcnvbtn_button_border.ToolTip = $"reset the file binding\n{text.btnReset_toolTip()}";
            CCB_reset.uie_ckbcnvbtn_button.Click += reset_Click;
            style_state_CCB(CCB_reset);
            bottomPanel.Children.Add(CCB_reset);

            CCB_rename.Name = "CCB_rename";
            //CCB_rename.uie_textblock.Text = text.btnRename_content().ToString();
            CCB_rename.uie_textblock.Text = "name";
            CCB_rename.uie_ckbcnvbtn_button_border.ToolTip = text.btnRename_toolTip();
            CCB_rename.uie_ckbcnvbtn_button.Click += rename_Click;
            style_state_CCB(CCB_rename);
            topPanel.Children.Add(CCB_rename);

            CCB_relink.Name = "CCB_relink";
            CCB_relink.uie_textblock.Text = "link";
            CCB_relink.uie_ckbcnvbtn_button_border.ToolTip = "content not existent";
            CCB_relink.uie_ckbcnvbtn_button.Click += relink_Click;
            style_state_CCB(CCB_relink);
            bottomPanel.Children.Add(CCB_relink);

            //CCB_resize.Name = "CCB_resize";
            //CCB_resize.uie_textblock.Text = "size";
            //CCB_resize.uie_ckbcnvbtn_button_border.ToolTip = "content not existent";
            //CCB_resize.uie_ckbcnvbtn_button.Click += resize_Click;
            //style_state_CCB(CCB_resize);
            //stackPanel.Children.Add(CCB_resize);

            tb.Name = "tb_filename";
            tb.Text = "- filename -";

            tb.Margin = new Thickness(7, 0, 0, 0);
            tb.TextAlignment = TextAlignment.Center;
            tb.VerticalAlignment = VerticalAlignment.Center;
            tb.IsEnabled = false;
            
            topPanel.Children.Add(tb);
        }

        

            
        private void propertyUpdate_buttonStyle()
        {
            // normal style
            Resources.Remove("buttonColor");
            Resources.Remove("buttonFont");
            Resources.Remove("highlight");
            Resources.Remove("radius");

            Resources.Add("buttonColor", config.btnBackColor);
            Resources.Add("buttonFont", config.btnForeColor);
            Resources.Add("highlight", config.highlightColor);
            Resources.Add("radius", new CornerRadius(config.borderRadius));
        }

        private void style_SBE()
        {
            border.Background = config.backColor;
            border.BorderBrush = config.foreColor;
            border.BorderThickness = new Thickness(4);
            border.CornerRadius = new CornerRadius(config.borderRadius);

            border.Padding = new Thickness(7);
        }

        private void style_state_CCB(UIE_CheckboxCanvasButton CCB_)
        {
            propertyUpdate_buttonStyle();
            
            Style style = this.FindResource("buttonStyle") as Style;

            CCB_.uie_ckbcnvbtn_button_border.Background = config.btnBackColor;
            CCB_.uie_ckbcnvbtn_button_border.BorderBrush = config.btnForeColor;
            CCB_.uie_ckbcnvbtn_button_border.BorderThickness = new Thickness(2);
            CCB_.uie_ckbcnvbtn_button_border.CornerRadius = new CornerRadius(config.borderRadius);

            CCB_.uie_ckbcnvbtn_button.Background = uic.transparent;

            CCB_.uie_ckbcnvbtn_button.Style = style;

            propertyUpdate_buttonStyle(); //  ?
        }




        #region grid events deactivated
        //private void grid_Loaded(object sender, RoutedEventArgs e)
        //{

        //}

        //private void grid_Initialized(object sender, EventArgs e)
        //{

        //}

        //private void grid_MouseDown(object sender, MouseButtonEventArgs e)
        //{

        //}

        //private void grid_MouseMove(object sender, MouseEventArgs e)
        //{

        //}

        //private void grid_MouseUp(object sender, MouseButtonEventArgs e)
        //{

        //}
        #endregion grid events deactivated


        #region Clicks
        public void resize_Click(object sender, RoutedEventArgs e)
        {
            //throw new NotImplementedException();
        }

        public void relink_Click(object sender, RoutedEventArgs e)
        {
            //throw new NotImplementedException();
        }

        public void rename_Click(object sender, RoutedEventArgs e)
        {
            //throw new NotImplementedException();
            if (tb.IsEnabled == false)
            {
                tb.IsEnabled = true;
            }
            else if (tb.IsEnabled == true)
            {
                tb.IsEnabled = false;
            }
        }

        public void reset_Click(object sender, RoutedEventArgs e)
        {
            openFileDialog();
        }

        #endregion


        private void SelectionBindingElement_Loaded(object sender, RoutedEventArgs e)
        {
            config.loadConfig();

            activate_state_CCBs();

            construct_SB();

            style_SBE();
        }

        private void SelectionBindingElement_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void SelectionBindingElement_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void SelectionBindingElement_MouseUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void SelectionBindingElement_PreviewDragOver(object sender, DragEventArgs e)
        {

        }

        private void SelectionBindingElement_Drop(object sender, DragEventArgs e)
        {

        }

        private void SelectionBindingElement_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void SelectionBindingElement_MouseLeave(object sender, MouseEventArgs e)
        {

        }
    }
}
/* UIE_SelectionBindingElement
 * 
 * End of File
 */