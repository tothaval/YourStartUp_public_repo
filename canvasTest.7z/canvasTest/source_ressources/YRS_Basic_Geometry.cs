﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Shapes;

namespace YourStartUp
{
    class YRS_Basic_Geometry
    {
        public SolidColorBrush fillColor { get; set; }
        public SolidColorBrush strokeColor { get; set; }


        public YRS_Basic_Geometry()
        {

        }

        public double avoidNegativity(double value)
        {
            if (value < 0)
            {
                value = value * (-1);
            }

            return value;
        }

        public Ellipse drawSimpleCircle(double width, double height)
        {
            Ellipse ell = new Ellipse();

            ell.Height = avoidNegativity(height);
            ell.Width = avoidNegativity(width);

            ell.StrokeThickness = 2;
                        
            ell.Stroke = strokeColor;
            ell.Fill = fillColor;

            return ell;            
        }

        public Polygon drawSimpleLine(double width, double height)
        {
            Polygon pol = new Polygon();

            System.Windows.Point Point1 = new System.Windows.Point (0,0);
            System.Windows.Point Point2 = new System.Windows.Point(0, 0);
            System.Windows.Point Point3 = new System.Windows.Point(0, 0);
            System.Windows.Point Point4 = new System.Windows.Point(0, 0);
            System.Windows.Point Point5 = new System.Windows.Point(0, 0);

            if (avoidNegativity(width) > avoidNegativity(height))
            {
                Point1 = new System.Windows.Point(0, 0);
                Point2 = new System.Windows.Point(width, 0);                
                Point3 = new System.Windows.Point(width, 4);
                Point4 = new System.Windows.Point(0, 4);
                Point5 = new System.Windows.Point(0, 0);

            }
            else if (avoidNegativity(height) > avoidNegativity(width))
            {
                Point1 = new System.Windows.Point(0, 0);
                Point2 = new System.Windows.Point(0, height);
                Point3 = new System.Windows.Point(4, height);
                Point4 = new System.Windows.Point(4, 0);
                Point5 = new System.Windows.Point(0, 0);
            }
            else if (avoidNegativity(width) == avoidNegativity(height) && (width > 0 || height > 0) )
            {
                Point1 = new System.Windows.Point(0, 2);
                Point2 = new System.Windows.Point(width, height);
                Point3 = new System.Windows.Point(width + 3, height - 2);
                Point4 = new System.Windows.Point(0 + 3, 0);
                Point5 = new System.Windows.Point(0, 2);
            }
            else if (avoidNegativity(width) == avoidNegativity(height) && (width < 0 || height < 0))
            {
                Point1 = new System.Windows.Point(width * (-1) - 3, 0 );
                Point2 = new System.Windows.Point(0, height * (-1));
                Point3 = new System.Windows.Point(0,(height * (-1)) - 2);
                Point4 = new System.Windows.Point(0 -3 , (height * (-1)) - 2);
                Point5 = new System.Windows.Point((width * (-1)) - 3, 0);
            }

            pol.Points.Add(Point1);
            pol.Points.Add(Point2);
            pol.Points.Add(Point3);
            pol.Points.Add(Point4);
            pol.Points.Add(Point5);
            
            pol.StrokeThickness = 2;

            pol.Stroke = strokeColor;
            pol.Fill = fillColor;

            pol.StrokeThickness = 2;

            return pol;
        }


        public Rectangle drawSimpleRectangle(double width, double height)
        {
            Rectangle rec = new Rectangle();
            
            rec.Height = avoidNegativity(height);
            rec.Width = avoidNegativity(width);
            
            rec.StrokeThickness = 2;

            rec.Stroke = strokeColor;
            rec.Fill = fillColor;

            rec.StrokeThickness = 2;

            return rec;
        }

        public Polygon drawSimpleTriangle(double width, double height)
        {
            Polygon pol = new Polygon();

            System.Windows.Point Point1 = new System.Windows.Point(0, 0);
            System.Windows.Point Point2 = new System.Windows.Point(0, height);
            System.Windows.Point Point3 = new System.Windows.Point(width, height);
            System.Windows.Point Point4 = new System.Windows.Point(0, 0);

            pol.Points.Add(Point4);
            pol.Points.Add(Point3);
            pol.Points.Add(Point2);
            pol.Points.Add(Point1);

            pol.StrokeThickness = 2;

            pol.Stroke = strokeColor;
            pol.Fill = fillColor;

            pol.StrokeThickness = 2;

            return pol;
        }
    }
}
