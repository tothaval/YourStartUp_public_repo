﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für UIE_CascadeButton.xaml
    /// </summary>
    public partial class UIE_CascadeButton : UserControl
    {
        YRS_Basic_Geometry geom = new YRS_Basic_Geometry();

        private int elliCounter = 0;
        private int lineCounter = 0;
        private int rectCounter = 0;
        private int triCounter = 0;        
         
        public UIE_CascadeButton()
        {
            InitializeComponent();
        }

        private void clearCanvas()
        {
            elliCounter = 0;
            lineCounter = 0;
            rectCounter = 0;
            triCounter = 0;

            uie_cascade_button_canvas.Children.Clear();
            uie_cascade_button_canvas.MinHeight = 20;
        }


        private Ellipse createEllipseIcon(SolidColorBrush strokeColor, SolidColorBrush fillColor)
        {
            Ellipse elli = new Ellipse();

            elli.Name = $"uie_cnv_rect{rectCounter}";
            elliCounter++;

            elli.Width = 30;
            elli.Height = 10;

            elli.Fill = fillColor;
            elli.Stroke = strokeColor;
            elli.StrokeThickness = 2;

            return elli;
        }

        public void createLineIcon(SolidColorBrush strokeColor, SolidColorBrush fillColor)
        {
            clearCanvas();

            geom.fillColor = fillColor;
            geom.strokeColor = strokeColor;

            Polygon line_diago = geom.drawSimpleLine(14, 14);
            Polygon line_horiz = geom.drawSimpleLine(20, 0);
            Polygon line_verti = geom.drawSimpleLine(0, 20);

            line_diago.StrokeThickness = 0;
            line_horiz.StrokeThickness = 0;
            line_verti.StrokeThickness = 0;

            line_diago.Stroke = fillColor;
            line_horiz.Stroke = fillColor;
            line_verti.Stroke = fillColor;

            line_diago.Fill = strokeColor;
            line_horiz.Fill = strokeColor;
            line_verti.Fill = strokeColor;

            line_diago.Name = $"uie_cnv_line_diago{lineCounter}";                              
            line_horiz.Name = $"uie_cnv_line_horiz{lineCounter}";
            line_verti.Name = $"uie_cnv_line_verti{lineCounter}";

            lineCounter++;

            Canvas.SetLeft(line_diago, 5);            
            Canvas.SetLeft(line_horiz, 5);
            Canvas.SetLeft(line_verti, 5);

            Canvas.SetTop(line_diago, 0);
            Canvas.SetTop(line_horiz, 0);
            Canvas.SetTop(line_verti, 0);

            Canvas.SetZIndex(line_diago, 60);
            Canvas.SetZIndex(line_horiz, 20);
            Canvas.SetZIndex(line_verti, 40);

            uie_cascade_button_canvas.Children.Add(line_diago);
            uie_cascade_button_canvas.Children.Add(line_horiz);
            uie_cascade_button_canvas.Children.Add(line_verti);

        }


        private Rectangle createRectangleIcon(SolidColorBrush strokeColor, SolidColorBrush fillColor)
        {
            Rectangle rect = new Rectangle();

            rect.Name = $"uie_cnv_rect{rectCounter}";
            rectCounter++;

            rect.Width = 30;
            rect.Height = 10;

            rect.Fill = fillColor;
            rect.Stroke = strokeColor;
            rect.StrokeThickness = 2;

            return rect;
        }

        private Polygon createTriangleIcon(SolidColorBrush strokeColor, SolidColorBrush fillColor, int width = 20, int height = 10)
        {
            Polygon pygon = new Polygon();

            pygon.Name = $"uie_cnv_tria{triCounter}";
            triCounter++;

            // Create a collection of points for a polyline  
            System.Windows.Point Point1 = new System.Windows.Point(0, 0);
            System.Windows.Point Point2 = new System.Windows.Point(0, height);
            System.Windows.Point Point3 = new System.Windows.Point(width, height);
            System.Windows.Point Point4 = new System.Windows.Point(0, 0);

            pygon.Points.Add(Point4);
            pygon.Points.Add(Point3);
            pygon.Points.Add(Point2);
            pygon.Points.Add(Point1);

            pygon.Fill = fillColor;
            pygon.Stroke = strokeColor;
            pygon.StrokeThickness = 2;

            return pygon;
        }

        public void changeIconTo_cascadingEllipses(SolidColorBrush strokeColor, SolidColorBrush fillColor)
        {
            clearCanvas();

            Ellipse elli = createEllipseIcon(strokeColor, fillColor);
            Ellipse elli1 = createEllipseIcon(strokeColor, fillColor);
            Ellipse elli2 = createEllipseIcon(strokeColor, fillColor);

            Canvas.SetLeft(elli, 0);
            Canvas.SetLeft(elli1, 5);
            Canvas.SetLeft(elli2, 10);

            Canvas.SetTop(elli, 0);
            Canvas.SetTop(elli1, 5);
            Canvas.SetTop(elli2, 10);

            Canvas.SetZIndex(elli, 60);
            Canvas.SetZIndex(elli1, 40);
            Canvas.SetZIndex(elli2, 20);

            uie_cascade_button_canvas.Children.Add(elli);
            uie_cascade_button_canvas.Children.Add(elli1);
            uie_cascade_button_canvas.Children.Add(elli2);
        }

        public void changeIconTo_cascadingRectangles(SolidColorBrush strokeColor, SolidColorBrush fillColor)
        {
            clearCanvas();

            Rectangle rect = createRectangleIcon(strokeColor, fillColor);
            Rectangle rect1 = createRectangleIcon(strokeColor, fillColor);
            Rectangle rect2 = createRectangleIcon(strokeColor, fillColor);

            Canvas.SetLeft(rect, 0);
            Canvas.SetLeft(rect1, 5);
            Canvas.SetLeft(rect2, 10);

            Canvas.SetTop(rect, 0);
            Canvas.SetTop(rect1, 5);
            Canvas.SetTop(rect2, 10);

            Canvas.SetZIndex(rect, 60);
            Canvas.SetZIndex(rect1, 40);
            Canvas.SetZIndex(rect2, 20);

            uie_cascade_button_canvas.Children.Add(rect);
            uie_cascade_button_canvas.Children.Add(rect1);
            uie_cascade_button_canvas.Children.Add(rect2);
        }

        public void changeIconTo_cascadingTriangles(SolidColorBrush strokeColor, SolidColorBrush fillColor)
        {
            clearCanvas();

            Polygon tri = createTriangleIcon(strokeColor, fillColor, 20, 15);
            Polygon tri1 = createTriangleIcon(strokeColor, fillColor, 20, 15);
            Polygon tri2 = createTriangleIcon(strokeColor, fillColor, 20, 15);
            
            Canvas.SetLeft(tri, 3);
            Canvas.SetLeft(tri1, 9);
            Canvas.SetLeft(tri2, 18);

            Canvas.SetTop(tri, 0);
            Canvas.SetTop(tri1, 3);
            Canvas.SetTop(tri2, 6);

            Canvas.SetZIndex(tri, 60);
            Canvas.SetZIndex(tri1, 40);
            Canvas.SetZIndex(tri2, 20);

            uie_cascade_button_canvas.Children.Add(tri);
            uie_cascade_button_canvas.Children.Add(tri1);
            uie_cascade_button_canvas.Children.Add(tri2);
        }

        public void changeIconTo_singularTriangle(SolidColorBrush strokeColor, SolidColorBrush fillColor)
        {
            clearCanvas();

            Polygon tria = createTriangleIcon(strokeColor, fillColor, 30, 20);

            Canvas.SetLeft(tria, 5);

            Canvas.SetTop(tria, 0);

            Canvas.SetZIndex(tria, 40);

            uie_cascade_button_canvas.Children.Add(tria);
        }

        public void changeIconTo_singularEllipse(SolidColorBrush strokeColor, SolidColorBrush fillColor)
        {
            clearCanvas();

            Ellipse elli = createEllipseIcon(strokeColor, fillColor);

            elli.Width = 40;
            elli.Height = 20;

            Canvas.SetLeft(elli, 0);

            Canvas.SetTop(elli, 0);

            Canvas.SetZIndex(elli, 40);

            uie_cascade_button_canvas.Children.Add(elli);
        }

        public void changeIconTo_singularRectangle(SolidColorBrush strokeColor, SolidColorBrush fillColor)
        {
            clearCanvas();

            Rectangle rect = createRectangleIcon(strokeColor, fillColor);

            rect.Width = 40;
            rect.Height = 20;

            Canvas.SetLeft(rect, 0);
            
            Canvas.SetTop(rect, 0);
            
            Canvas.SetZIndex(rect, 40);
            
            uie_cascade_button_canvas.Children.Add(rect);            
        }
    }
}
