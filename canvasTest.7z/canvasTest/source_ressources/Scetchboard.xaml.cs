﻿/* YourStartUp scetchboard tool  
 * 
 * Pur:         scetchboard window, offering a basic mind map and scetch functionality
 * Toc:         2022 (august <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      taranis.sk@gmail.com
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für Scetchboard.xaml
    /// </summary>
    public partial class Scetchboard : Window
    {
        ScetchboardTexts scetchboard = new ScetchboardTexts();
        YRS_ColorFeature yrs_color_feature = new YRS_ColorFeature();

        // invoked classes
        private ConfigData config = new ConfigData();
        private YRS_Basic_Geometry geom = new YRS_Basic_Geometry();

        // drawn objects drag state
        private bool drag = false;
        private bool drag_canvas = false;
        private bool drag_ellp = false;
        private bool drag_line = false;
        private bool drag_triangle = false;

        private bool dragging;
        private bool dragState = false;

        // colors 
        Color color_0 = Colors.Transparent;
        Color color_1 = Colors.Red;
        Color color_2 = Colors.Blue;

        // success of textbox parsing
        private bool parseFail = false;

        // drawn objects dimensions, angle, z-index, cascade count and psbly text
        int cascadeAmount = 5;
        int elementHeight = 50;
        int elementWidth = 100;
        int elementZindex = 0;

        double elementAngle = 0;

        StringBuilder elementText = new StringBuilder();

        // naming counters for drag drawing 
        private long dragEllipseID = 0;
        private long dragRectangleID = 0;
        // private long dragTriangleID = 0;

        // key states for drawing (s free hand, x rectangles, y ellipses)
        private bool s_pressed = false;
        private bool x_pressed = false;
        private bool y_pressed = false;

        // drawn objects moving positions
        private Point scetchPoint = new Point();

        private Point clickV;

        private Point startPoint;

        private Point startPoint_dragEllipse;
        private Point startPoint_dragRectangle;

        private Point startPoint_ellp;

        // geometry
        private Ellipse dragEllipse;
        private Rectangle dragRectangle;
        private Shape selectedShape;

        // Research Ressources 

        /* https://www.codeproject.com/Articles/148503/Simple-Drag-Selection-in-WPF         
         * 
         * https://stackoverflow.com/questions/16037753/wpf-drawing-on-canvas-with-mouse-events mit maus zeichnen
         * 
         */

        public Scetchboard()
        {
            InitializeComponent();
        }

        // methods
        #region private methods
        private void check_rbGroup_LinearGradientOrientation(Shape _shape)
        {

            if (rb_orientationBottom.IsChecked == true)
            {
                _shape.Fill = new LinearGradientBrush(
                    color_1,
                    color_2,
                    90);
            }
            else if (rb_orientationTop.IsChecked == true)
            {
                _shape.Fill = new LinearGradientBrush(
                    color_2,
                    color_1,
                    90);
            }
            else if (rb_orientationLeft.IsChecked == true)
            {
                _shape.Fill = new LinearGradientBrush(
                    color_1,
                    color_2,
                    0
                    );
            }
            else if (rb_orientationRight.IsChecked == true)
            {
                _shape.Fill = new LinearGradientBrush(
                    color_2,
                    color_1,
                    0
                    );
            }
        }

        private void determineColorScheme(Shape _shape)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                check_rbGroup_LinearGradientOrientation(_shape);
            }
            else if (rb_solidBrush.IsChecked == true)
            {
                solidColorFill(_shape);
            }
        }

        // draw stuff
        #region drawing
        private void drawCascade_Ellipses()
        {
            parseTextboxes();

            for (int i = 0; i < cascadeAmount; i++)
            {
                Ellipse cell = drawSimpleEllipse();

                drawShape(cell, i);
            }
        }

        private void drawCascade_Rectangles()
        {
            parseTextboxes();

            for (int i = 0; i < cascadeAmount; i++)
            {
                Rectangle crec = drawSimpleRectangle();

                drawShape(crec, i);
            }
        }

        private void drawCascade_Triangles()
        {
            parseTextboxes();

            for (int i = 0; i < cascadeAmount; i++)
            {
                // Polygon tria = drawSimpleTriangle();

                Polygon tria = drawSimpleTriangle();

                drawShape(tria, i);
            }
        }


        private void drawShape(Shape shape, int counter = 1)
        {
            determineColorScheme(shape);

            Canvas.SetLeft(shape, 50 * counter);
            Canvas.SetTop(shape, 25 * counter);

            Panel.SetZIndex(shape, elementZindex);
        }



        private Ellipse drawSimpleEllipse()
        {
            geom.fillColor = config.backColor;
            geom.strokeColor = config.foreColor;

            parseTextboxes();

            Ellipse ell = geom.drawSimpleCircle(elementWidth, elementHeight);

            drawShape(ell);

            rotateShape(ell);

            ell.MouseDown += Ell_MouseDown;
            ell.MouseMove += Ell_MouseMove;
            ell.MouseUp += Ell_MouseUp;

            canvas.Children.Add(ell);

            return ell;
        }


        private Polygon drawSimpleLine()
        {
            geom.fillColor = config.backColor;
            geom.strokeColor = config.foreColor;

            parseTextboxes();

            Polygon lin = geom.drawSimpleLine(elementWidth, elementHeight);

            drawShape(lin);

            rotateShape(lin);

            lin.MouseDown += pygon_MouseDown;
            lin.MouseMove += pygon_MouseMove;
            lin.MouseUp += pygon_MouseUp;

            canvas.Children.Add(lin);

            return lin;
        }

        private Rectangle drawSimpleRectangle()
        {
            geom.fillColor = config.backColor;
            geom.strokeColor = config.foreColor;

            parseTextboxes();

            Rectangle rec = geom.drawSimpleRectangle(elementWidth, elementHeight);

            drawShape(rec);

            rotateShape(rec);

            rec.MouseDown += Rectangle_MouseDown;
            rec.MouseMove += Rectangle_MouseMove;
            rec.MouseUp += Rectangle_MouseUp;

            canvas.Children.Add(rec);

            return rec;
        }

        private Polygon drawSimpleTriangle()
        {
            geom.fillColor = config.backColor;
            geom.strokeColor = config.foreColor;

            parseTextboxes();

            Polygon pol;

            if (elementAngle == 0 && (elementHeight < 0 || elementWidth < 0))
            {
                pol = geom.drawSimpleTriangle(elementWidth, elementHeight);
                drawShape(pol);
            }
            else if (elementAngle != 0 && (elementHeight < 0 || elementWidth < 0))
            {
                pol = geom.drawSimpleTriangle(geom.avoidNegativity(elementWidth), geom.avoidNegativity(elementHeight));
                drawShape(pol);
                rotateShape(pol);
            }
            else
            {
                pol = geom.drawSimpleTriangle(elementWidth, elementHeight);
                drawShape(pol);
                rotateShape(pol);
            }

            pol.MouseDown += pygon_MouseDown;
            pol.MouseMove += pygon_MouseMove;
            pol.MouseUp += pygon_MouseUp;

            canvas.Children.Add(pol);

            return pol;
        }
        #endregion drawing


        // load stuff
        #region loading
        private void loadConfig()
        {
            config.loadConfig();

            ScetchboardWindow.Resources.Remove("buttonColor");
            ScetchboardWindow.Resources.Remove("buttonFont");
            ScetchboardWindow.Resources.Remove("highlight");
            ScetchboardWindow.Resources.Remove("radius");

            ScetchboardWindow.Resources.Add("buttonColor", config.btnBackColor);
            ScetchboardWindow.Resources.Add("buttonFont", config.btnForeColor);
            ScetchboardWindow.Resources.Add("highlight", config.highlightColor);
            ScetchboardWindow.Resources.Add("radius", new CornerRadius(config.borderRadius));
        }

        private void loadColorFeature()
        {
            wrp_colorpicker.Children.Add(yrs_color_feature);
        }

        private void loadDesign()
        {
            ScetchboardWindow.Background = new SolidColorBrush(Colors.Transparent);

            WindowBorder.Background = config.backColor;
            WindowBorder.BorderBrush = config.foreColor;
            WindowBorder.BorderThickness = new Thickness(3);
            WindowBorder.CornerRadius = new CornerRadius(config.borderRadius);

            canvas.Background = config.canvasColor;
            wrpMenu.Background = config.canvasMenuColor;
            wrpRadioButtons.Background = config.canvasMenuColor;
            wrpTextBoxes.Background = config.canvasMenuColor;

            grdSplitter.Background = config.btnHideMenuColor;

            foreach (TextBox tb in wrpTextBoxes.Children)
            {
                tb.Background = config.textBox;
                tb.Foreground = config.textBoxFont;
            }
        }

        private void load_rectangleButton(Style style)
        {
            UIE_CascadeButton rec = new UIE_CascadeButton();
            rec.uie_cascade_button.Click += Uie_rectangle_button_Click;
            rec.uie_cascade_button.Background = new SolidColorBrush(Colors.Transparent);
            rec.uie_cascade_button.Style = style;

            rec.uie_cascade_button_border.CornerRadius = new CornerRadius(config.borderRadius);
            rec.uie_cascade_button_border.BorderThickness = new Thickness(1);
            rec.uie_cascade_button_border.BorderBrush = config.btnForeColor;
            rec.uie_cascade_button_border.Background = config.btnBackColor;

            rec.changeIconTo_singularRectangle(config.btnForeColor, config.btnBackColor);

            wrpMenu.Children.Add(rec);
        }

        private void load_rectangleCascade(Style style)
        {
            UIE_CascadeButton cas = new UIE_CascadeButton();
            cas.uie_cascade_button.Click += Uie_cascade_button_Click;
            cas.uie_cascade_button.Background = new SolidColorBrush(Colors.Transparent);
            cas.uie_cascade_button.Style = style;

            cas.uie_cascade_button_border.CornerRadius = new CornerRadius(config.borderRadius);
            cas.uie_cascade_button_border.BorderThickness = new Thickness(1);
            cas.uie_cascade_button_border.BorderBrush = config.btnForeColor;
            cas.uie_cascade_button_border.Background = config.btnBackColor;

            cas.changeIconTo_cascadingRectangles(config.btnForeColor, config.btnBackColor);

            wrpMenu.Children.Add(cas);
        }

        private void load_circleButton(Style style)
        {
            UIE_CascadeButton cir = new UIE_CascadeButton();
            cir.uie_cascade_button.Click += Uie_circle_button_Click;
            cir.uie_cascade_button.Background = new SolidColorBrush(Colors.Transparent);
            cir.uie_cascade_button.Style = style;

            cir.uie_cascade_button_border.CornerRadius = new CornerRadius(config.borderRadius);
            cir.uie_cascade_button_border.BorderThickness = new Thickness(1);
            cir.uie_cascade_button_border.Background = config.btnBackColor;
            cir.uie_cascade_button_border.BorderBrush = config.btnForeColor;

            cir.changeIconTo_singularEllipse(config.btnForeColor, config.btnBackColor);

            wrpMenu.Children.Add(cir);
        }

        private void load_circleCascade(Style style)
        {
            UIE_CascadeButton cas = new UIE_CascadeButton();
            cas.uie_cascade_button.Click += Uie_cascade_ellipses_button_Click;
            cas.uie_cascade_button.Background = new SolidColorBrush(Colors.Transparent);
            cas.uie_cascade_button.Style = style;

            cas.uie_cascade_button_border.CornerRadius = new CornerRadius(config.borderRadius);
            cas.uie_cascade_button_border.BorderThickness = new Thickness(1);
            cas.uie_cascade_button_border.Background = config.btnBackColor;
            cas.uie_cascade_button_border.BorderBrush = config.btnForeColor;

            cas.changeIconTo_cascadingEllipses(config.btnForeColor, config.btnBackColor);

            wrpMenu.Children.Add(cas);
        }

        private void load_triangleButton(Style style)
        {
            UIE_CascadeButton tri = new UIE_CascadeButton();
            tri.uie_cascade_button.Click += Uie_triangle_button_Click;
            tri.uie_cascade_button.Background = new SolidColorBrush(Colors.Transparent);
            tri.uie_cascade_button.Style = style;

            tri.uie_cascade_button_border.CornerRadius = new CornerRadius(config.borderRadius);
            tri.uie_cascade_button_border.BorderThickness = new Thickness(1);
            tri.uie_cascade_button_border.Background = config.btnBackColor;
            tri.uie_cascade_button_border.BorderBrush = config.btnForeColor;

            tri.changeIconTo_singularTriangle(config.btnForeColor, config.btnBackColor);

            wrpMenu.Children.Add(tri);
        }

        private void load_triangleCascade(Style style)
        {
            UIE_CascadeButton cas = new UIE_CascadeButton();
            cas.uie_cascade_button.Click += Uie_cascade_triangles_button_Click;
            cas.uie_cascade_button.Background = new SolidColorBrush(Colors.Transparent);
            cas.uie_cascade_button.Style = style;

            cas.uie_cascade_button_border.CornerRadius = new CornerRadius(config.borderRadius);
            cas.uie_cascade_button_border.BorderThickness = new Thickness(1);
            cas.uie_cascade_button_border.Background = config.btnBackColor;
            cas.uie_cascade_button_border.BorderBrush = config.btnForeColor;

            cas.changeIconTo_cascadingTriangles(config.btnForeColor, config.btnBackColor);

            wrpMenu.Children.Add(cas);
        }

        private void load_lineButton(Style style)
        {
            UIE_CascadeButton lin = new UIE_CascadeButton();
            lin.uie_cascade_button.Click += Uie_line_button_Click;
            lin.uie_cascade_button.Background = new SolidColorBrush(Colors.Transparent);
            lin.uie_cascade_button.Style = style;

            lin.uie_cascade_button_border.CornerRadius = new CornerRadius(config.borderRadius);
            lin.uie_cascade_button_border.BorderThickness = new Thickness(1);
            lin.uie_cascade_button_border.Background = config.btnBackColor;
            lin.uie_cascade_button_border.BorderBrush = config.btnForeColor;

            lin.createLineIcon(config.btnForeColor, config.btnBackColor);

            wrpMenu.Children.Add(lin);
        }


        private void loadMenuButtons()
        {
            Style _style = this.FindResource("buttonStyle") as Style;
            wrpMenu.Orientation = Orientation.Horizontal;

            load_rectangleButton(_style);

            load_rectangleCascade(_style);

            load_circleButton(_style);

            load_circleCascade(_style);

            load_triangleButton(_style);

            load_triangleCascade(_style);

            load_lineButton(_style);
        }

        #endregion loading

        // parse textbox contents into variables
        private void parseTextboxes()
        {
            string message = "";

            try
            {
                cascadeAmount = Int32.Parse(tbxAmount.Text);
                elementHeight = Int32.Parse(tbxHeight.Text);
                elementWidth = Int32.Parse(tbxWidth.Text);
                elementZindex = Int32.Parse(tbxZindex.Text);

                elementAngle = Double.Parse(tbxAngle.Text);

                elementText.Append(tbxItemText.Text);

                parseFail = false;

                parseFail = false;
            }
            catch (Exception e)
            {
                parseFail = true;
                message = e.Message;
            }

            if (parseFail == true)
            {
                MessageBox.Show($"{message}{scetchboard.textbox_parseFail_exception()}");
            }

        }

        private void rotateShape(Shape shape)
        {

            if (parseFail == false)
            {

                if (elementAngle == 0)
                {
                    shape.Height = elementHeight;
                    shape.Width = elementWidth;
                }
                else if (elementAngle == 90)
                {
                    shape.Height = elementWidth;
                    shape.Width = elementHeight;
                }
                else
                {
                    RotateTransform rt = new RotateTransform();

                    rt.CenterX = elementWidth * 0.5;
                    rt.CenterY = elementHeight * 0.5;                  

                    rt.Angle = elementAngle;

                    shape.Height = geom.avoidNegativity(elementHeight);
                    shape.Width = geom.avoidNegativity(elementWidth);

                    shape.RenderTransform = rt;
                }

            }
            else if (parseFail == true)
            {
                shape.Width = 100;
                shape.Height = 50;
            }
        }

        private void setZindexOnShape(Shape shape)
        {
            parseTextboxes();

            Panel.SetZIndex(shape, elementZindex);
        }

        private Point simulatePadding(Point pnt)
        {
            if (pnt.X < 5)
            {
                pnt.X = 5;
            }
            else if (pnt.X > canvas.ActualWidth - 5)
            {
                pnt.X = canvas.ActualWidth - 5;
            }

            if (pnt.Y < 5)
            {
                pnt.Y = 5;
            }
            else if (pnt.Y > canvas.ActualHeight - 5)
            {
                pnt.Y = canvas.ActualHeight - 5;
            }
            else if (pnt.X > canvas.ActualWidth || pnt.X < 5
                || pnt.Y > canvas.ActualHeight || pnt.Y < 5)
            {
                if (x_pressed == true)
                {
                    x_pressed_MouseUp();
                }
                else if (y_pressed == true)
                {
                    y_pressed_MouseUp();
                }
            }

            return pnt;
        }

        private void setColorOnShape(Shape shape)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                check_rbGroup_LinearGradientOrientation(shape);
            }
            else if (rb_solidBrush.IsChecked == true)
            {
                solidColorFill(shape);
            }
        }

        private void solidColorFill(Shape _shape)
        {
            color_0 = yrs_color_feature.getColor;

            _shape.Fill = new SolidColorBrush(color_0);
        }

        // drag drawing logic
        #region drag drawing logic

        // on mouse down
        private void s_pressed_MouseDown(MouseEventArgs _e)
        {
            if (s_pressed == false)
            {

            }
            else if (s_pressed == true)
            {
                if (_e.LeftButton == MouseButtonState.Pressed)
                    scetchPoint = _e.GetPosition(canvas);
            }
        }

        private void x_pressed_MouseDown(MouseEventArgs _e)
        {
            if (x_pressed == false)
            {

            }
            else if (x_pressed == true)
            {
                dragState = true;

                startPoint_dragRectangle = _e.GetPosition(canvas);

                dragRectangle = new Rectangle
                {
                    Fill = config.backColor,
                    Stroke = config.foreColor,
                    StrokeThickness = 2
                };

                Canvas.SetLeft(dragRectangle, startPoint_dragRectangle.X);
                Canvas.SetTop(dragRectangle, startPoint_dragRectangle.Y);

                canvas.Children.Add(dragRectangle);
            }
        }

        private void y_pressed_MouseDown(MouseEventArgs _e)
        {
            if (y_pressed == false)
            {

            }
            else if (y_pressed == true)
            {
                dragState = true;

                startPoint_dragEllipse = _e.GetPosition(canvas);

                dragEllipse = new Ellipse
                {
                    Fill = config.backColor,
                    Stroke = config.foreColor,
                    StrokeThickness = 3
                };
                Canvas.SetLeft(dragEllipse, startPoint_dragEllipse.X);
                Canvas.SetTop(dragEllipse, startPoint_dragEllipse.Y);
                canvas.Children.Add(dragEllipse);
            }
        }

        // on mouse move

        private void s_pressed_MouseMove(MouseEventArgs _e)
        {
            if (_e.LeftButton == MouseButtonState.Pressed)
            {
                if (s_pressed == true)
                {
                    Line line = new Line();

                    line.StrokeThickness = 20;
                    line.Stroke = new SolidColorBrush(color_0);
                    line.X1 = scetchPoint.X;
                    line.Y1 = scetchPoint.Y;
                    line.X2 = _e.GetPosition(canvas).X;
                    line.Y2 = _e.GetPosition(canvas).Y;

                    scetchPoint = _e.GetPosition(canvas);

                    canvas.Children.Add(line);
                }
            }
        }

        private void x_pressed_MouseMove(MouseEventArgs _e)
        {
            if (x_pressed == false)
            {

            }
            else if (x_pressed == true)
            {
                if (_e.LeftButton == MouseButtonState.Released || dragState == false)
                {
                    if (dragRectangle != null)
                    {
                        dragRectangleID++;

                        dragRectangle.Fill = config.btnBackColor;
                        dragRectangle.Stroke = config.btnForeColor;
                        dragRectangle.StrokeThickness = 2;

                        dragRectangle.Name = $"dragRectangle_{dragRectangleID.ToString()}";

                        dragRectangle.MouseDown += Rectangle_MouseDown;
                        dragRectangle.MouseMove += Rectangle_MouseMove;
                        dragRectangle.MouseUp += Rectangle_MouseUp;
                    }

                    dragState = false;

                    return;
                }

                Point pos = _e.GetPosition(canvas);

                pos = simulatePadding(pos);

                double x = Math.Min(pos.X, startPoint_dragRectangle.X);
                double y = Math.Min(pos.Y, startPoint_dragRectangle.Y);

                double w = Math.Max(pos.X, startPoint_dragRectangle.X) - x;
                double h = Math.Max(pos.Y, startPoint_dragRectangle.Y) - y;

                dragRectangle.Width = w;
                dragRectangle.Height = h;

                Canvas.SetLeft(dragRectangle, x);
                Canvas.SetTop(dragRectangle, y);
            }
        }

        private void y_pressed_MouseMove(MouseEventArgs _e)
        {
            if (y_pressed == false)
            {

            }
            else if (y_pressed == true)
            {
                if (_e.LeftButton == MouseButtonState.Released || dragState == false)
                {

                    if (dragEllipse != null)
                    {
                        dragEllipseID++;

                        dragEllipse.Fill = config.foreColor;
                        dragEllipse.Stroke = config.backColor;
                        dragEllipse.StrokeThickness = 3;

                        dragEllipse.Name = $"dragEllipse{dragEllipseID.ToString()}";

                        dragEllipse.MouseDown += Ell_MouseDown;
                        dragEllipse.MouseMove += Ell_MouseMove;
                        dragEllipse.MouseUp += Ell_MouseUp;
                    }

                    dragState = false;

                    //x_pressed = false;
                    return;
                }

                Point pos = _e.GetPosition(canvas);

                pos = simulatePadding(pos);

                double x = Math.Min(pos.X, startPoint_dragEllipse.X);
                double y = Math.Min(pos.Y, startPoint_dragEllipse.Y);

                double w = Math.Max(pos.X, startPoint_dragEllipse.X) - x;
                double h = Math.Max(pos.Y, startPoint_dragEllipse.Y) - y;

                dragEllipse.Width = w;
                dragEllipse.Height = h;

                Canvas.SetLeft(dragEllipse, x);
                Canvas.SetTop(dragEllipse, y);
            }
        }

        // on mouse up
        private void x_pressed_MouseUp()
        {
            drag = false;
            drag_canvas = false;
            drag_ellp = false;

            drag_line = false;
            drag_triangle = false;

            dragging = false;

            if (x_pressed == false)
            {

            }
            else if (x_pressed == true)
            {
                dragRectangleID++;

                dragRectangle.Fill = config.btnBackColor;
                dragRectangle.Stroke = config.btnForeColor;
                dragRectangle.StrokeThickness = 2;

                dragRectangle.Name = $"dragRectangle_{dragRectangleID.ToString()}";

                dragRectangle.MouseDown += Rectangle_MouseDown;
                dragRectangle.MouseMove += Rectangle_MouseMove;
                dragRectangle.MouseUp += Rectangle_MouseUp;

                dragState = false;
            }
        }

        private void y_pressed_MouseUp()
        {

            drag = false;
            drag_canvas = false;
            drag_ellp = false;

            drag_line = false;
            drag_triangle = false;

            dragging = false;

            if (y_pressed == false)
            {

            }
            else if (y_pressed == true)
            {
                dragEllipseID++;

                dragEllipse.Fill = config.foreColor;
                dragEllipse.Stroke = config.backColor;
                dragEllipse.StrokeThickness = 3;

                dragEllipse.Name = $"dragEllipse{dragEllipseID.ToString()}";

                dragEllipse.MouseDown += Ell_MouseDown;
                dragEllipse.MouseMove += Ell_MouseMove;
                dragEllipse.MouseUp += Ell_MouseUp;

                dragState = false;
            }
        }
        #endregion drag drawing logic

        #endregion private methods



        // events
        #region events

        // on canvas
        private void canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                if (s_pressed == false && x_pressed == false && y_pressed == false)
                {
                    ScetchboardWindow.DragMove();
                }
                else
                {
                    s_pressed_MouseDown(e);

                    x_pressed_MouseDown(e);

                    y_pressed_MouseDown(e);
                }

                e.Handled = true;
            }
        }

        private void canvas_MouseMove(object sender, MouseEventArgs e)
        {
            s_pressed_MouseMove(e);

            x_pressed_MouseMove(e);

            y_pressed_MouseMove(e);

            e.Handled = true;
        }

        private void canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                x_pressed_MouseUp();

                y_pressed_MouseUp();

                e.Handled = true;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                drag = false;
                drag_canvas = false;
                drag_ellp = false;
                drag_line = false;
                drag_triangle = false;

                dragging = false;
            }
        }


        // on ellipses
        private void Ell_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Ellipse ellp = (Ellipse)sender;

            Panel.SetZIndex(ellp, 1000);

            if (e.ChangedButton == MouseButton.Middle)
            {
                // start dragging
                drag_ellp = true;
                // save start point of dragging
                startPoint_ellp = Mouse.GetPosition(canvas);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                canvas.Children.Remove(ellp);

                e.Handled = true;

                GC.Collect(0);
            }

            if (e.ChangedButton == MouseButton.Left)
            {
                setColorOnShape(ellp);

                setZindexOnShape(ellp);

                e.Handled = true;
            }
        }

        private void Ell_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag_ellp)
            {
                Ellipse draggedEllipse = sender as Ellipse;
                Point newPoint = Mouse.GetPosition(canvas);
                double left = Canvas.GetLeft(draggedEllipse);
                double top = Canvas.GetTop(draggedEllipse);
                Canvas.SetLeft(draggedEllipse, left + (newPoint.X - startPoint_ellp.X));
                Canvas.SetTop(draggedEllipse, top + (newPoint.Y - startPoint_ellp.Y));

                startPoint_ellp = newPoint;
            }
        }

        private void Ell_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Middle)
            {
                Ellipse ellp = (Ellipse)sender;

                drag = false;
                drag_canvas = false;
                drag_ellp = false;
                drag_line = false;
                drag_triangle = false;

                dragging = false;

                Panel.SetZIndex(ellp, 0);
            }
        }


        // on radiobuttons
        private void rb_linearBrush_Checked(object sender, RoutedEventArgs e)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                rb_orientationBottom.IsEnabled = true;

                rb_orientationTop.IsEnabled = true;
                rb_orientationTop.IsChecked = true;

                rb_orientationLeft.IsEnabled = true;

                rb_orientationRight.IsEnabled = true;
            }
        }

        private void rb_solidBrush_Checked(object sender, RoutedEventArgs e)
        {
            if (rb_solidBrush.IsChecked == true)
            {
                rb_orientationBottom.IsEnabled = false;
                rb_orientationBottom.IsChecked = false;

                rb_orientationTop.IsEnabled = false;
                rb_orientationTop.IsChecked = false;

                rb_orientationLeft.IsEnabled = false;
                rb_orientationLeft.IsChecked = false;

                rb_orientationRight.IsEnabled = false;
                rb_orientationRight.IsChecked = false;
            }
        }

        private void pygon_MouseDown(object sender, MouseButtonEventArgs e)
        {
            selectedShape = sender as Shape;

            Panel.SetZIndex(selectedShape, 1000);

            if (e.ChangedButton == MouseButton.Middle)
            {
                //drag = true;
                //// save start point of dragging
                //startPoint = Mouse.GetPosition(canvas);

                //e.Handled = true;

                dragging = true;

                clickV = e.GetPosition(selectedShape);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                canvas.Children.Remove(selectedShape);

                e.Handled = true;

                GC.Collect(0);
            }

            if (e.ChangedButton == MouseButton.Left)
            {
                setColorOnShape(selectedShape);

                setZindexOnShape(selectedShape);

                e.Handled = true;
            }
        }


        private void pygon_MouseMove(object sender, MouseEventArgs e)
        {
            Polygon pygon = selectedShape as Polygon;

            if (dragging)
            {
                //Point newPoint = Mouse.GetPosition(canvas);
                //double left = Canvas.GetLeft(pygon);
                //double top = Canvas.GetTop(pygon);
                Canvas.SetLeft(pygon, e.GetPosition(canvas).X - clickV.X);

                Canvas.SetTop(pygon, e.GetPosition(canvas).Y - clickV.Y);
            }
        }

        private void pygon_MouseUp(object sender, MouseButtonEventArgs e)
        {
            selectedShape = sender as Shape;

            if (e.ChangedButton == MouseButton.Middle)
            {

                //Shape poly = (Shape)sender;

                drag = false;
                drag_canvas = false;
                drag_ellp = false;
                drag_line = false;
                drag_triangle = false;

                dragging = false;

                Panel.SetZIndex(selectedShape, 0);
            }
        }


        // on rectangles
        private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Rectangle rect = (Rectangle)sender;

            Canvas.SetZIndex(rect, 1000);

            if (e.ChangedButton == MouseButton.Middle)
            {
                // start dragging
                drag = true;
                // save start point of dragging
                startPoint = Mouse.GetPosition(canvas);

                e.Handled = true;
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                canvas.Children.Remove(rect);

                e.Handled = true;

                GC.Collect(0);
            }

            if (e.ChangedButton == MouseButton.Left)
            {
                setColorOnShape(rect);
                setZindexOnShape(rect);

                e.Handled = true;
            }
        }




        private void Rectangle_MouseMove(object sender, MouseEventArgs e)
        {
            // if dragging, then adjust rectangle position based on mouse movement
            if (drag)
            {
                Rectangle draggedRectangle = sender as Rectangle;
                Point newPoint = Mouse.GetPosition(canvas);
                double left = Canvas.GetLeft(draggedRectangle);
                double top = Canvas.GetTop(draggedRectangle);
                Canvas.SetLeft(draggedRectangle, left + (newPoint.X - startPoint.X));
                Canvas.SetTop(draggedRectangle, top + (newPoint.Y - startPoint.Y));

                startPoint = newPoint;
            }
        }

        private void Rectangle_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Middle)
            {
                Rectangle rect = (Rectangle)sender;

                drag = false;
                drag_canvas = false;
                drag_ellp = false;
                drag_line = false;
                drag_triangle = false;

                dragging = false;

                Panel.SetZIndex(rect, 0);
            }
        }

        // on Scetchboard main window
        private void ScetchboardWindow_Loaded(object sender, RoutedEventArgs e)
        {
            loadConfig();

            loadDesign();

            loadMenuButtons();

            loadColorFeature();

            rb_linearBrush.IsChecked = true;
            rb_orientationBottom.IsChecked = true;

        }

        // on buttons
        private void Uie_cascade_button_Click(object sender, RoutedEventArgs e)
        {
            drawCascade_Rectangles();
        }

        private void Uie_cascade_ellipses_button_Click(object sender, RoutedEventArgs e)
        {
            drawCascade_Ellipses();
        }

        private void Uie_cascade_triangles_button_Click(object sender, RoutedEventArgs e)
        {
            drawCascade_Triangles();
        }

        private void Uie_circle_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleEllipse();
        }

        private void Uie_line_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleLine();
        }

        private void Uie_rectangle_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleRectangle();
        }

        private void Uie_triangle_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleTriangle();
        }

        // on scetchboard window grid
        private void WindowGrid_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        // on scetchboard window border
        private void WindowBorder_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Border bor = (Border)sender;

            if (e.ChangedButton == MouseButton.Left)
            {
                //if (bor. )
                //{
                ScetchboardWindow.DragMove();
                //}

                e.Handled = true;
            }

            if (e.ChangedButton == MouseButton.Right)
            {

                //OnPreviewMouseRightButtonDown(e);
                //OnPreviewMouseRightButtonUp(e);

                e.Handled = true;

                Close();

                //this.OnPreviewMouseRightButtonDown(e);
                //this.OnPreviewMouseRightButtonUp(e);
            }

        }

        // scetchboard events
        private void ScetchboardWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            GC.Collect(0);
        }

        private void ScetchboardWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.B)
            {
                e.Handled = false;

                canvas.Background = new SolidColorBrush(color_0);

                canvas.UpdateLayout();
            }

            if (e.Key == Key.S)
            {
                e.Handled = false;

                if (y_pressed == true || x_pressed == true)
                {
                    x_pressed = false;
                    y_pressed = false;
                }
            }

            if (e.Key == Key.X)
            {
                //drawSimpleRectangle();
                e.Handled = false;

                if (y_pressed == true || s_pressed == true)
                {
                    s_pressed = false;
                    y_pressed = false;
                }
            }

            if (e.Key == Key.Y)
            {
                //drawSimpleRectangle();
                e.Handled = false;

                if (s_pressed == true || x_pressed == true)
                {
                    s_pressed = false;
                    x_pressed = false;
                }
            }
        }

        private void ScetchboardWindow_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.B)
            {
                e.Handled = true;
            }

            if (e.Key == Key.S)
            {
                if (s_pressed == true)
                {
                    s_pressed = false;
                }
                else if (s_pressed == false)
                {
                    s_pressed = true;
                }

                e.Handled = true;
            }

            if (e.Key == Key.X)
            {
                if (x_pressed == true)
                {
                    x_pressed = false;
                }
                else if (x_pressed == false)
                {
                    x_pressed = true;
                }

                e.Handled = true;
            }

            if (e.Key == Key.Y)
            {
                if (y_pressed == true)
                {
                    y_pressed = false;
                }
                else if (y_pressed == false)
                {
                    y_pressed = true;
                }

                e.Handled = true;
            }
        }

        private void ScetchboardWindow_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                ScetchboardWindow.DragMove();
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                e.Handled = true;

                //Close();
            }
        }

        private void ScetchboardWindow_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                dragState = false;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                drag = false;
                drag_canvas = false;
                drag_ellp = false;
                drag_line = false;
                drag_triangle = false;

                dragging = false;
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                GC.Collect(0);

                Close();
            }

            e.Handled = true;
        }
        #endregion events

        private void WindowBorder_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                dragState = false;
            }

            e.Handled = true;
        }
    }
}
