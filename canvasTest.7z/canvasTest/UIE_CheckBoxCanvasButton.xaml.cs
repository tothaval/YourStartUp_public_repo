﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace canvasTest
{
    /// <summary>
    /// Interaktionslogik für UIE_CheckBoxCanvasButton.xaml
    /// </summary>
    public partial class UIE_CheckBoxCanvasButton : UserControl
    {
        public Color color { get; set; }

        private bool checkState = false;

        public UIE_CheckBoxCanvasButton()
        {
            InitializeComponent();
        }

        private void checkReaction()
        {
            if (checkState == false)
            {
                checkState = true;
                uie_chx_choice_confirmer.IsChecked = true;
            }
            else if (checkState == true)
            {
                checkState = false;
                uie_chx_choice_confirmer.IsChecked = false;
            }
        }

        public Color returnColor()
        {
            if (color == null)
            {
                return Color.FromArgb(0, 0, 0, 0);
            }

            return color;
        }

        public void uie_ckbcnvbtn_button_Click(object sender, RoutedEventArgs e)
        {
            checkReaction();
        }
    }
}
