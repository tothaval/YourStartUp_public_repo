﻿/* YourStartUp info page
 * 
 * Pur:         displays license information, version number and offers a manual
 * Toc:         2022 (may <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      taranis.sk@gmail.com
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für Info.xaml
    /// </summary>
    public partial class Info : Window
    {
        private List<Label> lblList = new List<Label>();
        private List<TextBlock> tbList = new List<TextBlock>();

        public Info()
        {
            InitializeComponent();
        }

        private void fillElementList()
        {      
            tbList.Add(tbYourStartUp);
            tbList.Add(tb_version);
            tbList.Add(tb_license);
            tbList.Add(tb_manual);
            tbList.Add(tb_manual_);
        }
        private void YourStartUp_Info_Loaded(object sender, RoutedEventArgs e)
        {
            fillElementList();

            ConfigData config = new ConfigData();
            InfoTexts info = new InfoTexts();
            
            YourStartUp_Info.FontFamily = config.font;
            YourStartUp_Info.FontSize = config.fontSize;

            Background = new SolidColorBrush(Colors.Transparent);
            Foreground = config.foreColor;
                        
            border.CornerRadius = new CornerRadius(config.borderRadius);
            border.BorderThickness = new Thickness(3);
            border.BorderBrush = config.foreColor;
            border.Background = config.backColor;
                        
            YourStartUp_Info.Height = 720;
            YourStartUp_Info.Width = 730;                      

            // textblocks
            tbYourStartUp.FontSize = 2 * config.fontSize;
            tbYourStartUp.Background = config.backColor;
            tbYourStartUp.Foreground = config.foreColor;
            tbYourStartUp.FontFamily = config.font;
            tbYourStartUp.Padding = new Thickness(5);
            
            tb_license.Background = config.backColor;
            tb_license.Foreground = config.foreColor;
            tb_license.Text = info.tbLicense().ToString();
            tb_license.FontFamily = config.font;
            tb_license.FontSize = config.fontSize;
            tb_license.Padding = new Thickness(5);            

            tb_manual.Background = config.btnBackColor;
            tb_manual.Foreground = config.btnForeColor;
            tb_manual.Text = info.tbManual().ToString();
            tb_manual.FontFamily = config.font;
            tb_manual.FontSize = config.fontSize;
            tb_manual.Padding = new Thickness(5);

            tb_manual_.Background = config.btnForeColor;
            tb_manual_.Foreground = config.btnBackColor;
            tb_manual_.Text = info.tbManual_().ToString();
            tb_manual_.FontFamily = config.font;
            tb_manual_.FontSize = config.fontSize;
            tb_manual_.Padding = new Thickness(5);

            tb_version.Background = config.backColor;
            tb_version.Foreground = config.foreColor;
            tb_version.Text = info.tbVersion().ToString();
            tb_version.FontFamily = config.font;
            tb_version.FontSize = config.fontSize;
            tb_version.Padding = new Thickness(5);
        }

        private void YourStartUp_Info_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            { 
                this.DragMove(); 
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                this.Close();
            }
        }

        private void YourStartUp_Info_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            GC.Collect(0);
        }
    }
}
/* info page
 * 
 * End of File
 */