﻿/* YourStartUp config class  
 * 
 * Pur:         this class handles gui design data, saving programm state and loading of last programm state
 * Toc:         2022 (may <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      taranis.sk@gmail.com
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace YourStartUp
{
    class ConfigData
    {
        // properties

        public DriveInfo[] allDrives { get; set; }

        #region properties
        // properties - boolians
        public bool chxCoordinates { get; set; }
        public bool chxHideDrives { get; set; }
        public bool chxHideNotes { get; set; }
        public bool chxHideScetchboard { get; set; }
        public bool chxHideTimer { get; set; }
        public bool chxMoreOptions { get; set; }        
        public bool deleteButtonState { get; set; }
        public bool hideButtonMapState { get; set; }
        public bool hidemenuButtonState { get; set; }
        public bool renameButtonState { get; set; }
        public bool resetButtonState { get; set; }


        public bool chxTimerTopmost { get; set; }
        public bool chxHideTitleBar { get; set; }
        public bool chxTransparency { get; set; }

        // properties - colors

        public SolidColorBrush backColor { get; set; }
        public SolidColorBrush btnBackColor { get; set; }
        public SolidColorBrush btnForeColor { get; set; }
        public SolidColorBrush btnHideMenuColor { get; set; }
        public SolidColorBrush btnHideMenuFont { get; set; }
        public SolidColorBrush canvasColor { get; set; }
        public SolidColorBrush canvasMenuColor { get; set; }        
        public SolidColorBrush deleteState { get; set; }
        public SolidColorBrush deleteStateFont { get; set; }        
        public SolidColorBrush foreColor { get; set; }
        public SolidColorBrush highlightColor { get; set; }
        public SolidColorBrush renameState { get; set; }
        public SolidColorBrush renameStateFont { get; set; }
        public SolidColorBrush resetState { get; set; }
        public SolidColorBrush resetStateFont { get; set; }
        public SolidColorBrush sliderBackground { get; set; }
        public SolidColorBrush textBox { get; set; }
        public SolidColorBrush textBoxFont { get; set; }

        // properties - fonts
        public FontFamily font { get; set; }

        // properties - integers
        public int borderRadius { get; set; }
        public int btnHeight { get; set; }
        public int btnWidth { get; set; }
        public int fontSize { get; set; }
        public int gigabyte { get; set; }
        public int mainWindowHeight { get; set; }
        public int mainWindowWidth { get; set; }
        public int readyDrives { get; set; }

        // properties - long
        public long totalFreeSpace { get; set; }

        // properties - strings 
        public string imageFilePath { get; set; }
        public string path { get; set; }
        public string path_config { get; set; }        
        public string path_notes { get; set; }
        public string path_notes_titles { get; set; }
        public string path_settings { get; set; }

        public string scetchboardFilePath { get; set; }
        #endregion properties

        // globals _private
        #region globals _private

        DateTime dt = new DateTime();

        #endregion globals _private

        // constructors
        public ConfigData()
        {
            config();
            createDefaults();            
            loadConfig();
            newDriveInfo();
        }

        // methods _private
        #region methods _private
        private void calculateTotalFreeSpace()
        {
            totalFreeSpace = 0;
            foreach (var drive in allDrives)
            {
                if (drive.IsReady)
                {
                    totalFreeSpace += drive.AvailableFreeSpace;
                }                
            }
        }
        private void calculateTotalReadyDrives()
        {
            readyDrives = 0;
            foreach (var drive in allDrives)
            {
                if (drive.IsReady)
                {
                    readyDrives++;
                }
            }
        }
        private void checkExistence(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }
        private SolidColorBrush colorConverter (string color)
        {
            SolidColorBrush convertedColor;
            byte a, r, g, b;
                                 
            color.Trim();            

            a = byte.Parse(color.Substring(1,2), System.Globalization.NumberStyles.HexNumber);
            r = byte.Parse(color.Substring(3,2), System.Globalization.NumberStyles.HexNumber);
            g = byte.Parse(color.Substring(5,2), System.Globalization.NumberStyles.HexNumber);
            b = byte.Parse(color.Substring(7,2), System.Globalization.NumberStyles.HexNumber);

            Color argb = Color.FromArgb(a, r, g, b);
            convertedColor = new SolidColorBrush(argb);

            return convertedColor;
        }
        private void config()
        {
            // boolians
            chxCoordinates = false;
            chxHideDrives = false;
            chxHideNotes = false;
            chxHideScetchboard = false;
            chxHideTimer = false;
            chxMoreOptions = false;
            deleteButtonState = false;
            hideButtonMapState = false;
            hidemenuButtonState = false;
            renameButtonState = false;
            resetButtonState = false;

            chxTimerTopmost = false;

            chxHideTitleBar = false;
            chxTransparency = false;

            // colors
            backColor = new SolidColorBrush(Color.FromArgb(146, 18, 58, 18));
            btnBackColor = new SolidColorBrush(Color.FromArgb(176, 23, 23, 23));
            btnForeColor = new SolidColorBrush(Color.FromArgb(255, 228, 222, 103));
            btnHideMenuColor = new SolidColorBrush(Color.FromArgb(176, 23, 23, 23));
            btnHideMenuFont = new SolidColorBrush(Color.FromArgb(255, 228, 222, 103));
            canvasColor = new SolidColorBrush(Color.FromArgb(255, 255, 255, 251));
            canvasMenuColor = new SolidColorBrush(Color.FromArgb(175, 228, 228, 30));
            deleteState = new SolidColorBrush(Color.FromArgb(255, 139, 0, 0));
            deleteStateFont = new SolidColorBrush(Color.FromArgb(255, 255, 165, 0));
            foreColor = new SolidColorBrush(Color.FromArgb(255, 255, 165, 0));
            highlightColor = new SolidColorBrush(Color.FromArgb(255, 122, 255, 123));
            renameState = new SolidColorBrush(Color.FromArgb(255, 255, 165, 0));
            renameStateFont = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
            resetState = new SolidColorBrush(Color.FromArgb(255, 0, 0, 139));
            resetStateFont = new SolidColorBrush(Color.FromArgb(255, 240, 248, 255));
            sliderBackground = new SolidColorBrush(Color.FromArgb(225, 255, 255, 255));
            textBox = new SolidColorBrush(Color.FromArgb(225, 255, 255, 255));
            textBoxFont = new SolidColorBrush(Color.FromArgb(225, 85, 85, 85));

            // fonts
            font = new FontFamily("Verdana");
                        
            // integers                        
            btnHeight = 50;
            btnWidth = 150;
            borderRadius = 0;
            fontSize = 11;
            mainWindowHeight = 590;
            mainWindowWidth = 590;

            gigabyte = 1024 * 1024 * 1024;

            readyDrives = 0;

            // strings
            imageFilePath = "";
            path = "";
            path_config = @"\files\save.config";            
            path_notes = @"\files\save.notes";
            path_notes_titles = @"\files\save.notes_titles";
            path_settings = @"\files\save.settings";

            scetchboardFilePath = @"\pictures";
        }
        private void createDefaults()
        {
            path = Directory.GetCurrentDirectory() + @"\files";
            path_config = Directory.GetCurrentDirectory() + @"\files\save.config";            
            path_notes = Directory.GetCurrentDirectory() + @"\files\save.notes";
            path_notes_titles = Directory.GetCurrentDirectory() + @"\files\save.notes_titles";
            path_settings = Directory.GetCurrentDirectory() + @"\files\save.settings";

            scetchboardFilePath = Directory.GetCurrentDirectory() + scetchboardFilePath;

            checkExistence(path);

            if (!File.Exists(path_config))
            {
                StreamWriter sw_config = new StreamWriter(path_config, false);
                sw_config.WriteLine("+; path");
                sw_config.Close();
            }
            if (!File.Exists(path_notes))
            {
                StreamWriter sw_notes = new StreamWriter(path_notes, false);
                // sw_folders.WriteLine(Directory.GetCurrentDirectory().ToString());
                sw_notes.Close();
            }
            if (!File.Exists(path_notes_titles))
            {
                StreamWriter sw_notes_titles = new StreamWriter(path_notes_titles, false);
                // sw_folders.WriteLine(Directory.GetCurrentDirectory().ToString());
                sw_notes_titles.Close();
            }
            if (!File.Exists(path_settings))
            {
                // resetDefaults();
                saveSettings();
            }

            if (!Directory.Exists(scetchboardFilePath))
            {
                Directory.CreateDirectory(scetchboardFilePath);                                
            }
        }
        #endregion methods _private

        // methods _public
        #region methods _public
        public string dateString()
        {
            string date;

            dt = DateTime.Now;

            date = $@"{dt.Year}-{dt.Month}-{dt.Day}";

            return date;
        }

        public string dateTimeString()
        {
            string date;

            dt = DateTime.Now;

            date = $@"{dt.Year}_{dt.Month}_{dt.Day}-{dt.Hour}-{dt.Minute}-{dt.Second}";

            return date;
        }
        public void loadConfig() // hier vllt irgendwann noch ne try catch exception handling sache einbauen
        {
            List<string> stringList = new List<string>();

            StreamReader sr = new StreamReader(path_settings);

            string line;
            // Read and display lines from the file until the end of
            // the file is reached.
            while ((line = sr.ReadLine()) != null)
            {
                stringList.Add(line);
            }
            sr.Close();

            // buttons: width, heigth, radius
            btnHeight = Int32.Parse(stringList[0]);
            btnWidth = Int32.Parse(stringList[1]);
            borderRadius = Int32.Parse(stringList[2]);

            // brush colors
            backColor = colorConverter(stringList[3]);
            btnBackColor = colorConverter(stringList[4]);
            btnForeColor = colorConverter(stringList[5]);
            btnHideMenuColor = colorConverter(stringList[6]);
            btnHideMenuFont = colorConverter(stringList[7]);
            deleteState = colorConverter(stringList[8]);
            deleteStateFont = colorConverter(stringList[9]);
            foreColor = colorConverter(stringList[10]);
            renameState = colorConverter(stringList[11]);
            renameStateFont = colorConverter(stringList[12]);
            resetState = colorConverter(stringList[13]);
            resetStateFont = colorConverter(stringList[14]);
            sliderBackground = colorConverter(stringList[15]);
            textBox = colorConverter(stringList[16]);
            textBoxFont = colorConverter(stringList[17]);

            // font
            font = new FontFamily(stringList[18]);
            fontSize = Int32.Parse(stringList[19]);

            // path
            imageFilePath = stringList[20];

            // main window: heigth, width
            mainWindowHeight = Int32.Parse(stringList[21]);
            mainWindowWidth = Int32.Parse(stringList[22]);

            // checkboxes
            chxCoordinates = bool.Parse(stringList[23]);
            chxHideDrives = bool.Parse(stringList[24]);            
            chxHideNotes = bool.Parse(stringList[25]);
            chxHideScetchboard = bool.Parse(stringList[26]);
            chxHideTimer = bool.Parse(stringList[27]);
            chxMoreOptions = bool.Parse(stringList[28]);

            // unused checkboxstates
            chxTimerTopmost = bool.Parse(stringList[29]);
            chxHideTitleBar = bool.Parse(stringList[30]);
            chxTransparency = bool.Parse(stringList[31]);            

            // boolians
            deleteButtonState = bool.Parse(stringList[32]);
            hideButtonMapState = bool.Parse(stringList[33]);
            hidemenuButtonState = bool.Parse(stringList[34]);
            renameButtonState = bool.Parse(stringList[35]);
            resetButtonState = bool.Parse(stringList[36]);

            canvasColor = colorConverter(stringList[37]);
            canvasMenuColor = colorConverter(stringList[38]);
            highlightColor = colorConverter(stringList[39]);
        }
        public void newDriveInfo()
        {
            allDrives = DriveInfo.GetDrives();            
            calculateTotalFreeSpace();
            calculateTotalReadyDrives();
        }
        public void resetDefaults()
        {
            config();
        }
        public void saveConfig(List<Button> btnSet, List<string> setList, List<string> configList)
        {
            StreamWriter sw_config = new StreamWriter(path_config, false);

            for (int i = 0; i < btnSet.Count; i++)
            {
                sw_config.WriteLine($"{configList[i]};{setList[i]}");
            }
            sw_config.Close();
        }


        public void saveScetchboardPictureToPNG(Canvas canvas_)
        {
            string date = dateTimeString();

            string filename = $@"{scetchboardFilePath}\picture{date}.png";

            Rect bounds = VisualTreeHelper.GetDescendantBounds(canvas_);
            double dpi = 96d;

            RenderTargetBitmap rtb = new RenderTargetBitmap((int)bounds.Width, (int)bounds.Height, dpi, dpi, System.Windows.Media.PixelFormats.Default);

            DrawingVisual dv = new DrawingVisual();
            using (DrawingContext dc = dv.RenderOpen())
            {
                VisualBrush vb = new VisualBrush(canvas_);
                dc.DrawRectangle(vb, null, new Rect(new Point(), bounds.Size));
            }

            rtb.Render(dv);

            BitmapEncoder pngEncoder = new PngBitmapEncoder();
            pngEncoder.Frames.Add(BitmapFrame.Create(rtb));

            try
            {
                System.IO.MemoryStream ms = new System.IO.MemoryStream();

                pngEncoder.Save(ms);
                ms.Close();

                System.IO.File.WriteAllBytes(filename, ms.ToArray());
            }
            catch (Exception err)
            {
                MessageBox.Show(err.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void saveSettings()
        {
            StreamWriter sw_settings = new StreamWriter(path_settings, false);
            // buttons: width, heigth, radius
            sw_settings.WriteLine(btnHeight);
            sw_settings.WriteLine(btnWidth);
            sw_settings.WriteLine(borderRadius);
            // brush colors
            sw_settings.WriteLine(backColor);
            sw_settings.WriteLine(btnBackColor);
            sw_settings.WriteLine(btnForeColor);
            sw_settings.WriteLine(btnHideMenuColor);
            sw_settings.WriteLine(btnHideMenuFont);
            sw_settings.WriteLine(deleteState);
            sw_settings.WriteLine(deleteStateFont);
            sw_settings.WriteLine(foreColor);
            sw_settings.WriteLine(renameState);
            sw_settings.WriteLine(renameStateFont);
            sw_settings.WriteLine(resetState);
            sw_settings.WriteLine(resetStateFont);
            sw_settings.WriteLine(sliderBackground);
            sw_settings.WriteLine(textBox);
            sw_settings.WriteLine(textBoxFont);
            // font
            sw_settings.WriteLine(font);
            sw_settings.WriteLine(fontSize);
            // path
            sw_settings.WriteLine(imageFilePath);
            //sw_settings.WriteLine(configPath);
            //sw_settings.WriteLine(settingsPath);
            // main window: heigth, width
            sw_settings.WriteLine(mainWindowHeight);
            sw_settings.WriteLine(mainWindowWidth);

            sw_settings.WriteLine(chxCoordinates);
            sw_settings.WriteLine(chxHideDrives);
            sw_settings.WriteLine(chxHideNotes);            
            sw_settings.WriteLine(chxHideScetchboard);            
            sw_settings.WriteLine(chxHideTimer);
            sw_settings.WriteLine(chxMoreOptions);

            sw_settings.WriteLine(chxTimerTopmost);
            sw_settings.WriteLine(chxHideTitleBar);
            sw_settings.WriteLine(chxTransparency);
            
            sw_settings.WriteLine(deleteButtonState);
            sw_settings.WriteLine(hideButtonMapState);
            sw_settings.WriteLine(hidemenuButtonState);
            sw_settings.WriteLine(renameButtonState);
            sw_settings.WriteLine(resetButtonState);

            sw_settings.WriteLine(canvasColor);
            sw_settings.WriteLine(canvasMenuColor);
            sw_settings.WriteLine(highlightColor);

            // all setting saved
            sw_settings.Close();
        }
        #endregion methods _public
    }
}
/* YourStartUp config class  
 * 
 * End of File
 */