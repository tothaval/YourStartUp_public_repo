﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für YRS_ColorFeature.xaml
    /// </summary>
    public partial class YRS_ColorFeature : UserControl
    {
        Canvas_ColorChoice ccc = new Canvas_ColorChoice();

        public Color getColor { get; set; }

        Color color;
        public bool buttonChecked { get; set; }


        public YRS_ColorFeature()
        {
            InitializeComponent();
        }


        // 
        public void colorChoice_loadColors()
        {
            List<UIE_CheckboxCanvasButton> ccbLST = new List<UIE_CheckboxCanvasButton>();

            foreach (UIE_CheckboxCanvasButton item in stkpnl_colorChoice.Children)
            {
                ccbLST.Add(item);
            }

            for (int i = 0; i < ccc.colorLST_load.Count; i++)
            {
                ccbLST[i].uie_ckbcnvbtn_button.Background = returnSolidColorBrush(ccc.colorLST_load[i]);
            }
        }

        public void colorChoice_saveColors()
        {
            foreach (UIE_CheckboxCanvasButton item in stkpnl_colorChoice.Children)
            {
                Color color = ((SolidColorBrush)item.uie_ckbcnvbtn_button.Background).Color;

                ccc.colorLST.Add(color);
            }

            ccc.saveColorsToFile(ccc.colorLST);
        }

        public SolidColorBrush returnSolidColorBrush(Color color)
        {
            return new SolidColorBrush(color);
        }


        private void setCanvasBackground(Color clr)
        {
            color = clr;

            cnv_color_picker.Background = returnSolidColorBrush(color);
        }


        private void red_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            setCanvasBackground(Color.FromArgb(color.A, (byte)e.OldValue, color.G, color.B));

            getColor = color;
        }

        private void blue_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            setCanvasBackground(Color.FromArgb(color.A, color.R, color.G, (byte)e.OldValue));

            getColor = color;
        }

        private void green_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            setCanvasBackground(Color.FromArgb(color.A, color.R, (byte)e.OldValue, color.B));

            getColor = color;
        }

        private void grey_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            setCanvasBackground(Color.FromArgb(color.A, (byte)e.OldValue, (byte)e.OldValue, (byte)e.OldValue));

            getColor = color;
        }

        private void alpha_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            setCanvasBackground(Color.FromArgb((byte)e.OldValue, color.R, color.G, color.B));

            getColor = color;
        }

        private void sld_red_MouseUp(object sender, MouseButtonEventArgs e)
        {
            //if (e.ChangedButton == MouseButton.Left)
            //{
            //    Color clr = Color.FromArgb(color.A, (byte) sld_red.Value, color.G, color.B);

            //    setCanvasBackground(clr);

            //    e.Handled = true;
            //}
        }


        private void ColorFeature_Loaded(object sender, RoutedEventArgs e)
        {
            color = Colors.White;

            color.A = 255;
            color.R = 255;
            color.G = 255;
            color.B = 255;

            cnv_color_picker.MinWidth = 510;
            cnv_color_picker.Width = 510;
            cnv_color_picker.MinHeight = 70;
            cnv_color_picker.Height = 70;
            cnv_color_picker.Visibility = Visibility.Visible;

            buttonChecked = true;

            if (ccc.loadColorsFromFile() == true)
            {
                for (int i = 0; i < 28; i++)
                {
                    UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton();

                    ccb.Name = $"ccb{i}";

                    ccb.uie_ckbcnvbtn_button.Click += Uie_ckbcnvbtn_button_Click;

                    ccb.uie_ckbcnvbtn_button.Background = returnSolidColorBrush(ccc.colorLST_load[i]);

                    if (i == 0)
                    {
                        color = ccc.colorLST_load[i];

                        getColor = color;

                        cnv_color_picker.Background = returnSolidColorBrush(color);
                    }


                    ccb.MouseDown += Ccb_MouseDown;
                    ccb.MouseUp += Ccb_MouseUp;

                    stkpnl_colorChoice.Children.Add(ccb);
                }

                stkpnl_colorChoice.Margin = new Thickness(0, 0, 10, 0);
            }
        }

        private void Ccb_MouseUp(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
        }

        private void Ccb_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                UIE_CheckboxCanvasButton button = (UIE_CheckboxCanvasButton)sender;

                button.uie_ckbcnvbtn_button_border.Background = new SolidColorBrush(getColor); // returnSolidColorBrush(getColor);

                button.Background = returnSolidColorBrush(getColor);

                //MessageBox.Show("tada du lusche");
            }
        }

        private void Uie_ckbcnvbtn_button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;

            UIE_CheckboxCanvasButton ccb = new UIE_CheckboxCanvasButton();

            ccb.uie_ckbcnvbtn_button = btn;

            if (buttonChecked == false)
            {
                btn.Background = returnSolidColorBrush(getColor);
            }
            else if (buttonChecked == true)
            {
                SolidColorBrush brush = (SolidColorBrush)btn.Background;

                cnv_color_picker.Background = brush;

                getColor = brush.Color;
            }
        }

        private void sld_blue_MouseUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void sld_green_MouseUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void sld_grey_MouseUp(object sender, MouseButtonEventArgs e)
        {
            //38;
        }

        private void sld_alpha_MouseUp(object sender, MouseButtonEventArgs e)
        {

        }
    }
}
