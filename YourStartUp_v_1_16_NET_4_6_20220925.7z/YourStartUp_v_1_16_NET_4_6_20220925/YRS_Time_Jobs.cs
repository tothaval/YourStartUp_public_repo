﻿/*  purpose: managing time based logic and funtionalities
 * 
 * written: september 2022
 * by: stephan kammel
 */

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YourStartUp
{
    class YRS_Time_Jobs
    {
        private readonly System.Windows.Threading.DispatcherTimer _pulse = 
            new System.Windows.Threading.DispatcherTimer();

        private bool time = false;

        private Stopwatch breakDuration = new Stopwatch();
        private Stopwatch stopWatch = new Stopwatch();
        private Stopwatch sinceStart = new Stopwatch();

        private string hours, minutes, seconds;

        public YRS_Time_Jobs()
        {
            _pulse.Interval = TimeSpan.FromSeconds(1);
            _pulse.Tick += _pulse_Tick;
            sinceStart.Start();
        }

        private void _pulse_Tick(object sender, EventArgs e)
        {
            get_pulse();

            GC.Collect(0);
        }

        public StringBuilder get_active_time()
        {
            StringBuilder sb = new StringBuilder();

            hours = sinceStart.Elapsed.Hours.ToString("##00");
            minutes = sinceStart.Elapsed.Minutes.ToString("##00");
            seconds = sinceStart.Elapsed.Seconds.ToString("##00");

            return sb.Append($"{hours}:{minutes}:{seconds}");
        }

        public StringBuilder get_break_time()
        {
            StringBuilder sb = new StringBuilder();

            hours = breakDuration.Elapsed.Hours.ToString("##00");
            minutes = breakDuration.Elapsed.Minutes.ToString("##00");
            seconds = breakDuration.Elapsed.Seconds.ToString("##00");

            return sb.Append($"{hours}:{minutes}:{seconds}");
        }

        public StringBuilder get_stopwatch_time()
        {
            StringBuilder sb = new StringBuilder();

            hours = stopWatch.Elapsed.Hours.ToString("##00");
            minutes = stopWatch.Elapsed.Minutes.ToString("##00");
            seconds = stopWatch.Elapsed.Seconds.ToString("##00");

            return sb.Append($"{hours}:{minutes}:{seconds}");
        }


        public bool get_pulse()
        {

            if (time == false)
            {
                time = true;
            }
            else if (time == true)
            {
                time = false;
            }

            return time;            
        }
        public StringBuilder get_time_string()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append(DateTime.Now.ToLongTimeString());

            return sb;
        }


        public void reset_break_stopwatch()
        {
            breakDuration.Reset();
        }

        public void restart_stopwatch()
        {
            stopWatch.Restart();
        }


        public void start_break_stopwatch()
        {
            breakDuration.Start();
        }

        public void stop_active_time()
        {
            sinceStart.Stop();
        }

        public void stop_break_stopwatch()
        {
            breakDuration.Stop();
        }


        public void start_stopwatch()
        {
            stopWatch.Start();
        }
        public void stop_stopwatch()
        {
            stopWatch.Stop();
        }
    }
}
