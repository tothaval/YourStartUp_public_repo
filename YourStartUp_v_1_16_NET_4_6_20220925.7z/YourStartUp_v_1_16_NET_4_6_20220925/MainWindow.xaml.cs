﻿/* YourStartUp buttonmap tool  
 * 
 * Pur:         main window, collapsable main menu, collapsable button area, user can bind files and urls to buttons
 * Toc:         2022 (may <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      kammel@posteo.de
 */
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Point = System.Windows.Point;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // classes
        #region classes

        public int checkCount = 0;

        // colors
        private SolidColorBrush color1;
        private SolidColorBrush color2;

        Canvas_BasicGeometry geom = new Canvas_BasicGeometry();
        Canvas_ColorChoice ccc = new Canvas_ColorChoice();
        Canvas_UIConfig uic = new Canvas_UIConfig();

        ScetchboardTexts scetchboard = new ScetchboardTexts();

        // invoked classes
        private ConfigData config = new ConfigData();

        // geometry
        private Ellipse dragEllipse;
        private System.Windows.Shapes.Rectangle dragRectangle;
        private Shape selectedShape;


        private Canvas_BasicGeometry cnv_geo;
        private Canvas_ColorChoice cnv_clr;
        private Canvas_GoldPaletteModule gold;
        private Canvas_PicturePaletteModule pic;
        private Canvas_PlacementAndDesignElement ppe;

        private MainWindowTexts texts = new MainWindowTexts();

        private ScetchboardTexts scetchboardTexts = new ScetchboardTexts();

        private UIE_AlphabetElement abc;
        private UIE_CalculatorElement cal;
        private UIE_CoordinatesElement cor;
        private UIE_DiceElement dic;
        private UIE_DrivesElement dri;
        private UIE_GroupingElement gro;
        private UIE_HealthTool_BMI_Element hea;

        private UIE_ImageElement UIE_image_element;

        private UIE_InfoElement inf;
        private UIE_LicenseElement lic;

        private UIE_MainWindowMenuElement UIE_menu_element;

        private UIE_MathElement mat;
        private UIE_MeasureElement mea;
        private UIE_NameElement nam;
        private UIE_NotesElement not;
        private UIE_OptionsElement opt;
        private UIE_PCHandlingTrainerElement pch;

        private UIE_ScetchboardElement UIE_scetchboard_element;
        private UIE_SelectionBindingElement UIE_selection_binding_element;

        private UIE_TextEditorElement tee;
        private UIE_TextElement txe;

        private UIE_TimerElement UIE_timer_element;

        private YRS_ColorFeature yrs_color_feature = new YRS_ColorFeature();
        private YRS_GeometryElement geo;
        private YRS_Time_Jobs tim;
        //private YRS_ColorFeature -> wurde zu Cancas_ColorChoice
        // ich wollte irgendwas auf F3 packen.
        #endregion classes

        #region  private globals
        private bool loaded = false;

        // success of textbox parsing
        private bool parseFail = false;

        // drawn objects dimensions, angle, z-index, cascade count and psbly text
        int cascadeAmount = 3;
        int elementHeight = 250;
        int elementWidth = 400;
        int elementZindex = 12;

        double elementAngle = 0;

        private double x = 370;
        private double y = 380;

        // drawn object amounts
        private long drawMainWindowMenuElement = 0;
        private long drawImageElement = 0;
        private long drawScetchboardElement = 0;
        private long drawSelectionBindingElement = 0;
        private long drawTimerElement = 0;
        private long drawYRSColorFeature = 0;

        private long drawEllipseID = 0;
        //private long drawImageElement = 0;
        private long drawLineID = 0;
        private long drawRectangleID = 0;
        private long drawTriangleID = 0;
        private long drawTextElement = 0;

        // key states for drawing (s free hand, x rectangles, y ellipses)
        private bool d_pressed = false;
        private bool h_pressed = false;

        private bool s_pressed = false;
        private bool x_pressed = false;
        private bool y_pressed = false;

        // drawn objects moving positions
        private Point scetchPoint = new Point();

        private Point clickV;

        private Point startPoint;
        private Point startPoint_menuElements;
        private Point startPoint_mycanvas;

        private Point startPoint_dragEllipse;
        private Point startPoint_dragRectangle;

        private Point startPoint_ellp;

        // boolian drag states
        private bool drag_image_element;
        private bool drag_menu_element;
        private bool drag_scetchboard_element;
        private bool drag_selection_binding_element;
        private bool drag_timer_element;

        // drawn objects drag state
        private bool drag = false;
        private bool drag_canvas = false;
        private bool drag_menuElements = false;
        private bool drag_ellp = false;
        private bool drag_line = false;
        private bool drag_triangle = false;

        private bool dragging;
        private bool dragState = false;

        // visual object lists
        private List<UIE_ImageElement> listOfImageElements =
            new List<UIE_ImageElement>();

        private List<UIE_MainWindowMenuElement> listOfMenuElements =
            new List<UIE_MainWindowMenuElement>();

        private List<UIE_ScetchboardElement> listOfScetchboardElements =
            new List<UIE_ScetchboardElement>();

        private List<UIE_SelectionBindingElement> listOfSelectionBindingElements =
            new List<UIE_SelectionBindingElement>();

        private List<UIE_TimerElement> listOfTimerElements =
            new List<UIE_TimerElement>();

        // naming counters for drag drawing 
        private long dragEllipseID = 0;
        private long dragRectangleID = 0;
        // private long dragTriangleID = 0;

        // coordinate points
        private Point drag_point_image_element = new Point();
        private Point drag_point_menu_element = new Point();
        private Point drag_point_scetchboard_element = new Point();
        private Point drag_point_selection_binding_element = new Point();
        private Point drag_point_timer_element = new Point();

        #endregion private globals

        //Drop="grdMainWindow_Drop" XAML kram
        //  PreviewDragOver="grdMainWindow_PreviewDragOver"

        // globals _public
        #region globals _public
        public int showCount = 0;

        // globals _public        
        public List<Button> btnSetList = new List<Button>();
        public List<Button> btnMenuList = new List<Button>();

        public List<Border> brdSetList = new List<Border>();
        public List<Border> brdMenuList = new List<Border>();
        #endregion globals _public


        // globals _private
        #region globals _private

        private ImageBrush image = new ImageBrush();

        private int refresh = 0; // counter (_pulse)

        private List<TextBox> txtBoxList = new List<TextBox>();
        private List<string> setList = new List<string>();
        private List<string> configList = new List<string>();
        private List<Button> btnDrvs = new List<Button>();

        private readonly System.Windows.Threading.DispatcherTimer _pulse = new System.Windows.Threading.DispatcherTimer();

        private string configuration = "+;path";

        private int _height = 0;
        private int _width = 0;
        #endregion globals _private


        // constructors
        #region constructors
        public MainWindow()
        {
            InitializeComponent();

            _pulse.Interval = TimeSpan.FromSeconds(1);
            _pulse.Tick += _pulse_Tick;
        }
        #endregion constructors


        // time methods
        #region time methods
        private void _pulse_Tick(object sender, EventArgs e)
        {
            refresh++;
            if (refresh == 2)
            {
                //    for (int i = 0; i < btnDrvs.Count; i++)
                //    {
                //        wrpDrives.Children.Clear();
                //        btnDrvs.Clear();
                //    }

                //    setupDrives();

                //    refresh = 0;

                //    config.newDriveInfo();
            }

            GC.Collect(0);
        }
        #endregion time methods

        // drag drawing logic
        #region drag drawing logic

        // on mouse down
        private void s_pressed_MouseDown(MouseEventArgs _e)
        {
            if (s_pressed == false)
            {

            }
            else if (s_pressed == true)
            {
                if (_e.LeftButton == MouseButtonState.Pressed)
                    scetchPoint = _e.GetPosition(MainWindowCanvas);
            }
        }

        private void x_pressed_MouseDown(MouseEventArgs _e)
        {
            if (x_pressed == false)
            {

            }
            else if (x_pressed == true)
            {
                dragState = true;

                startPoint_dragRectangle = _e.GetPosition(MainWindowCanvas);

                dragRectangle = new System.Windows.Shapes.Rectangle
                {
                    Fill = yrs_color_feature.returnSolidColorBrush(color1.Color),
                    Stroke = yrs_color_feature.returnSolidColorBrush(color2.Color),
                    StrokeThickness = uic.borderThickness
                };

                Canvas.SetLeft(dragRectangle, startPoint_dragRectangle.X);
                Canvas.SetTop(dragRectangle, startPoint_dragRectangle.Y);

                MainWindowCanvas.Children.Add(dragRectangle);
            }
        }

        private void y_pressed_MouseDown(MouseEventArgs _e)
        {
            if (y_pressed == false)
            {

            }
            else if (y_pressed == true)
            {
                dragState = true;

                startPoint_dragEllipse = _e.GetPosition(MainWindowCanvas);

                dragEllipse = new Ellipse
                {
                    Fill = yrs_color_feature.returnSolidColorBrush(color1.Color),
                    Stroke = yrs_color_feature.returnSolidColorBrush(color2.Color),
                    StrokeThickness = uic.borderThickness
                };
                Canvas.SetLeft(dragEllipse, startPoint_dragEllipse.X);
                Canvas.SetTop(dragEllipse, startPoint_dragEllipse.Y);
                MainWindowCanvas.Children.Add(dragEllipse);
            }
        }

        // on mouse move
        private void s_pressed_MouseMove(MouseEventArgs _e)
        {
            if (_e.LeftButton == MouseButtonState.Pressed)
            {
                if (s_pressed == true)
                {
                    Line line = new Line();

                    //line.StrokeThickness = 50;
                    //line.StrokeThickness = 20;
                    line.StrokeThickness = 11;

                    if (rb_linearBrush.IsChecked == true)
                    {
                        line.Stroke = linearGradientOrientation_processing();
                    }
                    else if (rb_solidBrush.IsChecked == true)
                    {
                        line.Stroke = yrs_color_feature.returnSolidColorBrush(yrs_color_feature.getColor);
                    }

                    //line.Stroke = new RadialGradientBrush(color_1, color_2);
                    //line.Stroke = new LinearGradientBrush(color_1, color_2, 0);

                    //line.StrokeDashArray = new DoubleCollection() { 1, 2, 4 };

                    //line.StrokeEndLineCap = PenLineCap.Triangle;
                    line.StrokeEndLineCap = PenLineCap.Round;
                    //line.StrokeEndLineCap = PenLineCap.Square;
                    //line.StrokeEndLineCap = PenLineCap.Round;

                    line.X1 = scetchPoint.X;
                    line.Y1 = scetchPoint.Y;
                    line.X2 = _e.GetPosition(MainWindowCanvas).X;
                    line.Y2 = _e.GetPosition(MainWindowCanvas).Y;

                    scetchPoint = _e.GetPosition(MainWindowCanvas);

                    setZindexOnShape(line);

                    MainWindowCanvas.Children.Add(line);
                }
            }
        }

        private void x_pressed_MouseMove(MouseEventArgs _e)
        {
            if (x_pressed == false)
            {

            }
            else if (x_pressed == true)
            {
                if (_e.LeftButton == MouseButtonState.Released || dragState == false)
                {
                    if (dragRectangle != null)
                    {
                        dragRectangleID++;

                        dragRectangle.Fill = yrs_color_feature.returnSolidColorBrush(color1.Color);
                        dragRectangle.Stroke = yrs_color_feature.returnSolidColorBrush(color2.Color);
                        dragRectangle.StrokeThickness = 3;

                        dragRectangle.Name = $"dragRectangle_{dragRectangleID.ToString()}";

                        dragRectangle.MouseDown += Rectangle_MouseDown;
                        dragRectangle.MouseMove += Rectangle_MouseMove;
                        dragRectangle.MouseUp += Rectangle_MouseUp;
                    }

                    dragState = false;

                    return;
                }

                Point pos = _e.GetPosition(MainWindowCanvas);

                pos = simulatePadding(pos);

                double x = Math.Min(pos.X, startPoint_dragRectangle.X);
                double y = Math.Min(pos.Y, startPoint_dragRectangle.Y);

                double w = Math.Max(pos.X, startPoint_dragRectangle.X) - x;
                double h = Math.Max(pos.Y, startPoint_dragRectangle.Y) - y;

                dragRectangle.Width = w;
                dragRectangle.Height = h;

                Canvas.SetLeft(dragRectangle, x);
                Canvas.SetTop(dragRectangle, y);
            }
        }

        private void y_pressed_MouseMove(MouseEventArgs _e)
        {
            if (y_pressed == false)
            {

            }
            else if (y_pressed == true)
            {
                if (_e.LeftButton == MouseButtonState.Released || dragState == false)
                {

                    if (dragEllipse != null)
                    {
                        dragEllipseID++;

                        dragEllipse.Fill = yrs_color_feature.returnSolidColorBrush(color1.Color);
                        dragEllipse.Stroke = yrs_color_feature.returnSolidColorBrush(color2.Color);
                        dragEllipse.StrokeThickness = 3;

                        dragEllipse.Name = $"dragEllipse{dragEllipseID.ToString()}";

                        dragEllipse.MouseDown += Ell_MouseDown;
                        dragEllipse.MouseMove += Ell_MouseMove;
                        dragEllipse.MouseUp += Ell_MouseUp;
                    }

                    dragState = false;

                    //x_pressed = false;
                    return;
                }

                Point pos = _e.GetPosition(MainWindowCanvas);

                pos = simulatePadding(pos);

                double x = Math.Min(pos.X, startPoint_dragEllipse.X);
                double y = Math.Min(pos.Y, startPoint_dragEllipse.Y);

                double w = Math.Max(pos.X, startPoint_dragEllipse.X) - x;
                double h = Math.Max(pos.Y, startPoint_dragEllipse.Y) - y;

                dragEllipse.Width = w;
                dragEllipse.Height = h;

                Canvas.SetLeft(dragEllipse, x);
                Canvas.SetTop(dragEllipse, y);
            }
        }

        // on mouse up
        private void x_pressed_MouseUp()
        {
            drag = false;
            drag_canvas = false;
            drag_ellp = false;

            drag_line = false;
            drag_triangle = false;

            dragging = false;

            if (x_pressed == false)
            {

            }
            else if (x_pressed == true)
            {
                dragRectangleID++;

                dragRectangle.Fill = yrs_color_feature.returnSolidColorBrush(color1.Color);
                dragRectangle.Stroke = yrs_color_feature.returnSolidColorBrush(color2.Color);
                dragRectangle.StrokeThickness = 3;

                dragRectangle.Name = $"dragRectangle_{dragRectangleID.ToString()}";

                dragRectangle.MouseDown += Rectangle_MouseDown;
                dragRectangle.MouseMove += Rectangle_MouseMove;
                dragRectangle.MouseUp += Rectangle_MouseUp;

                dragState = false;
            }
        }

        private void y_pressed_MouseUp()
        {

            drag = false;
            drag_canvas = false;
            drag_ellp = false;

            drag_line = false;
            drag_triangle = false;

            dragging = false;

            if (y_pressed == false)
            {

            }
            else if (y_pressed == true)
            {
                dragEllipseID++;

                if (dragEllipse != null)
                {
                    dragEllipse.Fill = yrs_color_feature.returnSolidColorBrush(color1.Color);
                    dragEllipse.Stroke = yrs_color_feature.returnSolidColorBrush(color2.Color);
                    dragEllipse.StrokeThickness = 3;
                }

                dragEllipse.Name = $"dragEllipse{dragEllipseID.ToString()}";

                dragEllipse.MouseDown += Ell_MouseDown;
                dragEllipse.MouseMove += Ell_MouseMove;
                dragEllipse.MouseUp += Ell_MouseUp;

                dragState = false;
            }
        }
        #endregion drag drawing logic

        // design
        #region design
        private void canvasDesign()
        {
            Height = config.mainWindowHeight;
            Width = config.mainWindowWidth;

            color1 = config.btnBackColor;
            color2 = config.btnForeColor;

            ButtonMap.Background = new SolidColorBrush(Colors.Transparent);

            border.Background = config.backColor;
            border.BorderBrush = config.foreColor;
            border.BorderThickness = new Thickness(3);
            border.CornerRadius = new CornerRadius(config.borderRadius);

            MainWindowCanvas.Background = config.canvasColor;
            wrpMenu.Background = config.backColor;
            wrpRadioButtons.Background = config.canvasMenuColor;
            wrpTextBoxes.Background = config.btnBackColor;

            yrs_color_feature.border.Background = config.canvasMenuColor;
            yrs_color_feature.Foreground = config.canvasColor;

            foreach (TextBox tb in wrpTextBoxes.Children)
            {
                tb.Background = config.textBox;
                tb.Foreground = config.textBoxFont;
            }

            rb_solidBrush.IsChecked = true;
        }

        private void canvasRessources()
        {
            config.loadConfig();

            ButtonMap.Resources.Remove("buttonColor");
            ButtonMap.Resources.Remove("buttonFont");
            ButtonMap.Resources.Remove("highlight");
            ButtonMap.Resources.Remove("radius");

            ButtonMap.Resources.Add("buttonColor", config.btnBackColor);
            ButtonMap.Resources.Add("buttonFont", config.btnForeColor);
            ButtonMap.Resources.Add("highlight", config.highlightColor);
            ButtonMap.Resources.Add("radius", new CornerRadius(config.borderRadius));
        }
        #endregion design


        private void check_rbGroup_LinearGradientOrientation(Shape _shape)
        {
            colorChoiceFunction();

            if (rb_orientationBottom.IsChecked == true)
            {
                _shape.Fill = new LinearGradientBrush(
                    color1.Color,
                    color2.Color,
                    90);
            }
            else if (rb_orientationTop.IsChecked == true)
            {
                _shape.Fill = new LinearGradientBrush(
                    color2.Color,
                    color1.Color,
                    90);
            }
            else if (rb_orientationLeft.IsChecked == true)
            {
                _shape.Fill = new LinearGradientBrush(
                    color1.Color,
                    color2.Color,
                    0
                    );
            }
            else if (rb_orientationRight.IsChecked == true)
            {
                _shape.Fill = new LinearGradientBrush(
                    color2.Color,
                    color1.Color,
                    0
                    );
            }
        }

        private void check_rbGroup_LinearGradientOrientation_UIE_TextElement(UIE_TextElement uiet)
        {
            colorChoiceFunction();

            if (rb_orientationBottom.IsChecked == true)
            {
                uiet.border.Background = new LinearGradientBrush(
                    color1.Color,
                    color2.Color,
                    90);
                uiet.textbox.Foreground = new LinearGradientBrush(
                    color2.Color,
                    color1.Color,
                    90);
            }
            else if (rb_orientationTop.IsChecked == true)
            {
                uiet.border.Background = new LinearGradientBrush(
                    color2.Color,
                    color1.Color,
                    90);
                uiet.textbox.Foreground = new LinearGradientBrush(
                    color1.Color,
                    color2.Color,
                    90);
            }
            else if (rb_orientationLeft.IsChecked == true)
            {
                uiet.border.Background = new LinearGradientBrush(
                    color1.Color,
                    color2.Color,
                    0
                    );
                uiet.textbox.Foreground = new LinearGradientBrush(
                    color2.Color,
                    color1.Color,
                    90);
            }
            else if (rb_orientationRight.IsChecked == true)
            {
                uiet.border.Background = new LinearGradientBrush(
                    color2.Color,
                    color1.Color,
                    0
                    );
                uiet.textbox.Foreground = new LinearGradientBrush(
                    color1.Color,
                    color2.Color,
                    90);
            }
        }

        public void colorChoiceFunction()
        {
            checkCount = 0;

            List<UIE_CheckboxCanvasButton> ccbLST = new List<UIE_CheckboxCanvasButton>();

            foreach (UIE_CheckboxCanvasButton item in yrs_color_feature.stkpnl_colorChoice.Children)
            {
                ccbLST.Add(item);
            }

            foreach (UIE_CheckboxCanvasButton ccb in ccbLST)
            {
                if (ccb.uie_chx_choice_confirmer.IsChecked == true)
                {
                    //MessageBox.Show($"{plemplem.Name}\n{plemplem.uie_chx_choice_confirmer.Name}");

                    SolidColorBrush brush = (SolidColorBrush)ccb.uie_ckbcnvbtn_button.Background;

                    if (checkCount == 0)
                    {
                        color1 = brush;
                    }
                    else if (checkCount == 1)
                    {
                        color2 = brush;
                    }

                    checkCount++;
                }
            }

            if (checkCount > 2)
            {
                MessageBox.Show("only two colors can be processed.");
            }
        }


        #region d
        private void determineColorScheme(Shape _shape)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                check_rbGroup_LinearGradientOrientation(_shape);
            }
            else if (rb_solidBrush.IsChecked == true)
            {
                solidColorFill(_shape);
            }

            _shape.StrokeThickness = uic.borderThickness;
        }

        private void determineColorScheme_UIE_TextElement(UIE_TextElement uiet)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                check_rbGroup_LinearGradientOrientation_UIE_TextElement(uiet);
            }
            else if (rb_solidBrush.IsChecked == true)
            {
                solidColorFill_UIE_Textelement(uiet);
            }
        }

        private void disableDragState()
        {
            // boolian drag states
            drag_image_element = false;
            drag_menu_element = false;
            drag_scetchboard_element = false;
            drag_selection_binding_element = false;
            drag_timer_element = false;

            // drawn objects drag state
            drag = false;
        drag_canvas = false;
        drag_menuElements = false;
        drag_ellp = false;
        drag_line = false;
        drag_triangle = false;

            dragging = false;
            dragState = false;

    }
    #endregion d


    // draw stuff
    #region drawing
    #region cascades
    private void drawCascade_Ellipses()
        {
            parseTextboxes();

            for (int i = 0; i < cascadeAmount; i++)
            {
                Ellipse cell = drawSimpleEllipse();

                drawShape(cell, i);
            }
        }

        private void drawCascade_Rectangles()
        {
            parseTextboxes();

            for (int i = 0; i < cascadeAmount; i++)
            {
                System.Windows.Shapes.Rectangle crec = drawSimpleRectangle();

                drawShape(crec, i);
            }
        }

        private void drawCascade_Triangles()
        {
            parseTextboxes();

            for (int i = 0; i < cascadeAmount; i++)
            {
                // Polygon tria = drawSimpleTriangle();

                Polygon tria = drawSimpleTriangle_rectangular();

                drawShape(tria, i);
            }
        }
        #endregion cascades



        private void drawShape(Shape shape, int counter = 1)
        {
            parseTextboxes();
            determineColorScheme(shape);

            Canvas.SetLeft(shape, 50 * counter);
            Canvas.SetTop(shape, 25 * counter);

            Panel.SetZIndex(shape, elementZindex);
        }


        #region simple geometry
        private Ellipse drawSimpleEllipse()
        {
            // ccb button mit text border/oder symbol zum speichern der farbe für den rand,)

            parseTextboxes();

            Ellipse ell = geom.drawSimpleEllipse(elementWidth, elementHeight);

            ell.Name = $"ellipse{drawEllipseID}";

            //ell.StrokeDashArray = new DoubleCollection() { 2 };

            drawEllipseID++;

            drawShape(ell);

            rotateShape(ell);

            ell.MouseDown += Ell_MouseDown;
            ell.MouseMove += Ell_MouseMove;
            ell.MouseUp += Ell_MouseUp;

            MainWindowCanvas.Children.Add(ell);

            return ell;
        }

        private Polygon drawSimpleLine()
        {
            parseTextboxes();

            Polygon lin = geom.drawSimpleLine(elementWidth, elementHeight);

            lin.Name = $"ellipse{drawLineID}";

            drawLineID++;

            drawShape(lin);

            rotateShape(lin);

            lin.MouseDown += pygon_MouseDown;
            lin.MouseMove += pygon_MouseMove;
            lin.MouseUp += pygon_MouseUp;

            MainWindowCanvas.Children.Add(lin);

            return lin;
        }

        private System.Windows.Shapes.Rectangle drawSimpleRectangle()
        {
            parseTextboxes();

            System.Windows.Shapes.Rectangle rec = geom.drawSimpleRectangle(elementWidth, elementHeight);

            rec.Name = $"ellipse{drawRectangleID}";

            //rec.StrokeDashArray = new DoubleCollection() { 2 };

            drawRectangleID++;

            drawShape(rec);

            rotateShape(rec);

            rec.MouseDown += Rectangle_MouseDown;
            rec.MouseMove += Rectangle_MouseMove;
            rec.MouseUp += Rectangle_MouseUp;

            MainWindowCanvas.Children.Add(rec);

            return rec;
        }

        private Polygon drawSimpleTriangle_equilateral()
        {
            parseTextboxes();

            Polygon tri_equ;

            if (elementAngle == 0 && (elementHeight < 0 || elementWidth < 0))
            {
                tri_equ = geom.drawSimpleTriangle_equilateral(elementWidth, elementHeight);

                tri_equ.Name = $"ellipse{drawTriangleID}";

                drawShape(tri_equ);
            }
            else if (elementAngle != 0 && (elementHeight < 0 || elementWidth < 0))
            {
                tri_equ = geom.drawSimpleTriangle_equilateral(
                    geom.avoidNegativity(elementWidth), geom.avoidNegativity(elementHeight)
                    );

                tri_equ.Name = $"ellipse{drawTriangleID}";

                drawShape(tri_equ);
                rotateShape(tri_equ);
            }
            else
            {
                tri_equ = geom.drawSimpleTriangle_equilateral(elementWidth, elementHeight);

                tri_equ.Name = $"ellipse{drawTriangleID}";

                drawShape(tri_equ);
                rotateShape(tri_equ);
            }

            drawTriangleID++;

            tri_equ.MouseDown += pygon_MouseDown;
            tri_equ.MouseMove += pygon_MouseMove;
            tri_equ.MouseUp += pygon_MouseUp;

            MainWindowCanvas.Children.Add(tri_equ);

            return tri_equ;
        }

        private Polygon drawSimpleTriangle_isosceles()
        {
            parseTextboxes();

            Polygon tri_iso;

            if (elementAngle == 0 && (elementHeight < 0 || elementWidth < 0))
            {
                tri_iso = geom.drawSimpleTriangle_isosceles(elementWidth, elementHeight);

                tri_iso.Name = $"ellipse{drawTriangleID}";

                drawShape(tri_iso);
            }
            else if (elementAngle != 0 && (elementHeight < 0 || elementWidth < 0))
            {
                tri_iso = geom.drawSimpleTriangle_isosceles(
                    geom.avoidNegativity(elementWidth), geom.avoidNegativity(elementHeight)
                    );

                tri_iso.Name = $"ellipse{drawTriangleID}";

                drawShape(tri_iso);
                rotateShape(tri_iso);
            }
            else
            {
                tri_iso = geom.drawSimpleTriangle_isosceles(elementWidth, elementHeight);

                tri_iso.Name = $"ellipse{drawTriangleID}";

                drawShape(tri_iso);
                rotateShape(tri_iso);
            }

            drawTriangleID++;

            tri_iso.MouseDown += pygon_MouseDown;
            tri_iso.MouseMove += pygon_MouseMove;
            tri_iso.MouseUp += pygon_MouseUp;

            MainWindowCanvas.Children.Add(tri_iso);

            return tri_iso;
        }

        private Polygon drawSimpleTriangle_rectangular()
        {
            parseTextboxes();

            Polygon tri;

            if (elementAngle == 0 && (elementHeight < 0 || elementWidth < 0))
            {
                tri = geom.drawSimpleTriangle_rectangular(elementWidth, elementHeight);

                tri.Name = $"ellipse{drawTriangleID}";

                drawShape(tri);
            }
            else if (elementAngle != 0 && (elementHeight < 0 || elementWidth < 0))
            {
                tri = geom.drawSimpleTriangle_rectangular(geom.avoidNegativity(elementWidth), geom.avoidNegativity(elementHeight));

                tri.Name = $"ellipse{drawTriangleID}";

                drawShape(tri);
                rotateShape(tri);
            }
            else
            {
                tri = geom.drawSimpleTriangle_rectangular(elementWidth, elementHeight);

                tri.Name = $"ellipse{drawTriangleID}";

                drawShape(tri);
                rotateShape(tri);
            }

            drawTriangleID++;

            tri.MouseDown += pygon_MouseDown;
            tri.MouseMove += pygon_MouseMove;
            tri.MouseUp += pygon_MouseUp;

            MainWindowCanvas.Children.Add(tri);

            return tri;
        }
        #endregion simple geometry

        public UIE_ImageElement drawUIE_ImageElement(ImageBrush ib_)
        {
            parseTextboxes();

            UIE_ImageElement uimg = new UIE_ImageElement(elementWidth, elementHeight);

            uimg.Name = $"uimg{drawImageElement}";
            drawImageElement++;

            uimg.border.BorderBrush = new SolidColorBrush(yrs_color_feature.getColor);
            uimg.border.BorderThickness = new Thickness(2);
            uimg.border.CornerRadius = new CornerRadius(config.borderRadius);
            uimg.canvas.Background = ib_;

            //rotateUIE_TextElement(uimg);
            //determineColorScheme_UIE_TextElement(uimg);

            uimg.MouseDown += utex_MouseDown;
            uimg.MouseMove += utex_MouseMove;
            uimg.MouseUp += utex_MouseUp;

            return uimg;
        }



        private UIE_TextElement drawUIE_TextElement()
        {
            parseTextboxes();

            UIE_TextElement utex = new UIE_TextElement();

            utex.Name = $"utex{drawTextElement}";
            drawTextElement++;

            utex.border.BorderBrush = new SolidColorBrush(yrs_color_feature.getColor);
            utex.border.BorderThickness = new Thickness(2);

            utex.border.Height = elementHeight;
            utex.border.Width = elementWidth;

            utex.border.CornerRadius = new CornerRadius(3);

            rotateUIE_TextElement(utex);
            determineColorScheme_UIE_TextElement(utex);

            //lt.Stroke = new SolidColorBrush(Colors.Black);
            //lt.StrokeThickness = 15;

            Canvas.SetLeft(utex, 250);
            Canvas.SetTop(utex, 250);
            Panel.SetZIndex(utex, elementZindex);

            //drawTriangleID++;

            utex.MouseDown += utex_MouseDown;
            utex.MouseMove += utex_MouseMove;
            utex.MouseUp += utex_MouseUp;

            MainWindowCanvas.Children.Add(utex);

            return utex;
        }

        private YRS_ColorFeature drawYRS_ColorFeature()
        {
            //parseTextboxes();

            RotateTransform rt = new RotateTransform();
            rt.Angle = elementAngle;

            yrs_color_feature.RenderTransform = rt;

            //lt.Stroke = new SolidColorBrush(Colors.Black);
            //lt.StrokeThickness = 15;

            yrs_color_feature.border.Background = config.backColor;
            yrs_color_feature.border.BorderBrush = config.foreColor;
            yrs_color_feature.border.BorderThickness = new Thickness(3);

            Canvas.SetLeft(yrs_color_feature, 5);
            Canvas.SetBottom(yrs_color_feature, 5);
            Panel.SetZIndex(yrs_color_feature, 2005);

            //drawTriangleID++;

            yrs_color_feature.MouseDown += utex_MouseDown;
            yrs_color_feature.MouseMove += utex_MouseMove;
            yrs_color_feature.MouseUp += utex_MouseUp;

            MainWindowCanvas.Children.Add(yrs_color_feature);

            return yrs_color_feature;
        }


        private void parseTextboxes()
        {
            string message = "";

            try
            {
                cascadeAmount = Int32.Parse(tbxAmount.Text);

                elementWidth = Int32.Parse(tbxWidth.Text);
                elementHeight = Int32.Parse(tbxHeight.Text);

                elementZindex = Int32.Parse(tbxZindex.Text);
                elementAngle = Double.Parse(tbxAngle.Text);

                x = Double.Parse(tbxX.Text);
                y = Double.Parse(tbxY.Text);

                parseFail = false;
            }
            catch (Exception e)
            {
                parseFail = true;
                message = e.Message;

                //MessageBox.Show($"{message}{scetchboardTexts.textbox_parseFail_exception()}");
            }
        }

        // rotate element upon creation
        private void rotateShape(Shape shape)
        {
            if (parseFail == false)
            {
                RotateTransform rt = new RotateTransform();

                rt.CenterX = elementWidth * 0.5;
                rt.CenterY = elementHeight * 0.5;

                rt.Angle = elementAngle;

                shape.Height = geom.avoidNegativity(elementHeight);
                shape.Width = geom.avoidNegativity(elementWidth);

                shape.RenderTransform = rt;
            }
            else if (parseFail == true)
            {
                shape.Width = 100;
                shape.Height = 50;
            }
        }

        private void rotateUIE_TextElement(UIE_TextElement uiet)
        {
            if (parseFail == false)
            {
                RotateTransform rt = new RotateTransform();

                rt.CenterX = elementWidth * 0.5;
                rt.CenterY = elementHeight * 0.5;

                rt.Angle = elementAngle;

                uiet.Height = geom.avoidNegativity(elementHeight);
                uiet.Width = geom.avoidNegativity(elementWidth);

                uiet.RenderTransform = rt;
            }
            else if (parseFail == true)
            {
                //uiet.Width = 100;
                //uiet.Height = 50;
            }
        }


        #endregion design

        // load stuff
        #region loading

        private void load_A(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_A_Click;

            uie.changeIconTo_A();

            load_button_appearance(uie, style);
        }

        private void load_button_appearance(UIE_CascadeButton ui_element, Style _style)
        {
            ui_element.uie_cascade_button.Background = uic.transparent;

            ui_element.uie_cascade_button_border.CornerRadius = new CornerRadius(config.borderRadius);
            ui_element.uie_cascade_button_border.BorderThickness = new Thickness(2);
            ui_element.uie_cascade_button_border.BorderBrush = config.btnForeColor;
            ui_element.uie_cascade_button_border.Background = config.btnBackColor;

            ui_element.uie_cascade_button.Style = _style;

            wrpMenu.Children.Add(ui_element);
        }

        private void load_rectangleButton(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_rectangle_button_Click;

            uie.changeIconTo_singularRectangle();

            load_button_appearance(uie, style);
        }

        private void load_rectangleCascade(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_cascade_button_Click;

            uie.changeIconTo_cascadingRectangles();

            load_button_appearance(uie, style);
        }

        private void load_ellipseButton(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_circle_button_Click;

            uie.changeIconTo_singularEllipse();

            load_button_appearance(uie, style);
        }

        private void load_ellipseCascade(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_cascade_ellipses_button_Click;

            uie.changeIconTo_cascadingEllipses();

            load_button_appearance(uie, style);
        }

        private void load_triangle_equilateral_Button(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_triangle_equilateral_button_Click;

            uie.changeIconTo_singularTriangle_equilateral();

            load_button_appearance(uie, style);
        }

        private void load_triangle_isosceles_Button(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_triangle_isosceles_button_Click;

            uie.changeIconTo_singularTriangle_isosceles();

            load_button_appearance(uie, style);
        }

        private void load_triangle_rectangular_Button(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_triangle_rectangular_button_Click;

            uie.changeIconTo_singularTriangle();

            load_button_appearance(uie, style);
        }

        private void load_triangleCascade(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_cascade_triangles_button_Click;

            uie.changeIconTo_cascadingTriangles();

            load_button_appearance(uie, style);
        }

        private void load_lineButton(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_line_button_Click;

            uie.changeIconTo_Line();

            load_button_appearance(uie, style);
        }

        private void loadMenuButtons()
        {
            Style style = this.FindResource("buttonStyle") as Style;

            load_rectangleButton(style);
            load_rectangleCascade(style);

            load_ellipseButton(style);
            load_ellipseCascade(style);

            load_triangle_equilateral_Button(style);
            load_triangle_isosceles_Button(style);
            load_triangle_rectangular_Button(style);
            load_triangleCascade(style);

            load_lineButton(style);
            load_A(style);
            //load_TextElement(style);
        }
        #endregion loading

        // modules
        #region module creation
        private UIE_ImageElement modul_ImageElement(ImageBrush ib_)
        {
            parseTextboxes();

            UIE_image_element = new UIE_ImageElement(elementWidth, elementHeight);

            UIE_image_element.Name = $"uimg{drawImageElement}";
            drawImageElement++;

            UIE_image_element.border.BorderBrush = config.foreColor;
            UIE_image_element.border.BorderThickness = new Thickness(3);
            UIE_image_element.border.CornerRadius = new CornerRadius(config.borderRadius);
            UIE_image_element.canvas.Background = ib_;

            //rotateUIE_TextElement(uimg);
            //determineColorScheme_UIE_TextElement(uimg);

            Canvas.SetLeft(UIE_image_element, x);
            Canvas.SetTop(UIE_image_element, y);
            Panel.SetZIndex(UIE_image_element, elementZindex);

            if (loaded == true)
            {
                UIE_image_element.border.Width = elementWidth;
                UIE_image_element.border.Height = elementHeight;
                UIE_image_element.canvas.HorizontalAlignment = HorizontalAlignment.Stretch;
                UIE_image_element.canvas.VerticalAlignment = VerticalAlignment.Stretch;
            }
            else
            {
                UIE_image_element.border.Width = 420;
                UIE_image_element.border.Height = 250;
            }

            RotateTransform rt = new RotateTransform();

            rt.CenterX = elementWidth * 0.5;
            rt.CenterY = elementHeight * 0.5;

            rt.Angle = elementAngle;

            UIE_image_element.RenderTransform = rt;

            UIE_image_element.MouseDown += UIE_image_element_MouseDown;
            UIE_image_element.MouseMove += UIE_image_element_MouseMove;
            UIE_image_element.MouseUp += UIE_image_element_MouseUp;

            listOfImageElements.Add(UIE_image_element);

            return UIE_image_element;
        }

        private UIE_MainWindowMenuElement modul_MainWindowMenuElement()
        {
            parseTextboxes();

            UIE_menu_element = new UIE_MainWindowMenuElement();

            UIE_menu_element.Name = $"uime{drawMainWindowMenuElement}";
            drawMainWindowMenuElement++;

            UIE_menu_element.generate_Menu_Module();

            Canvas.SetLeft(UIE_menu_element, x);
            Canvas.SetTop(UIE_menu_element, y);
            Panel.SetZIndex(UIE_menu_element, elementZindex);

            RotateTransform rt = new RotateTransform();

            rt.CenterX = elementWidth * 0.5;
            rt.CenterY = elementHeight * 0.5;

            rt.Angle = elementAngle;

            UIE_menu_element.RenderTransform = rt;

            UIE_menu_element.MouseDown += UIE_menu_element_MouseDown;
            UIE_menu_element.MouseMove += UIE_menu_element_MouseMove;
            UIE_menu_element.MouseUp += UIE_menu_element_MouseUp;

            listOfMenuElements.Add(UIE_menu_element);

            return UIE_menu_element;
        }

        public UIE_ScetchboardElement modul_ScetchboardElement()
        {
            parseTextboxes();

            UIE_scetchboard_element = new UIE_ScetchboardElement();

            UIE_scetchboard_element.Name = $"uisc{drawScetchboardElement}";
            drawScetchboardElement++;

            Canvas.SetLeft(UIE_scetchboard_element, x);
            Canvas.SetTop(UIE_scetchboard_element, y);
            Panel.SetZIndex(UIE_scetchboard_element, elementZindex);

            if (loaded == true)
            {

                UIE_scetchboard_element.Height = elementHeight;
                UIE_scetchboard_element.Width = elementWidth;

            }
            else
            {
                UIE_scetchboard_element.Height = 250;
                UIE_scetchboard_element.Width = 420;
            }

            RotateTransform rt = new RotateTransform();

            rt.Angle = elementAngle;

            UIE_scetchboard_element.RenderTransform = rt;

            UIE_scetchboard_element.MouseDown += UIE_scetchboard_element_MouseDown;
            UIE_scetchboard_element.MouseMove += UIE_scetchboard_element_MouseMove;
            UIE_scetchboard_element.MouseUp += UIE_scetchboard_element_MouseUp;

            UIE_scetchboard_element.canvasLoad();

            listOfScetchboardElements.Add(UIE_scetchboard_element);

            return UIE_scetchboard_element;
        }

        public UIE_SelectionBindingElement modul_SelectionBindingElement()
        {
            parseTextboxes();

            UIE_selection_binding_element = new UIE_SelectionBindingElement();

            UIE_selection_binding_element.Name = $"uime{drawSelectionBindingElement}";
            drawMainWindowMenuElement++;

            Canvas.SetLeft(UIE_selection_binding_element, x);
            Canvas.SetTop(UIE_selection_binding_element, y);
            Panel.SetZIndex(UIE_selection_binding_element, elementZindex);

            if (loaded == true)
            {
                UIE_selection_binding_element.Height = elementHeight;
                UIE_selection_binding_element.Width = elementWidth;
            }
            else
            {
                UIE_selection_binding_element.Height = 250;
                UIE_selection_binding_element.Width = 420;
            }

            RotateTransform rt = new RotateTransform();

            //if (loaded == true)
            //{
            //    UIE_selection_binding_element.border.Width = elementWidth;
            //    UIE_selection_binding_element.border.Height = elementHeight;
            //}
            //else
            //{
            //    UIE_selection_binding_element.border.Width = 400;
            //    UIE_selection_binding_element.border.Height = 200;
            //}

            rt.Angle = elementAngle;

            UIE_selection_binding_element.RenderTransform = rt;

            UIE_selection_binding_element.MouseDown += UIE_selection_binding_element_MouseDown;
            UIE_selection_binding_element.MouseMove += UIE_selection_binding_element_MouseMove;
            UIE_selection_binding_element.MouseUp += UIE_selection_binding_element_MouseUp;

            listOfSelectionBindingElements.Add(UIE_selection_binding_element);

            return UIE_selection_binding_element;
        }

        public void resizeTimerModule(Button _to_be_changed)
        {
            //UIE_TimerElement uite = new UIE_TimerElement();

            /////////FindParent(_to_be_changed);?????

            //uite.btnTakeABreak = _to_be_changed;

            //uite.brdBtnTakeABreak.Width = 420;


            ////_to_be_changed.Width = ActualWidth * 2;

        }


        public UIE_TimerElement modul_TimerElement()
        {            
            parseTextboxes();

            UIE_timer_element = new UIE_TimerElement();

            UIE_timer_element.Name = $"uime{drawTimerElement}";
            drawTimerElement++;

            Canvas.SetLeft(UIE_timer_element, x);
            Canvas.SetTop(UIE_timer_element, y);
            Panel.SetZIndex(UIE_timer_element, elementZindex);

            if (loaded == true)
            {
                UIE_timer_element.Height = elementHeight;
                UIE_timer_element.Width = elementWidth;
            }
            else
            {
                UIE_timer_element.Height = 250;
                UIE_timer_element.Width = 420;
            }
            

            RotateTransform rt = new RotateTransform();

            rt.CenterX = elementWidth * 0.5;
            rt.CenterY = elementHeight * 0.5;

            rt.Angle = elementAngle;

            UIE_timer_element.RenderTransform = rt;

            UIE_timer_element.MouseDown += UIE_timer_element_MouseDown;
            UIE_timer_element.MouseMove += UIE_timer_element_MouseMove;
            UIE_timer_element.MouseUp += UIE_timer_element_MouseUp;

            listOfTimerElements.Add(UIE_timer_element);

            return UIE_timer_element;
        }
        #endregion module creation


        // processing
        #region processing
        private UIE_ImageElement mainWindowCanvas_Drop_processing(UIE_ImageElement img_, int i_)
        {
            double deltax = x * i_;
            double deltay = y * i_;

            Canvas.SetLeft(img_, deltax);
            Canvas.SetTop(img_, deltay);

            Panel.SetZIndex(img_, elementZindex);

            return img_;
        }

        public void mainWindow_Shutdown_processing()
        {
            _pulse.Stop();

            config.mainWindowHeight = (int)Height;
            config.mainWindowWidth = (int)Width;

            config.saveConfig(btnSetList, setList, configList);
            config.saveSettings();

            Application.Current.Shutdown();
        }

        private LinearGradientBrush linearGradientOrientation_processing()
        {
            LinearGradientBrush Line = new LinearGradientBrush();

            if (rb_orientationBottom.IsChecked == true)
            {
                Line = new LinearGradientBrush(
                    color1.Color,
                    color2.Color,
                    90);

                return Line;
            }
            else if (rb_orientationTop.IsChecked == true)
            {
                Line = new LinearGradientBrush(
                    color2.Color,
                    color1.Color,
                    90);

                return Line;
            }
            else if (rb_orientationLeft.IsChecked == true)
            {
                Line = new LinearGradientBrush(
                    color1.Color,
                    color2.Color,
                    0
                    );

                return Line;
            }
            else if (rb_orientationRight.IsChecked == true)
            {
                Line = new LinearGradientBrush(
                    color2.Color,
                    color1.Color,
                    0
                    );

                return Line;
            }
            return Line;
        }

        // change color on item
        private void setColorOnShape(Shape shape)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                check_rbGroup_LinearGradientOrientation(shape);
            }
            else if (rb_solidBrush.IsChecked == true)
            {
                solidColorFill(shape);
            }
        }

        private void setColorOnUIE_TextElement(UIE_TextElement uiet)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                check_rbGroup_LinearGradientOrientation_UIE_TextElement(uiet);
            }
            else if (rb_solidBrush.IsChecked == true)
            {
                solidColorFill_UIE_Textelement(uiet);
            }
        }

        private void setColorOnUIE_ImageElement(UIE_ImageElement uiei)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                colorChoiceFunction();
                uiei.ImageElement.border.Background = new RadialGradientBrush(color1.Color, color2.Color);
                uiei.ImageElement.border.BorderBrush = new SolidColorBrush(yrs_color_feature.getColor);
                uiei.ImageElement.border.BorderThickness = new Thickness(3);

            }
            else if (rb_solidBrush.IsChecked == true)
            {
                colorChoiceFunction();
                uiei.ImageElement.border.Background = new SolidColorBrush(yrs_color_feature.getColor);
                uiei.ImageElement.border.BorderBrush = new SolidColorBrush(yrs_color_feature.getColor);
                uiei.ImageElement.border.BorderThickness = new Thickness(3);
            }
        }


        // change z-index on item
        private void setZindexOnShape(Shape shape)
        {
            parseTextboxes();

            Panel.SetZIndex(shape, elementZindex);
        }

        private void setZindexOn_UIE_Textelement(UIE_TextElement uiet)
        {
            parseTextboxes();

            Panel.SetZIndex(uiet, elementZindex);
        }

        private Point simulatePadding(Point pnt)
        {
            if (pnt.X < 5)
            {
                pnt.X = 5;
            }
            else if (pnt.X > MainWindowCanvas.ActualWidth - 5)
            {
                pnt.X = MainWindowCanvas.ActualWidth - 5;
            }

            if (pnt.Y < 5)
            {
                pnt.Y = 5;
            }
            else if (pnt.Y > MainWindowCanvas.ActualHeight - 5)
            {
                pnt.Y = MainWindowCanvas.ActualHeight - 5;
            }
            else if (pnt.X > MainWindowCanvas.ActualWidth || pnt.X < 5
                || pnt.Y > MainWindowCanvas.ActualHeight || pnt.Y < 5)
            {
                if (x_pressed == true)
                {
                    x_pressed_MouseUp();
                }
                else if (y_pressed == true)
                {
                    y_pressed_MouseUp();
                }
            }

            return pnt;
        }

        private void solidColorFill(Shape _shape)
        {
            _shape.Fill = new SolidColorBrush(yrs_color_feature.getColor);
            _shape.Stroke = yrs_color_feature.returnSolidColorBrush(color2.Color);
        }

        private void solidColorFill_UIE_Textelement(UIE_TextElement uiet)
        {
            uiet.border.Background = new SolidColorBrush(yrs_color_feature.getColor);
            uiet.textbox.Foreground = yrs_color_feature.returnSolidColorBrush(color1.Color);
        }
        #endregion processing

        private string filenameCheck(string filename_)
        {
            string filetype = "file";

            if (filename_.EndsWith("png") || filename_.EndsWith("jpg") || filename_.EndsWith("jpeg"))
            {
                filetype = "image";

                return filetype;
            }
            else if (filename_.EndsWith("wav") || filename_.EndsWith("mpeg") || filename_.EndsWith("mp3"))
            {
                filetype = "sound";

                return filetype;
            }
            else return filetype;
        }


        // events
        private void MainWindowCanvas_Drop(object sender, DragEventArgs e)
        {
            parseTextboxes();

            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = e.Data.GetData(DataFormats.FileDrop) as string[];

                for (int i = 0; i < files.Length; i++)
                {
                    string filename = System.IO.Path.GetFileName(files[i]);

                    string filepath = System.IO.Path.GetFullPath(files[i]);

                    string filetype = filenameCheck(filename);


                    if (filetype == "image" && files[i] != null && files[i].Length > 0)
                    {
                        BitmapImage theImage = new BitmapImage
                            (new Uri(filepath, UriKind.Absolute));

                        ImageBrush myImageBrush = new ImageBrush(theImage);

                        UIE_ImageElement uIE_ImageElement = modul_ImageElement(myImageBrush);

                        mainWindowCanvas_Drop_processing(uIE_ImageElement, i);

                        MainWindowCanvas.Children.Add(uIE_ImageElement);
                    }

                    else if (filetype == "file" && files[i] != null && files[i].Length > 0)
                    {
                        UIE_SelectionBindingElement uIE_sBElement = modul_SelectionBindingElement();

                        uIE_sBElement.SelectionBindingElement.filepath = filepath;
                        uIE_sBElement.SelectionBindingElement.filename = filename;

                        ImageSource imso = uIE_sBElement.SelectionBindingElement.GetIcon(filepath);
                        uIE_sBElement.SelectionBindingElement.imageUICtrl.Source = imso;

                        uIE_sBElement.SelectionBindingElement.tb.Text = filename;
                        uIE_sBElement.SelectionBindingElement.tb.TextAlignment = TextAlignment.Center;

                        uIE_sBElement.SelectionBindingElement.btn.ToolTip = $"{filename}";

                        MainWindowCanvas.Children.Add(uIE_sBElement);
                    }
                    else if (filetype == "sound" && files[i] != null && files[i].Length > 0)
                    {
                        //UIE_SelectionBindingElement uIE_sBElement = modul_SelectionBindingElement();

                        //uIE_sBElement.SelectionBindingElement.filepath = filepath;
                        //uIE_sBElement.SelectionBindingElement.filename = filename;

                        //ImageSource imso = uIE_sBElement.SelectionBindingElement.GetIcon(filepath);
                        //uIE_sBElement.SelectionBindingElement.imageUICtrl.Source = imso;

                        //uIE_sBElement.SelectionBindingElement.tb.Text = filename;
                        //uIE_sBElement.SelectionBindingElement.tb.TextAlignment = TextAlignment.Center;

                        //uIE_sBElement.SelectionBindingElement.btn.ToolTip = $"{filename}";

                        //MainWindowCanvas.Children.Add(uIE_sBElement);
                    }
                }
            }
        }
        private void MainWindowCanvas_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.B)
            {
                MainWindowCanvas.Background = yrs_color_feature.returnSolidColorBrush(yrs_color_feature.getColor);

                e.Handled = false;
            }

            if (e.Key == Key.D)
            {
                if (yrs_color_feature.buttonChecked == false)
                {
                    yrs_color_feature.buttonChecked = true;
                }
                else if (yrs_color_feature.buttonChecked == true)
                {
                    yrs_color_feature.buttonChecked = false;
                }

                e.Handled = false;
            }

            if (e.Key == Key.F2)
            {
                config.saveScetchboardPictureToPNG(MainWindowCanvas);
            }

            if (e.Key == Key.S)
            {
                e.Handled = false;

                if (x_pressed == true || y_pressed == true)
                {
                    x_pressed = false;
                    y_pressed = false;
                }
            }


            if (e.Key == Key.X)
            {
                //drawSimpleRectangle();
                e.Handled = false;

                if (s_pressed == true || y_pressed == true)
                {
                    s_pressed = false;
                    y_pressed = false;
                }
            }


            if (e.Key == Key.Y)
            {
                //drawSimpleRectangle();
                e.Handled = false;

                if (s_pressed == true || x_pressed == true)
                {
                    s_pressed = false;
                    x_pressed = false;
                }
            }
        }

        private void MainWindowCanvas_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.B)
            {
                e.Handled = true;
            }

            if (e.Key == Key.D)
            {
                if (d_pressed == true)
                {
                    d_pressed = false;

                    lbl_colorFeatureVisibilityStatus.Content = "no key mode active";
                }
                else if (d_pressed == false)
                {
                    d_pressed = true;

                    lbl_colorFeatureVisibilityStatus.Content = "Mode: 'key d pressed ' change colors on buttons";
                }

                e.Handled = true;
            }

            if (e.Key == Key.H)
            {
                if (h_pressed == true)
                {
                    h_pressed = false;

                    lbl_colorFeatureVisibilityStatus.Content = "no key mode active";
                }
                else if (h_pressed == false)
                {
                    h_pressed = true;

                    lbl_colorFeatureVisibilityStatus.Content = "Mode: 'key h pressed ' hide color feature";
                }

                e.Handled = true;
            }


            if (e.Key == Key.S)
            {
                if (s_pressed == true)
                {
                    s_pressed = false;

                    lbl_activeMode.Content = "no key mode active";
                }
                else if (s_pressed == false)
                {
                    s_pressed = true;

                    lbl_activeMode.Content = "Mode: 'key s pressed ' draw free hand scetch line";
                }

                e.Handled = true;
            }

            if (e.Key == Key.X)
            {
                if (x_pressed == true)
                {
                    x_pressed = false;

                    lbl_activeMode.Content = "no key mode active";
                }
                else if (x_pressed == false)
                {
                    x_pressed = true;

                    lbl_activeMode.Content = "Mode: 'key x pressed ' draw free hand rectangle shapes";
                }

                e.Handled = true;
            }

            if (e.Key == Key.Y)
            {
                if (y_pressed == true)
                {
                    y_pressed = false;

                    lbl_activeMode.Content = "no key mode active";
                }
                else if (y_pressed == false)
                {
                    y_pressed = true;

                    lbl_activeMode.Content = "Mode: 'key y pressed ' -> draw free hand ellipse shapes";
                }

                e.Handled = true;
            }

        }

        private void MainWindowCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            // lbl_colorFeatureVisibilityStatus.Content = "Mode: 'key d pressed ' change colors on buttons";
            d_pressed = false;
        }



        private void MainWindowCanvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                if (s_pressed == false && x_pressed == false && y_pressed == false)
                {
                    // hier gibt es ab und an einen bug wegen irgendwas, gerade vergessen.
                    try
                    {
                        ButtonMap.DragMove();
                    }
                    catch (Exception)
                    {
                    }
                }
                else
                {
                    s_pressed_MouseDown(e);
                    x_pressed_MouseDown(e);
                    y_pressed_MouseDown(e);
                }



                e.Handled = true;
            }
        }

        private void MainWindowCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            s_pressed_MouseMove(e);

            x_pressed_MouseMove(e);

            y_pressed_MouseMove(e);

            e.Handled = true;
        }

        private void MainWindowCanvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                x_pressed_MouseUp();
                y_pressed_MouseUp();

                e.Handled = true;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                disableDragState();

                e.Handled = true;
            }
        }


        private void MainWindowCanvas_PreviewDragOver(object sender, DragEventArgs e)
        {
            e.Handled = true;
        }

        #region buttons
        // on buttons
        private void Uie_A_Click(object sender, RoutedEventArgs e)
        {
            drawUIE_TextElement();
        }

        private void Uie_cascade_button_Click(object sender, RoutedEventArgs e)
        {
            drawCascade_Rectangles();
        }

        private void Uie_cascade_ellipses_button_Click(object sender, RoutedEventArgs e)
        {
            drawCascade_Ellipses();
        }

        private void Uie_cascade_triangles_button_Click(object sender, RoutedEventArgs e)
        {
            drawCascade_Triangles();
        }

        private void Uie_circle_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleEllipse();
        }

        private void Uie_line_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleLine();
        }

        private void Uie_rectangle_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleRectangle();
        }

        private void Uie_TextElement_Click(object sender, RoutedEventArgs e)
        {
            drawUIE_TextElement();
        }

        private void Uie_triangle_equilateral_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleTriangle_equilateral();
        }

        private void Uie_triangle_isosceles_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleTriangle_isosceles();
        }

        private void Uie_triangle_rectangular_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleTriangle_rectangular();
        }
        #endregion buttons

        // mouse ups
        #region mouse ups
        private void UIE_image_element_MouseUp(object sender, MouseButtonEventArgs e)
        {
            UIE_ImageElement uiie = (UIE_ImageElement)sender;

            if (e.ChangedButton == MouseButton.Middle)
            {
                disableDragState();

                Panel.SetZIndex(uiie, elementZindex);
            }

            e.Handled = true;
        }
        private void UIE_menu_element_MouseUp(object sender, MouseButtonEventArgs e)
        {
            UIE_MainWindowMenuElement uime = (UIE_MainWindowMenuElement)sender;

            if (e.ChangedButton == MouseButton.Middle)
            {
                disableDragState();

                Panel.SetZIndex(uime, elementZindex);
            }

            e.Handled = true;
        }
        private void UIE_scetchboard_element_MouseUp(object sender, MouseButtonEventArgs e)
        {
            UIE_ScetchboardElement uise = (UIE_ScetchboardElement)sender;

            if (e.ChangedButton == MouseButton.Middle)
            {
                disableDragState();

                Panel.SetZIndex(uise, elementZindex);
            }

            e.Handled = true;
        }
        private void UIE_selection_binding_element_MouseUp(object sender, MouseButtonEventArgs e)
        {
            UIE_SelectionBindingElement usbe = (UIE_SelectionBindingElement)sender;

            if (e.ChangedButton == MouseButton.Middle)
            {
                disableDragState();

                Panel.SetZIndex(usbe, elementZindex);
            }

            e.Handled = true;
        }
        private void UIE_timer_element_MouseUp(object sender, MouseButtonEventArgs e)
        {
            UIE_TimerElement uite = (UIE_TimerElement)sender;

            if (e.ChangedButton == MouseButton.Middle)
            {
                disableDragState();

                Panel.SetZIndex(uite, elementZindex);
            }

            e.Handled = true;
        }
        #endregion mouse ups


        // mouse moves
        #region mouse move
        private void UIE_image_element_MouseMove(object sender, MouseEventArgs e)
        {
            UIE_ImageElement uime = sender as UIE_ImageElement;

            // if dragging, then adjust rectangle position based on mouse movement
            if (drag_image_element)
            {
                Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                double left = Canvas.GetLeft(uime);
                double top = Canvas.GetTop(uime);
                Canvas.SetLeft(uime, left + (newPoint.X - drag_point_image_element.X));
                Canvas.SetTop(uime, top + (newPoint.Y - drag_point_image_element.Y));

                drag_point_image_element = newPoint;
            }
        }

        private void UIE_menu_element_MouseMove(object sender, MouseEventArgs e)
        {
            UIE_MainWindowMenuElement uime = sender as UIE_MainWindowMenuElement;

            // if dragging, then adjust rectangle position based on mouse movement
            if (drag_menu_element)
            {
                Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                double left = Canvas.GetLeft(uime);
                double top = Canvas.GetTop(uime);
                Canvas.SetLeft(uime, left + (newPoint.X - drag_point_menu_element.X));
                Canvas.SetTop(uime, top + (newPoint.Y - drag_point_menu_element.Y));

                drag_point_menu_element = newPoint;
            }
        }

        private void UIE_scetchboard_element_MouseMove(object sender, MouseEventArgs e)
        {
            UIE_ScetchboardElement uise = sender as UIE_ScetchboardElement;

            // if dragging, then adjust rectangle position based on mouse movement
            if (drag_menu_element)
            {
                Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                double left = Canvas.GetLeft(uise);
                double top = Canvas.GetTop(uise);
                Canvas.SetLeft(uise, left + (newPoint.X - drag_point_scetchboard_element.X));
                Canvas.SetTop(uise, top + (newPoint.Y - drag_point_scetchboard_element.Y));

                drag_point_scetchboard_element = newPoint;
            }
        }

        private void UIE_selection_binding_element_MouseMove(object sender, MouseEventArgs e)
        {
            UIE_SelectionBindingElement usbe = sender as UIE_SelectionBindingElement;

            // if dragging, then adjust rectangle position based on mouse movement
            if (drag_selection_binding_element)
            {
                Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                double left = Canvas.GetLeft(usbe);
                double top = Canvas.GetTop(usbe);
                Canvas.SetLeft(usbe, left + (newPoint.X - drag_point_selection_binding_element.X));
                Canvas.SetTop(usbe, top + (newPoint.Y - drag_point_selection_binding_element.Y));

                drag_point_selection_binding_element = newPoint;
            }
        }
        private void UIE_timer_element_MouseMove(object sender, MouseEventArgs e)
        {
            UIE_TimerElement uite = sender as UIE_TimerElement;

            // if dragging, then adjust rectangle position based on mouse movement
            if (drag_timer_element)
            {
                Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                double left = Canvas.GetLeft(uite);
                double top = Canvas.GetTop(uite);
                Canvas.SetLeft(uite, left + (newPoint.X - drag_point_timer_element.X));
                Canvas.SetTop(uite, top + (newPoint.Y - drag_point_timer_element.Y));

                drag_point_timer_element = newPoint;
            }
        }
        #endregion mouse moves


        #region mouse downs
        // Mouse Downs
        private void UIE_image_element_MouseDown(object sender, MouseButtonEventArgs e)
        {
            UIE_ImageElement uiie = (UIE_ImageElement)sender;

            if (e.ChangedButton == MouseButton.Left)
            {
                colorChoiceFunction();

                uiie.border.Background = linearGradientOrientation_processing();
                uiie.BorderBrush = new SolidColorBrush(yrs_color_feature.getColor);
                //uiie.BorderThickness = 

                parseTextboxes();

                uiie.border.Width = elementWidth;
                uiie.border.Height = elementHeight;

                Canvas.SetLeft(uiie, x);
                Canvas.SetTop(uiie, y);

                Panel.SetZIndex(uiie, elementZindex);

                RotateTransform rt = new RotateTransform();
                rt.Angle = elementAngle;

                uiie.RenderTransform = rt;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                Panel.SetZIndex(uiie, 5000);

                // start dragging
                drag_image_element = true;

                // save start point of dragging
                drag_point_image_element = Mouse.GetPosition(MainWindowCanvas);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(uiie);

                GC.Collect(0);
            }

            e.Handled = true;
        }

        private void UIE_menu_element_MouseDown(object sender, MouseButtonEventArgs e)
        {
            UIE_MainWindowMenuElement uime = (UIE_MainWindowMenuElement)sender;

            if (e.ChangedButton == MouseButton.Left)
            {
                colorChoiceFunction();

                uime.border.Background = linearGradientOrientation_processing();
                uime.BorderBrush = new SolidColorBrush(yrs_color_feature.getColor);
                //uiie.BorderThickness = 

                parseTextboxes();

                uime.border.Width = elementWidth;
                uime.border.Height = elementHeight;

                Canvas.SetLeft(uime, x);
                Canvas.SetTop(uime, y);

                Panel.SetZIndex(uime, elementZindex);

                RotateTransform rt = new RotateTransform();
                rt.Angle = elementAngle;

                uime.RenderTransform = rt;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                Panel.SetZIndex(uime, 5000);

                // start dragging
                drag_menu_element = true;

                // save start point of dragging
                drag_point_menu_element = Mouse.GetPosition(MainWindowCanvas);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(uime);

                GC.Collect(0);
            }

            e.Handled = true;
        }

        private void UIE_scetchboard_element_MouseDown(object sender, MouseButtonEventArgs e)
        {
            UIE_ScetchboardElement uise = (UIE_ScetchboardElement)sender;

            if (e.ChangedButton == MouseButton.Left)
            {
                colorChoiceFunction();

                uise.border.Background = linearGradientOrientation_processing();
                uise.BorderBrush = new SolidColorBrush(yrs_color_feature.getColor);
                //uiie.BorderThickness = 

                parseTextboxes();

                uise.border.Width = elementWidth;
                uise.border.Height = elementHeight;

                Canvas.SetLeft(uise, x);
                Canvas.SetTop(uise, y);

                Panel.SetZIndex(uise, elementZindex);

                RotateTransform rt = new RotateTransform();
                rt.Angle = elementAngle;

                uise.RenderTransform = rt;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                Panel.SetZIndex(uise, 5000);

                // start dragging
                drag_scetchboard_element = true;

                // save start point of dragging
                drag_point_scetchboard_element = Mouse.GetPosition(MainWindowCanvas);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(uise);

                GC.Collect(0);
            }

            e.Handled = true;
        }

        private void UIE_selection_binding_element_MouseDown(object sender, MouseButtonEventArgs e)
        {
            UIE_SelectionBindingElement usbe = (UIE_SelectionBindingElement)sender;

            if (e.ChangedButton == MouseButton.Left)
            {
                colorChoiceFunction();

                //colorSelectionMethodApplication(); // not yet in existance/ existing .
                usbe.border.Background = linearGradientOrientation_processing();
                usbe.BorderBrush = new SolidColorBrush(yrs_color_feature.getColor);
                //uiie.BorderThickness = 

                parseTextboxes();

                usbe.border.Width = elementWidth;
                usbe.border.Height = elementHeight;

                Canvas.SetLeft(usbe, x);
                Canvas.SetTop(usbe, y);

                Panel.SetZIndex(usbe, elementZindex);

                RotateTransform rt = new RotateTransform();
                rt.Angle = elementAngle;

                usbe.RenderTransform = rt;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                Panel.SetZIndex(usbe, 5000);

                // start dragging
                drag_selection_binding_element = true;

                // save start point of dragging
                drag_point_selection_binding_element = Mouse.GetPosition(MainWindowCanvas);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(usbe);

                GC.Collect(0);
            }

            e.Handled = true;
        }

        private void UIE_timer_element_MouseDown(object sender, MouseButtonEventArgs e)
        {
            UIE_TimerElement uite = (UIE_TimerElement)sender;

            if (e.ChangedButton == MouseButton.Left)
            {
                colorChoiceFunction();

                //colorSelectionMethodApplication(); // not yet in existance/ existing .
                uite.border.Background = linearGradientOrientation_processing();
                uite.BorderBrush = new SolidColorBrush(yrs_color_feature.getColor);
                //uiie.BorderThickness = 

                parseTextboxes();

                uite.border.Width = elementWidth;
                uite.border.Height = elementHeight;

                Canvas.SetLeft(uite, x);
                Canvas.SetTop(uite, y);

                Panel.SetZIndex(uite, elementZindex);

                RotateTransform rt = new RotateTransform();
                rt.Angle = elementAngle;

                uite.RenderTransform = rt;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                Panel.SetZIndex(uite, 5000);

                // start dragging
                drag_timer_element = true;

                // save start point of dragging
                drag_point_timer_element = Mouse.GetPosition(MainWindowCanvas);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(uite);

                GC.Collect(0);
            }

            e.Handled = true;
        }
        #endregion mouse downs        

        // MainWindowCanvas control events
        #region MainWindowCanvas control events

        // on ellipses
        private void Ell_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Ellipse ellp = (Ellipse)sender;

            Panel.SetZIndex(ellp, 5000);

            if (e.ChangedButton == MouseButton.Middle)
            {
                // start dragging
                drag_ellp = true;
                // save start point of dragging
                startPoint_ellp = Mouse.GetPosition(MainWindowCanvas);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(ellp);

                e.Handled = true;

                GC.Collect(0);
            }

            if (e.ChangedButton == MouseButton.Left)
            {
                setColorOnShape(ellp);

                setZindexOnShape(ellp);
            }
        }

        private void Ell_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag_ellp)
            {
                Ellipse draggedEllipse = sender as Ellipse;
                Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                double left = Canvas.GetLeft(draggedEllipse);
                double top = Canvas.GetTop(draggedEllipse);
                Canvas.SetLeft(draggedEllipse, left + (newPoint.X - startPoint_ellp.X));
                Canvas.SetTop(draggedEllipse, top + (newPoint.Y - startPoint_ellp.Y));

                startPoint_ellp = newPoint;
            }
        }



        private void Ell_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Middle)
            {
                Ellipse ellp = (Ellipse)sender;

                Panel.SetZIndex(ellp, elementZindex);

                disableDragState();

                e.Handled = true;
            }
        }

        private void pylin_MouseDown(object sender, MouseButtonEventArgs e)
        {
            selectedShape = sender as Shape;

            Panel.SetZIndex(selectedShape, 1000);

            if (e.ChangedButton == MouseButton.Middle)
            {
                if (dragging == false)
                {
                    dragging = true;
                    clickV = e.GetPosition(selectedShape);
                }

                e.Handled = true;
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(selectedShape);

                e.Handled = true;

                GC.Collect(0);
            }

            if (e.ChangedButton == MouseButton.Left)
            {
                setColorOnShape(selectedShape);

                setZindexOnShape(selectedShape);
            }
        }


        private void pylin_MouseMove(object sender, MouseEventArgs e)
        {
            Polyline pylin = selectedShape as Polyline;

            if (dragging)
            {
                Canvas.SetLeft(pylin, e.GetPosition(MainWindowCanvas).X - geom.avoidNegativity(clickV.X));
                Canvas.SetTop(pylin, e.GetPosition(MainWindowCanvas).Y - geom.avoidNegativity(clickV.Y));
            }
        }

        private void pylin_MouseUp(object sender, MouseButtonEventArgs e)
        {
            selectedShape = sender as Shape;

            if (e.ChangedButton == MouseButton.Middle)
            {
                disableDragState();
            }

            e.Handled = true;
        }



        private void pygon_MouseDown(object sender, MouseButtonEventArgs e)
        {
            selectedShape = sender as Shape;

            Panel.SetZIndex(selectedShape, 1000);

            if (e.ChangedButton == MouseButton.Middle)
            {
                if (dragging == false)
                {
                    dragging = true;
                    clickV = e.GetPosition(selectedShape);
                }

                e.Handled = true;
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(selectedShape);

                e.Handled = true;

                GC.Collect(0);
            }

            if (e.ChangedButton == MouseButton.Left)
            {
                setColorOnShape(selectedShape);

                setZindexOnShape(selectedShape);
            }
        }


        private void pygon_MouseMove(object sender, MouseEventArgs e)
        {
            Polygon pygon = selectedShape as Polygon;

            if (dragging)
            {
                Canvas.SetLeft(pygon, e.GetPosition(MainWindowCanvas).X - geom.avoidNegativity(clickV.X));
                Canvas.SetTop(pygon, e.GetPosition(MainWindowCanvas).Y - geom.avoidNegativity(clickV.Y));
            }
        }

        private void pygon_MouseUp(object sender, MouseButtonEventArgs e)
        {
            selectedShape = sender as Shape;

            if (e.ChangedButton == MouseButton.Middle)
            {
                disableDragState();
            }

            e.Handled = true;
        }


        // on rectangles
        private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Shapes.Rectangle rect = (System.Windows.Shapes.Rectangle)sender;

            Panel.SetZIndex(rect, 1000);

            if (e.ChangedButton == MouseButton.Middle)
            {
                // start dragging
                drag = true;
                // save start point of dragging
                startPoint = Mouse.GetPosition(MainWindowCanvas);

                e.Handled = true;
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(rect);

                e.Handled = true;

                GC.Collect(0);
            }

            if (e.ChangedButton == MouseButton.Left)
            {
                setColorOnShape(rect);
                setZindexOnShape(rect);
            }
        }

        private void Rectangle_MouseMove(object sender, MouseEventArgs e)
        {
            // if dragging, then adjust rectangle position based on mouse movement
            if (drag)
            {
                System.Windows.Shapes.Rectangle draggedRectangle = sender as System.Windows.Shapes.Rectangle;
                Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                double left = Canvas.GetLeft(draggedRectangle);
                double top = Canvas.GetTop(draggedRectangle);
                Canvas.SetLeft(draggedRectangle, left + (newPoint.X - startPoint.X));
                Canvas.SetTop(draggedRectangle, top + (newPoint.Y - startPoint.Y));

                startPoint = newPoint;
            }
        }

        private void Rectangle_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Middle)
            {
                System.Windows.Shapes.Rectangle rect = (System.Windows.Shapes.Rectangle)sender;

                disableDragState();

                Panel.SetZIndex(rect, elementZindex);
            }
        }

        private void utex_MouseDown(object sender, MouseButtonEventArgs e)
        {

            if (e.ChangedButton == MouseButton.Middle)
            {
                if (sender is UIE_TextElement)
                {
                    UIE_TextElement utex = (UIE_TextElement)sender;

                    //MessageBox.Show("huhu textelement hier");

                    Panel.SetZIndex(utex, 1000);
                    // start dragging
                    drag_canvas = true;
                    // save start point of dragging
                    startPoint_mycanvas = Mouse.GetPosition(MainWindowCanvas);

                    e.Handled = true;
                }

                else if (sender is UIE_ImageElement)
                {
                    UIE_ImageElement utex = (UIE_ImageElement)sender;

                    //MessageBox.Show("huhu bildelement hier");
                    Panel.SetZIndex(utex, 1000);
                    // start dragging
                    drag_canvas = true;
                    // save start point of dragging
                    startPoint_mycanvas = Mouse.GetPosition(MainWindowCanvas);

                    e.Handled = true;
                }

                else if (sender is YRS_ColorFeature)
                {
                    YRS_ColorFeature utex = (YRS_ColorFeature)sender;

                    //MessageBox.Show("huhu bildelement hier");
                    Panel.SetZIndex(utex, 1000);
                    // start dragging
                    drag_canvas = true;
                    // save start point of dragging
                    startPoint_menuElements = Mouse.GetPosition(MainWindowCanvas);

                    e.Handled = true;
                }
            }
            if (e.ChangedButton == MouseButton.Right)
            {
                if (sender is UIE_TextElement)
                {
                    UIE_TextElement utex = (UIE_TextElement)sender;

                    MainWindowCanvas.Children.Remove(utex);
                }

                else if (sender is UIE_ImageElement)
                {
                    UIE_ImageElement utex = (UIE_ImageElement)sender;

                    MainWindowCanvas.Children.Remove(utex);
                }

                else if (sender is YRS_ColorFeature)
                {
                    YRS_ColorFeature utex = (YRS_ColorFeature)sender;

                    MainWindowCanvas.Children.Remove(utex);
                }

                GC.Collect(0);
            }

            if (e.ChangedButton == MouseButton.Left)
            {
                if (sender is UIE_TextElement)
                {
                    UIE_TextElement utex = (UIE_TextElement)sender;
                    if (utex.textbox.IsEnabled)
                    {
                        utex.textbox.IsEnabled = false;
                        utex.checkbox.IsChecked = false;
                    }
                    else
                    {
                        utex.textbox.IsEnabled = true;
                        utex.checkbox.IsChecked = true;
                    }

                    rotateUIE_TextElement(utex);
                    setColorOnUIE_TextElement(utex);
                    setZindexOn_UIE_Textelement(utex);
                }

                if (sender is UIE_ImageElement)
                {
                    UIE_ImageElement utex = (UIE_ImageElement)sender;

                    // process uie_imageelement method name

                    //utex.enableTextBox();
                    //rotateUIE_TextElement(utex);
                    setColorOnUIE_ImageElement(utex);
                    //setZindexOn_UIE_Textelement(utex);

                    e.Handled = false;
                }

                else if (sender is YRS_ColorFeature)
                {
                    YRS_ColorFeature utex = (YRS_ColorFeature)sender;

                    RotateTransform rt = new RotateTransform();
                    rt.Angle = elementAngle;

                    utex.RenderTransform = rt;

                    utex.Background = new SolidColorBrush(yrs_color_feature.getColor);

                    Panel.SetZIndex(utex, elementZindex);
                }

                e.Handled = true;
            }
        }

        private void utex_MouseMove(object sender, MouseEventArgs e)
        {
            // if dragging, then adjust rectangle position based on mouse movement
            if (drag_canvas)
            {
                if (sender is UIE_TextElement)
                {
                    UIE_TextElement utex = sender as UIE_TextElement;
                    Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                    double left = Canvas.GetLeft(utex);
                    double top = Canvas.GetTop(utex);
                    Canvas.SetLeft(utex, left + (newPoint.X - startPoint_mycanvas.X));
                    Canvas.SetTop(utex, top + (newPoint.Y - startPoint_mycanvas.Y));

                    startPoint_mycanvas = newPoint;

                }

                else if (sender is UIE_ImageElement)
                {
                    UIE_ImageElement utex = sender as UIE_ImageElement;
                    Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                    double left = Canvas.GetLeft(utex);
                    double top = Canvas.GetTop(utex);
                    Canvas.SetLeft(utex, left + (newPoint.X - startPoint_mycanvas.X));
                    Canvas.SetTop(utex, top + (newPoint.Y - startPoint_mycanvas.Y));

                    startPoint_mycanvas = newPoint;
                }

                else if (sender is YRS_ColorFeature)
                {
                    YRS_ColorFeature utex = sender as YRS_ColorFeature;
                    Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                    double left = Canvas.GetLeft(utex);
                    double top = Canvas.GetTop(utex);
                    Canvas.SetLeft(utex, left + (newPoint.X - startPoint_menuElements.X));
                    Canvas.SetTop(utex, top + (newPoint.Y - startPoint_menuElements.Y));

                    startPoint_menuElements = newPoint;
                }
            }
        }

        private void utex_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Middle)
            {
                if (sender is UIE_TextElement)
                {
                    UIE_TextElement utex = (UIE_TextElement)sender;

                    disableDragState();

                    Panel.SetZIndex(utex, elementZindex);
                }
                else if (sender is UIE_ImageElement)
                {
                    UIE_ImageElement utex = (UIE_ImageElement)sender;

                    disableDragState();

                    Panel.SetZIndex(utex, elementZindex);
                }

                else if (sender is YRS_ColorFeature)
                {
                    YRS_ColorFeature utex = (YRS_ColorFeature)sender;

                    disableDragState();

                    Panel.SetZIndex(utex, elementZindex);
                }

            }
        }
        #endregion MainwindowCanvas control events

        // main window events
        #region main window events
        private void ButtonMap_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            mainWindow_Shutdown_processing();

            GC.Collect();
        }
        private void ButtonMap_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.M)
            {
                MainWindowCanvas.Children.Add(modul_MainWindowMenuElement());
            }


            if (e.Key == Key.B)
            {
                if (rb_linearBrush.IsChecked == true)
                {
                    MainWindowCanvas.Background = linearGradientOrientation_processing();
                }
                else if (rb_solidBrush.IsChecked == true)
                {
                    MainWindowCanvas.Background = new SolidColorBrush(yrs_color_feature.getColor);
                }

                e.Handled = false;
            }


            if (e.Key == Key.F2)
            {
                config.saveScetchboardPictureToPNG(MainWindowCanvas);
            }

            if (e.Key == Key.F3)
            {
                // explosives Canvas mit zwei Sprungwerten per F3?
                if (yrs_color_feature.Visibility == Visibility.Collapsed)
                {
                    wrpMenu.Visibility = Visibility.Visible;
                    wrpRadioButtons.Visibility = Visibility.Visible;
                    wrpTextBoxes.Visibility = Visibility.Visible;
                    //wrp_colorpicker.Visibility = Visibility.Visible;

                    foreach (UIE_MainWindowMenuElement mwme in listOfMenuElements)
                    {
                        mwme.Visibility = Visibility.Visible;
                    }


                }
                else if (yrs_color_feature.Visibility == Visibility.Visible)
                {

                    wrpMenu.Visibility = Visibility.Collapsed;
                    wrpRadioButtons.Visibility = Visibility.Collapsed;
                    wrpTextBoxes.Visibility = Visibility.Collapsed;
                    //wrp_colorpicker.Visibility = Visibility.Collapsed;

                    foreach (UIE_MainWindowMenuElement mwme in listOfMenuElements)
                    {
                        mwme.Visibility = Visibility.Hidden;
                    }


                }

                e.Handled = false;
            }

                        
            if (e.Key == Key.H)
            {
                if (h_pressed == true)
                {
                    foreach (UIE_MainWindowMenuElement module in listOfMenuElements)
                    {
                        module.Visibility = Visibility.Hidden;
                    }
                }
                else if (h_pressed == false)
                {
                    foreach (UIE_MainWindowMenuElement module in listOfMenuElements)
                    {
                        module.Visibility = Visibility.Visible;
                    }
                }

                e.Handled = false;
            }

            if (e.Key == Key.S)
            {
                e.Handled = false;

                if (x_pressed == true || y_pressed == true)
                {
                    x_pressed = false;
                    y_pressed = false;
                }
            }


            if (e.Key == Key.X)
            {
                //drawSimpleRectangle();
                e.Handled = false;

                if (s_pressed == true || y_pressed == true)
                {
                    s_pressed = false;
                    y_pressed = false;
                }
            }


            if (e.Key == Key.Y)
            {
                //drawSimpleRectangle();
                e.Handled = false;

                if (s_pressed == true || x_pressed == true)
                {
                    s_pressed = false;
                    x_pressed = false;
                }
            }


        }
        private void ButtonMap_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.B)
            {
                e.Handled = true;
            }

            if (e.Key == Key.H)
            {
                if (h_pressed == true)
                {
                    //lbl_colorFeatureVisibilityStatus.Content = "Mode: 'key h pressed ' hide color feature";

                    h_pressed = false;

                    lbl_colorFeatureVisibilityStatus.Content = "no key mode active";
                }
                else if (h_pressed == false)
                {

                    //lbl_colorFeatureVisibilityStatus.Content = "no key mode active";

                    h_pressed = true;

                    lbl_colorFeatureVisibilityStatus.Content = "Mode: 'key h pressed ' hide color feature";
                }

                e.Handled = true;
            }

            if (e.Key == Key.M)
            {
                e.Handled = true;
            }

            if (e.Key == Key.S)
            {
                if (s_pressed == true)
                {
                    s_pressed = false;

                    lbl_activeMode.Content = "Mode: 'key s pressed ' draw free hand scetch line";
                }
                else if (s_pressed == false)
                {
                    lbl_colorFeatureVisibilityStatus.Content = "no key mode active";

                    s_pressed = true;

                    //lbl_activeMode.Content = "Mode: 'key s pressed ' draw free hand scetch line";
                }

                e.Handled = true;
            }

            if (e.Key == Key.X)
            {
                if (x_pressed == true)
                {
                    x_pressed = false;


                    lbl_activeMode.Content = "no key mode active";
                }
                else if (x_pressed == false)
                {
                    x_pressed = true;

                    lbl_activeMode.Content = "Mode: 'key x pressed ' draw free hand rectangle shapes";
                }

                e.Handled = true;
            }

            if (e.Key == Key.Y)
            {
                if (y_pressed == true)
                {
                    y_pressed = false;

                    lbl_activeMode.Content = "no key mode active";
                }
                else if (y_pressed == false)
                {
                    y_pressed = true;

                    lbl_activeMode.Content = "Mode: 'key y pressed ' -> draw free hand ellipse shapes";
                }

                e.Handled = true;
            }

        }
        private void ButtonMap_Loaded(object sender, RoutedEventArgs e)
        {
            config = new ConfigData();
            config.loadConfig();

            canvasRessources();

            drawYRS_ColorFeature();

            loadMenuButtons();

            canvasDesign();

            MainWindowCanvas.Children.Add(modul_ScetchboardElement());
            MainWindowCanvas.Children.Add(modul_SelectionBindingElement());
            MainWindowCanvas.Children.Add(modul_MainWindowMenuElement());
            MainWindowCanvas.Children.Add(modul_TimerElement());

            loaded = true;

            GC.Collect(0);
        }
        private void ButtonMap_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                ButtonMap.DragMove();
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                string question = texts.quitQuestion().ToString();
                string title = texts.quitTitle().ToString();

                MessageBoxResult result = MessageBox.Show(question, title, MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (result == MessageBoxResult.Yes)
                {
                    mainWindow_Shutdown_processing();
                }
            }
        }
        private void ButtonMap_MouseMove(object sender, MouseEventArgs e)
        {

        }
        private void ButtonMap_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                disableDragState();

                s_pressed = false;
                x_pressed = false;
                y_pressed = false;
            }

            if (e.ChangedButton == MouseButton.Right)
            {

            }

            e.Handled = true;
        }
        #endregion main window events


        #region radiobutton events

        // on radiobuttons
        private void rb_linearBrush_Checked(object sender, RoutedEventArgs e)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                rb_orientationBottom.IsEnabled = true;

                rb_orientationTop.IsEnabled = true;
                rb_orientationTop.IsChecked = true;

                rb_orientationLeft.IsEnabled = true;

                rb_orientationRight.IsEnabled = true;
            }
        }

        private void rb_solidBrush_Checked(object sender, RoutedEventArgs e)
        {
            if (rb_solidBrush.IsChecked == true)
            {
                rb_orientationBottom.IsEnabled = false;
                rb_orientationBottom.IsChecked = false;

                rb_orientationTop.IsEnabled = false;
                rb_orientationTop.IsChecked = false;

                rb_orientationLeft.IsEnabled = false;
                rb_orientationLeft.IsChecked = false;

                rb_orientationRight.IsEnabled = false;
                rb_orientationRight.IsChecked = false;
            }
        }
        #endregion radiobutton events
    }
}
/* YourStartUp buttonmap tool  
 * 
 * End of File
 */