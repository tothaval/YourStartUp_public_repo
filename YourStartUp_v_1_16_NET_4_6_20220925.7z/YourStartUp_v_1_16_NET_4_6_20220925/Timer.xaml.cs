﻿/* YourStartUp timer tool  
 * 
 * Pur:         displays time, offers a stopwatch function
 * Toc:         2022 (may <> september)
 * Dev:         Stephan Kammel
* E-Mail:      kammel@posteo.de
 */

using Microsoft.Win32;

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für Timer.xaml
    /// </summary>
    public partial class Timer : Window
    {
        private ConfigData config = new ConfigData();

        private TimerTexts timer = new TimerTexts();

        private YRS_Time_Jobs tj = new YRS_Time_Jobs();

        private System.Windows.Threading.DispatcherTimer _timer = new System.Windows.Threading.DispatcherTimer();

        private bool breakState = false;

        private int counter;        

        private string breakDurationString;

        // constructor(s)
        public Timer()
        {
            InitializeComponent();
            _timer.Tick += _timer_Tick;
            _timer.Interval = TimeSpan.FromSeconds(0.28);
            _timer.Start();

            tj.start_stopwatch();        
        }

        // methods private
        #region methods private A-L
        private void addConfiguratedUIElements()
        {
            tbDate.FontFamily = config.font;
            tbDate.FontSize = 12;
            tbDate.Background = config.backColor;
            tbDate.Foreground = config.foreColor;
            tbDate.HorizontalAlignment = HorizontalAlignment.Center;
            tbLastBreak.VerticalAlignment = VerticalAlignment.Center;
            tbDate.TextAlignment = TextAlignment.Center;
            tbDate.Padding = new Thickness(5, 10, 5, 0);
            tbDate.ToolTip = timer.tbDate_toolTip();

            border.CornerRadius = new CornerRadius(config.borderRadius);
            border.BorderThickness = new Thickness(3);
            border.BorderBrush = config.foreColor;
            border.Background = config.backColor;

            tbLastBreak.FontSize = config.fontSize * 3;
            tbLastBreak.VerticalAlignment = VerticalAlignment.Center;
            tbLastBreak.ToolTip = timer.tbLastBreak_tooltip();

            tbLastBreak.TextAlignment = TextAlignment.Center;
            tbLastBreak.Padding = new Thickness(5, 0, 5, 0);

            tbSinceStart.FontSize = config.fontSize * 3;
            tbSinceStart.VerticalAlignment = VerticalAlignment.Center;
            tbSinceStart.ToolTip = timer.tbSinceStart_tooltip();
            tbSinceStart.TextAlignment = TextAlignment.Center;
            tbSinceStart.Padding = new Thickness(5, 0, 5, 0);

            tbTimer.FontSize = config.fontSize * 3;
            tbTimer.VerticalAlignment = VerticalAlignment.Center;
            tbTimer.ToolTip = timer.tbTimer_toolTip();
            tbTimer.TextAlignment = TextAlignment.Center;
            tbTimer.Padding = new Thickness(5, 0, 5, 0);

            btnTakeABreak.FontSize = config.fontSize;
            btnTakeABreak.ToolTip = timer.btnTakeABreak_toolTip();
            btnTakeABreak.Content = timer.btnTakeABreak_content();

            btnMinimize.FontSize = config.fontSize;
            btnMinimize.ToolTip = timer.btnMinimize_toolTip();
            btnMinimize.Content = timer.btnMinimize_content();
        }

        private void addRessources()
        {
            this.DataContext = this;

            yrs_timer.Resources.Add("backgroundColors", config.btnBackColor);
            yrs_timer.Resources.Add("borderRadius", new CornerRadius(config.borderRadius));
            yrs_timer.Resources.Add("buttonHeight", Convert.ToDouble(config.btnHeight));
            yrs_timer.Resources.Add("foregroundColors", config.btnForeColor);

            yrs_timer.Resources.Add("highlight", config.highlightColor);

            yrs_timer.Resources.Add("breakButtonColor", config.renameState);
            yrs_timer.Resources.Add("breakButtonFont", config.renameStateFont);
        }

        private void loadUIConfig()
        {
            addRessources();

            yrs_timer.FontFamily = config.font;
            yrs_timer.FontSize = config.fontSize;
            yrs_timer.Height = 4 * config.btnHeight + 75;
            yrs_timer.MinHeight = 4 * config.btnHeight + 75;
            yrs_timer.Width = config.btnWidth + 75;
            yrs_timer.MinWidth = config.btnWidth + 75;

            Background = new SolidColorBrush(Colors.Transparent);
            Foreground = config.foreColor;

            addConfiguratedUIElements();

            wrpTimeLog.Orientation = Orientation.Vertical;
        }

        private void sessionSwitchOff()
        {
            SystemEvents.SessionSwitch -= SystemEvents_SessionSwitch;
        }

        private void sessionSwitchOn() // name anders, code zum checken ob der bildschirm gesperrt ist.
        {
            SystemEvents.SessionSwitch += SystemEvents_SessionSwitch;
            /* Do something you need to do, block thread, or do a quick check
             * just be sure to unregister when you are done.
             */
            //SystemEvents.SessionSwitch -= SystemEvents_SessionSwitch;
        }

        private TextBlock timeCalculation()
        {
            TextBlock tb = new TextBlock();

            tb.TextAlignment = TextAlignment.Center;
            tb.FontFamily = config.font;
            tb.FontSize = 12;
            tb.Margin = new Thickness(5, 2, 5, 0);
            tb.Padding = new Thickness(5, 0, 5, 0);

            if (breakState == true)
            {
                counter++;
                tj.reset_break_stopwatch();
                tj.start_break_stopwatch();
                tb.Text = $"#{counter}\n{tbTimer.Text} ::: {tbSinceStart.Text} ::: {tbLastBreak.Text}";

                tb.Foreground = config.btnForeColor;

                tb.ToolTip = timer.breakStateTrue_toolTip();
                counter--;
            }
            else
            {
                tj.stop_break_stopwatch();
                calculateBreakDuration();
                tb.Text = $"{breakDurationString} ::: {tbSinceStart.Text} ::: {tbTimer.Text}\n";

                tb.Foreground = config.renameStateFont;

                tb.ToolTip = timer.breakStateFalse_toolTip();
                counter++;
            }
            return tb;
        }

        private TextBlock timeLog()
        {
            if (counter > 9)
            {
                wrpTimeLog.Children.Clear();
                counter = 0;
            }

            return timeCalculation();
        }

        private void calculateBreak()
        {
            if (breakState == false)
            {                
                tbLastBreak.Text = tj.get_stopwatch_time().ToString();
            }
        }

        private void calculateBreakDuration()
        {            
            breakDurationString = tj.get_break_time().ToString();
        }


        private void calculateTimerRuntime()
        {           
            tbSinceStart.Text = tj.get_active_time().ToString();

            tbDate.Text = config.dateString();

        }

        private void handleBreak()
        {
            calculateBreak();

            processBreakButtonAction();
        }
        #endregion methods private A-L

        #region methods private M-Z
        private void processBreakButtonAction()
        {
            if (breakState == false)
            {
                breakState = true;
                btnTakeABreak.Background = config.btnBackColor;
                btnTakeABreak.Foreground = config.renameStateFont;
                btnTakeABreak.Content = timer.endBreak_content();

                tj.stop_stopwatch();
            }
            else
            {
                tj.restart_stopwatch();
                breakState = false;

                btnTakeABreak.Background = config.renameState;
                btnTakeABreak.Foreground = config.renameStateFont;
                btnTakeABreak.Content = timer.btnTakeABreak_content();
            }
        }
        #endregion methods private M-Z

        // events private

        // button events
        #region button events
        private void btnMinimize_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void btnTakeABreak_Click(object sender, RoutedEventArgs e)
        {
            handleBreak();
            wrpTimeLog.Children.Add(timeLog());
            wrpTimeLog.HorizontalAlignment = HorizontalAlignment.Center;
        }
        #endregion button events

        public void SystemEvents_SessionSwitch(object sender, SessionSwitchEventArgs e)
        {
            if (e.Reason == SessionSwitchReason.SessionLock)
            {
                handleBreak();
                wrpTimeLog.Children.Add(timeLog());
                wrpTimeLog.HorizontalAlignment = HorizontalAlignment.Center;
            }

            else if (e.Reason == SessionSwitchReason.SessionUnlock)
            {
                handleBreak();
                wrpTimeLog.Children.Add(timeLog());
                wrpTimeLog.HorizontalAlignment = HorizontalAlignment.Center;
            }
        }

        private void _timer_Tick(object sender, EventArgs e)
        {   
            tbTimer.Text = tj.get_time_string().ToString();

            //tbTimer.Text = DateTime.Now.ToLongTimeString();
            calculateBreak();
            calculateTimerRuntime();

            GC.Collect(0);
        }

        // timer window events
        #region timer window events
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            loadUIConfig();
            calculateBreak();
            calculateTimerRuntime();
            tbTimer.Text = DateTime.Now.ToLongTimeString();

            sessionSwitchOn();

            yrs_timer.Topmost = config.chxTimerTopmost;
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
            if (e.ChangedButton == MouseButton.Right)
            {
                this.Close();
            }
        }
        private void yrs_timer_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            tj.stop_active_time();

            sessionSwitchOff();

            GC.Collect(0);
        }
        #endregion timer window events
    }
}
/* YourStartUp timer tool  
 * 
 * End of File
 */

