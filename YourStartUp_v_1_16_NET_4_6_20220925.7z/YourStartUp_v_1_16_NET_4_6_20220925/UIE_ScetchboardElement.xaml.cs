﻿/* YourStartUp UserInterfaceElement Scetchboard
 * 
 * Pur:         drawing,...
 * Int:         mind map,...
 * Toc:         2022 (september <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      kammel@posteo.de
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für UIE_ScetchboardElement.xaml
    /// </summary>
    public partial class UIE_ScetchboardElement : UserControl
    {
        public int checkCount = 0;

        Color color_1;
        Color color_2;

        Canvas_BasicGeometry geom = new Canvas_BasicGeometry();
        Canvas_ColorChoice ccc = new Canvas_ColorChoice();
        Canvas_UIConfig uic = new Canvas_UIConfig();

        ScetchboardTexts scetchboard = new ScetchboardTexts();

        YRS_ColorFeature yrs_color_feature = new YRS_ColorFeature();

        // invoked classes
        private ConfigData config = new ConfigData();


        // drawn objects drag state
        private bool drag = false;
        private bool drag_canvas = false;
        private bool drag_menuElements = false;
        private bool drag_ellp = false;
        private bool drag_line = false;
        private bool drag_triangle = false;

        private bool dragging;
        private bool dragState = false;

        // success of textbox parsing
        private bool parseFail = false;

        // drawn objects dimensions, angle, z-index, cascade count and psbly text
        int cascadeAmount = 5;
        int elementHeight = 50;
        int elementWidth = 100;
        int elementZindex = 0;

        double elementAngle = 0;

        StringBuilder elementText = new StringBuilder();

        // ui dimensions
        double color_feature_height = 0;

        // naming counters for drag drawing 
        private long dragEllipseID = 0;
        private long dragRectangleID = 0;
        // private long dragTriangleID = 0;

        private long drawEllipseID = 0;
        private long drawImageElement = 0;
        private long drawLineID = 0;
        private long drawRectangleID = 0;
        private long drawTriangleID = 0;
        private long drawTextElement = 0;

        // key states for drawing (s free hand, x rectangles, y ellipses)
        private bool d_pressed = false;
        private bool h_pressed = false;

        private bool s_pressed = false;
        private bool x_pressed = false;
        private bool y_pressed = false;

        // drawn objects moving positions
        private Point scetchPoint = new Point();

        private Point clickV;

        private Point startPoint;
        private Point startPoint_menuElements;
        private Point startPoint_mycanvas;

        private Point startPoint_dragEllipse;
        private Point startPoint_dragRectangle;

        private Point startPoint_ellp;

        // geometry
        private Ellipse dragEllipse;
        private Rectangle dragRectangle;
        private Shape selectedShape;

        // constructor
        public UIE_ScetchboardElement()
        {
            InitializeComponent();
        }

        // methods
        // publics
        public void colorChoiceFunction()
        {
            checkCount = 0;

            List<UIE_CheckboxCanvasButton> ccbLST = new List<UIE_CheckboxCanvasButton>();

            foreach (UIE_CheckboxCanvasButton item in yrs_color_feature.stkpnl_colorChoice.Children)
            {
                ccbLST.Add(item);
            }

            foreach (UIE_CheckboxCanvasButton ccb in ccbLST)
            {
                if (ccb.uie_chx_choice_confirmer.IsChecked == true)
                {
                    //MessageBox.Show($"{plemplem.Name}\n{plemplem.uie_chx_choice_confirmer.Name}");

                    SolidColorBrush brush = (SolidColorBrush)ccb.uie_ckbcnvbtn_button.Background;

                    if (checkCount == 0)
                    {
                        color_1 = brush.Color;
                    }
                    else if (checkCount == 1)
                    {
                        color_2 = brush.Color;
                    }

                    checkCount++;
                }
            }

            if (checkCount > 2)
            {
                MessageBox.Show("only two colors can be processed.");
            }
        }



        #region private methods

        //private void canvasDesign()
        //{
        //    ScetchboardElement.Background = new SolidColorBrush(Colors.Transparent);

        //    border.Background = config.canvasMenuColor;
        //    border.BorderBrush = config.foreColor;
        //    border.BorderThickness = new Thickness(3);
        //    border.CornerRadius = new CornerRadius(config.borderRadius);
            


        //}

        public void canvasLoad()
        {            
            canvasRessources();

            drawYRS_ColorFeature();

            loadMenuButtons();

            color_1 = config.btnBackColor.Color;
            color_2 = config.btnForeColor.Color;

            //canvasDesign();

            foreach (TextBox tb in wrpTextBoxes.Children)
            {
                tb.Background = config.textBox;
                tb.Foreground = config.textBoxFont;
            }

            border.Background = config.backColor;
            border.BorderBrush = config.foreColor;
            border.BorderThickness = new Thickness(3);

            canvas.Background = config.canvasColor;
            canvas_border.BorderBrush = config.canvasMenuColor;
            canvas_border.BorderThickness = new Thickness(3);

            wrpMenu.Background = config.canvasMenuColor;
            wrpRadioButtons.Background = config.canvasMenuColor;
            wrpTextBoxes.Background = config.canvasMenuColor;            

            //color_feature_height = uie_color_feature.ActualHeight;

            rb_solidBrush.IsChecked = true;

            //rb_linearBrush.IsChecked = true;
            //rb_orientationBottom.IsChecked = true;
        }

        private void canvasRessources()
        {
            //config.loadConfig();

            ScetchboardElement.Resources.Remove("buttonColor");
            ScetchboardElement.Resources.Remove("buttonFont");
            ScetchboardElement.Resources.Remove("highlight");
            ScetchboardElement.Resources.Remove("radius");

            ScetchboardElement.Resources.Add("buttonColor", config.btnBackColor);
            ScetchboardElement.Resources.Add("buttonFont", config.btnForeColor);
            ScetchboardElement.Resources.Add("highlight", config.highlightColor);
            ScetchboardElement.Resources.Add("radius", new CornerRadius(config.borderRadius));
        }


        private void check_rbGroup_LinearGradientOrientation(Shape _shape)
        {
            colorChoiceFunction();

            if (rb_orientationBottom.IsChecked == true)
            {
                _shape.Fill = new LinearGradientBrush(
                    color_1,
                    color_2,
                    90);
            }
            else if (rb_orientationTop.IsChecked == true)
            {
                _shape.Fill = new LinearGradientBrush(
                    color_2,
                    color_1,
                    90);
            }
            else if (rb_orientationLeft.IsChecked == true)
            {
                _shape.Fill = new LinearGradientBrush(
                    color_1,
                    color_2,
                    0
                    );
            }
            else if (rb_orientationRight.IsChecked == true)
            {
                _shape.Fill = new LinearGradientBrush(
                    color_2,
                    color_1,
                    0
                    );
            }
        }

        private void check_rbGroup_LinearGradientOrientation_UIE_TextElement(UIE_TextElement uiet)
        {
            colorChoiceFunction();

            if (rb_orientationBottom.IsChecked == true)
            {
                uiet.border.Background = new LinearGradientBrush(
                    color_1,
                    color_2,
                    90);
                uiet.textbox.Foreground = new LinearGradientBrush(
                    color_2,
                    color_1,
                    90);
            }
            else if (rb_orientationTop.IsChecked == true)
            {
                uiet.border.Background = new LinearGradientBrush(
                    color_2,
                    color_1,
                    90);
                uiet.textbox.Foreground = new LinearGradientBrush(
                    color_1,
                    color_2,
                    90);
            }
            else if (rb_orientationLeft.IsChecked == true)
            {
                uiet.border.Background = new LinearGradientBrush(
                    color_1,
                    color_2,
                    0
                    );
                uiet.textbox.Foreground = new LinearGradientBrush(
                    color_2,
                    color_1,
                    90);
            }
            else if (rb_orientationRight.IsChecked == true)
            {
                uiet.border.Background = new LinearGradientBrush(
                    color_2,
                    color_1,
                    0
                    );
                uiet.textbox.Foreground = new LinearGradientBrush(
                    color_1,
                    color_2,
                    90);
            }
        }

        private void determineColorScheme(Shape _shape)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                check_rbGroup_LinearGradientOrientation(_shape);
            }
            else if (rb_solidBrush.IsChecked == true)
            {
                solidColorFill(_shape);
            }

            _shape.StrokeThickness = uic.borderThickness;
        }

        private void determineColorScheme_UIE_TextElement(UIE_TextElement uiet)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                check_rbGroup_LinearGradientOrientation_UIE_TextElement(uiet);
            }
            else if (rb_solidBrush.IsChecked == true)
            {
                solidColorFill_UIE_Textelement(uiet);
            }
        }

        private void disableDragState()
        {
            drag = false;
            drag_canvas = false;
            drag_menuElements = false;
            drag_ellp = false;
            drag_line = false;
            drag_triangle = false;

            dragging = false;
        }


        // draw stuff
        #region drawing
        #region cascades
        private void drawCascade_Ellipses()
        {
            parseTextboxes();

            for (int i = 0; i < cascadeAmount; i++)
            {
                Ellipse cell = drawSimpleEllipse();

                drawShape(cell, i);
            }
        }

        private void drawCascade_Rectangles()
        {
            parseTextboxes();

            for (int i = 0; i < cascadeAmount; i++)
            {
                Rectangle crec = drawSimpleRectangle();

                drawShape(crec, i);
            }
        }

        private void drawCascade_Triangles()
        {
            parseTextboxes();

            for (int i = 0; i < cascadeAmount; i++)
            {
                // Polygon tria = drawSimpleTriangle();

                Polygon tria = drawSimpleTriangle_rectangular();

                drawShape(tria, i);
            }
        }
        #endregion cascades



        private void drawShape(Shape shape, int counter = 1)
        {
            determineColorScheme(shape);

            Canvas.SetLeft(shape, 50 * counter);
            Canvas.SetTop(shape, 25 * counter);

            Panel.SetZIndex(shape, elementZindex);
        }


        #region simple geometry
        private Ellipse drawSimpleEllipse()
        {
            // ccb button mit text border/oder symbol zum speichern der farbe für den rand,)

            parseTextboxes();

            Ellipse ell = geom.drawSimpleEllipse(elementWidth, elementHeight);

            ell.Name = $"ellipse{drawEllipseID}";

            //ell.StrokeDashArray = new DoubleCollection() { 2 };

            drawEllipseID++;

            drawShape(ell);

            rotateShape(ell);

            ell.MouseDown += Ell_MouseDown;
            ell.MouseMove += Ell_MouseMove;
            ell.MouseUp += Ell_MouseUp;

            canvas.Children.Add(ell);

            return ell;
        }

        private Polygon drawSimpleLine()
        {
            parseTextboxes();

            Polygon lin = geom.drawSimpleLine(elementWidth, elementHeight);

            lin.Name = $"ellipse{drawLineID}";

            drawLineID++;

            drawShape(lin);

            rotateShape(lin);

            lin.MouseDown += pygon_MouseDown;
            lin.MouseMove += pygon_MouseMove;
            lin.MouseUp += pygon_MouseUp;

            canvas.Children.Add(lin);

            return lin;
        }

        private Rectangle drawSimpleRectangle()
        {
            parseTextboxes();

            Rectangle rec = geom.drawSimpleRectangle(elementWidth, elementHeight);

            rec.Name = $"ellipse{drawRectangleID}";

            //rec.StrokeDashArray = new DoubleCollection() { 2 };

            drawRectangleID++;

            drawShape(rec);

            rotateShape(rec);

            rec.MouseDown += Rectangle_MouseDown;
            rec.MouseMove += Rectangle_MouseMove;
            rec.MouseUp += Rectangle_MouseUp;

            canvas.Children.Add(rec);

            return rec;
        }

        private Polygon drawSimpleTriangle_equilateral()
        {
            parseTextboxes();

            Polygon tri_equ;

            if (elementAngle == 0 && (elementHeight < 0 || elementWidth < 0))
            {
                tri_equ = geom.drawSimpleTriangle_equilateral(elementWidth, elementHeight);

                tri_equ.Name = $"ellipse{drawTriangleID}";

                drawShape(tri_equ);
            }
            else if (elementAngle != 0 && (elementHeight < 0 || elementWidth < 0))
            {
                tri_equ = geom.drawSimpleTriangle_equilateral(
                    geom.avoidNegativity(elementWidth), geom.avoidNegativity(elementHeight)
                    );

                tri_equ.Name = $"ellipse{drawTriangleID}";

                drawShape(tri_equ);
                rotateShape(tri_equ);
            }
            else
            {
                tri_equ = geom.drawSimpleTriangle_equilateral(elementWidth, elementHeight);

                tri_equ.Name = $"ellipse{drawTriangleID}";

                drawShape(tri_equ);
                rotateShape(tri_equ);
            }

            drawTriangleID++;

            tri_equ.MouseDown += pygon_MouseDown;
            tri_equ.MouseMove += pygon_MouseMove;
            tri_equ.MouseUp += pygon_MouseUp;

            canvas.Children.Add(tri_equ);

            return tri_equ;
        }

        private Polygon drawSimpleTriangle_isosceles()
        {
            parseTextboxes();

            Polygon tri_iso;

            if (elementAngle == 0 && (elementHeight < 0 || elementWidth < 0))
            {
                tri_iso = geom.drawSimpleTriangle_isosceles(elementWidth, elementHeight);

                tri_iso.Name = $"ellipse{drawTriangleID}";

                drawShape(tri_iso);
            }
            else if (elementAngle != 0 && (elementHeight < 0 || elementWidth < 0))
            {
                tri_iso = geom.drawSimpleTriangle_isosceles(
                    geom.avoidNegativity(elementWidth), geom.avoidNegativity(elementHeight)
                    );

                tri_iso.Name = $"ellipse{drawTriangleID}";

                drawShape(tri_iso);
                rotateShape(tri_iso);
            }
            else
            {
                tri_iso = geom.drawSimpleTriangle_isosceles(elementWidth, elementHeight);

                tri_iso.Name = $"ellipse{drawTriangleID}";

                drawShape(tri_iso);
                rotateShape(tri_iso);
            }

            drawTriangleID++;

            tri_iso.MouseDown += pygon_MouseDown;
            tri_iso.MouseMove += pygon_MouseMove;
            tri_iso.MouseUp += pygon_MouseUp;

            canvas.Children.Add(tri_iso);

            return tri_iso;
        }

        private Polygon drawSimpleTriangle_rectangular()
        {
            parseTextboxes();

            Polygon tri;

            if (elementAngle == 0 && (elementHeight < 0 || elementWidth < 0))
            {
                tri = geom.drawSimpleTriangle_rectangular(elementWidth, elementHeight);

                tri.Name = $"ellipse{drawTriangleID}";

                drawShape(tri);
            }
            else if (elementAngle != 0 && (elementHeight < 0 || elementWidth < 0))
            {
                tri = geom.drawSimpleTriangle_rectangular(geom.avoidNegativity(elementWidth), geom.avoidNegativity(elementHeight));

                tri.Name = $"ellipse{drawTriangleID}";

                drawShape(tri);
                rotateShape(tri);
            }
            else
            {
                tri = geom.drawSimpleTriangle_rectangular(elementWidth, elementHeight);

                tri.Name = $"ellipse{drawTriangleID}";

                drawShape(tri);
                rotateShape(tri);
            }

            drawTriangleID++;

            tri.MouseDown += pygon_MouseDown;
            tri.MouseMove += pygon_MouseMove;
            tri.MouseUp += pygon_MouseUp;

            canvas.Children.Add(tri);

            return tri;
        }
        #endregion simple geometry

        public UIE_ImageElement drawUIE_ImageElement(ImageBrush ib_)
        {
            parseTextboxes();

            UIE_ImageElement uimg = new UIE_ImageElement(elementWidth, elementHeight);

            uimg.Name = $"uimg{drawImageElement}";
            drawImageElement++;

            uimg.border.BorderBrush = new SolidColorBrush(color_2);
            uimg.border.BorderThickness = new Thickness(2);
            uimg.border.CornerRadius = new CornerRadius(3);
            uimg.canvas.Background = ib_;

            //rotateUIE_TextElement(uimg);
            //determineColorScheme_UIE_TextElement(uimg);

            uimg.MouseDown += utex_MouseDown;
            uimg.MouseMove += utex_MouseMove;
            uimg.MouseUp += utex_MouseUp;

            return uimg;
        }



        private UIE_TextElement drawUIE_TextElement()
        {
            parseTextboxes();

            UIE_TextElement utex = new UIE_TextElement();

            utex.Name = $"utex{drawTextElement}";
            drawTextElement++;

            utex.border.BorderBrush = new SolidColorBrush(color_2);
            utex.border.BorderThickness = new Thickness(2);

            utex.border.Height = elementHeight;
            utex.border.Width = elementWidth;

            utex.border.CornerRadius = new CornerRadius(3);

            rotateUIE_TextElement(utex);
            determineColorScheme_UIE_TextElement(utex);

            //lt.Stroke = new SolidColorBrush(Colors.Black);
            //lt.StrokeThickness = 15;

            Canvas.SetLeft(utex, 250);
            Canvas.SetTop(utex, 250);
            Panel.SetZIndex(utex, elementZindex);

            //drawTriangleID++;

            utex.MouseDown += utex_MouseDown;
            utex.MouseMove += utex_MouseMove;
            utex.MouseUp += utex_MouseUp;

            canvas.Children.Add(utex);

            return utex;
        }

        private YRS_ColorFeature drawYRS_ColorFeature()
        {
            //parseTextboxes();

            RotateTransform rt = new RotateTransform();
            rt.Angle = elementAngle;

            yrs_color_feature.RenderTransform = rt;

            //lt.Stroke = new SolidColorBrush(Colors.Black);
            //lt.StrokeThickness = 15;

            yrs_color_feature.border.Background = config.backColor;
            yrs_color_feature.border.BorderBrush = config.foreColor;
            yrs_color_feature.border.BorderThickness = new Thickness(3);

            Canvas.SetLeft(yrs_color_feature, 5);
            Canvas.SetBottom(yrs_color_feature, 5);
            Panel.SetZIndex(yrs_color_feature, 2005);

            //drawTriangleID++;

            yrs_color_feature.MouseDown += utex_MouseDown;
            yrs_color_feature.MouseMove += utex_MouseMove;
            yrs_color_feature.MouseUp += utex_MouseUp;

            wrp_colorpicker.Children.Add(yrs_color_feature);

            return yrs_color_feature;
        }
        #endregion drawing


        // load stuff
        #region loading

        private void load_A(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_A_Click;

            uie.changeIconTo_A();

            load_button_appearance(uie, style);
        }

        private void load_button_appearance(UIE_CascadeButton ui_element, Style _style)
        {
            ui_element.uie_cascade_button.Background = uic.transparent;

            ui_element.uie_cascade_button_border.CornerRadius = new CornerRadius(uic.cornerRadius);
            ui_element.uie_cascade_button_border.BorderThickness = new Thickness(uic.borderThickness);
            ui_element.uie_cascade_button_border.BorderBrush = uic.borderBrush;
            ui_element.uie_cascade_button_border.Background = uic.background;

            ui_element.uie_cascade_button.Style = _style;

            wrpMenu.Children.Add(ui_element);
        }

        private void load_rectangleButton(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_rectangle_button_Click;

            uie.changeIconTo_singularRectangle();

            load_button_appearance(uie, style);
        }

        private void load_rectangleCascade(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_cascade_button_Click;

            uie.changeIconTo_cascadingRectangles();

            load_button_appearance(uie, style);
        }

        private void load_ellipseButton(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_circle_button_Click;

            uie.changeIconTo_singularEllipse();

            load_button_appearance(uie, style);
        }

        private void load_ellipseCascade(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_cascade_ellipses_button_Click;

            uie.changeIconTo_cascadingEllipses();

            load_button_appearance(uie, style);
        }

        private void load_triangle_equilateral_Button(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_triangle_equilateral_button_Click;

            uie.changeIconTo_singularTriangle_equilateral();

            load_button_appearance(uie, style);
        }

        private void load_triangle_isosceles_Button(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_triangle_isosceles_button_Click;

            uie.changeIconTo_singularTriangle_isosceles();

            load_button_appearance(uie, style);
        }

        private void load_triangle_rectangular_Button(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_triangle_rectangular_button_Click;

            uie.changeIconTo_singularTriangle();

            load_button_appearance(uie, style);
        }

        private void load_triangleCascade(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_cascade_triangles_button_Click;

            uie.changeIconTo_cascadingTriangles();

            load_button_appearance(uie, style);
        }

        private void load_lineButton(Style style)
        {
            UIE_CascadeButton uie = new UIE_CascadeButton();

            uie.uie_cascade_button.Click += Uie_line_button_Click;

            uie.changeIconTo_Line();

            load_button_appearance(uie, style);
        }

        private void loadMenuButtons()
        {
            Style style = this.FindResource("buttonStyle") as Style;

            load_rectangleButton(style);
            load_rectangleCascade(style);

            load_ellipseButton(style);
            load_ellipseCascade(style);

            load_triangle_equilateral_Button(style);
            load_triangle_isosceles_Button(style);
            load_triangle_rectangular_Button(style);
            load_triangleCascade(style);

            load_lineButton(style);
            load_A(style);
            //load_TextElement(style);
        }
        #endregion loading


        // parse textbox contents into variables
        private void parseTextboxes()
        {
            string message = "";

            try
            {
                cascadeAmount = Int32.Parse(tbxAmount.Text);
                elementHeight = Int32.Parse(tbxHeight.Text);
                elementWidth = Int32.Parse(tbxWidth.Text);
                elementZindex = Int32.Parse(tbxZindex.Text);

                elementAngle = Double.Parse(tbxAngle.Text);

                elementText.Append(tbxItemText.Text);

                parseFail = false;
            }
            catch (Exception e)
            {
                parseFail = true;
                message = e.Message;
                
                if (parseFail == true)
                {
                    MessageBox.Show($"{message}{scetchboard.textbox_parseFail_exception()}");
                }
            }
        }

        // rotate element upon creation
        private void rotateShape(Shape shape)
        {
            if (parseFail == false)
            {                
                shape.Height = geom.avoidNegativity(elementHeight);
                shape.Width = geom.avoidNegativity(elementWidth);

                rotateShape(shape);                
            }
            else if (parseFail == true)
            {
                shape.Width = 100;
                shape.Height = 50;
            }
        }

        private void rotateUIE_TextElement(UIE_TextElement uiet)
        {
            if (parseFail == false)
            {                
                uiet.Height = geom.avoidNegativity(elementHeight);
                uiet.Width = geom.avoidNegativity(elementWidth);

                RotateTransform rt = new RotateTransform();

                rt.CenterX = elementWidth * 0.5;
                rt.CenterY = elementHeight * 0.5;

                rt.Angle = elementAngle;

                uiet.RenderTransform = rt;
            }
            else if (parseFail == true)
            {
                //uiet.Width = 100;
                //uiet.Height = 50;
            }
        }

        // change color on item
        private void setColorOnShape(Shape shape)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                check_rbGroup_LinearGradientOrientation(shape);
            }
            else if (rb_solidBrush.IsChecked == true)
            {
                solidColorFill(shape);
            }
        }

        private void setColorOnUIE_TextElement(UIE_TextElement uiet)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                check_rbGroup_LinearGradientOrientation_UIE_TextElement(uiet);
            }
            else if (rb_solidBrush.IsChecked == true)
            {
                solidColorFill_UIE_Textelement(uiet);
            }
        }

        private void setColorOnUIE_ImageElement(UIE_ImageElement uiei)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                colorChoiceFunction();
                uiei.ImageElement.border.Background = new RadialGradientBrush(color_1, color_2);
                uiei.ImageElement.border.BorderBrush = new SolidColorBrush(yrs_color_feature.getColor);
                uiei.ImageElement.border.BorderThickness = new Thickness(3);

            }
            else if (rb_solidBrush.IsChecked == true)
            {
                colorChoiceFunction();
                uiei.ImageElement.border.Background = new SolidColorBrush(yrs_color_feature.getColor);
                uiei.ImageElement.border.BorderBrush = new SolidColorBrush(yrs_color_feature.getColor);
                uiei.ImageElement.border.BorderThickness = new Thickness(3);
            }
        }

        // change z-index on item
        private void setZindexOnShape(Shape shape)
        {
            parseTextboxes();

            Panel.SetZIndex(shape, elementZindex);
        }

        private void setZindexOn_UIE_Textelement(UIE_TextElement uiet)
        {
            parseTextboxes();

            Panel.SetZIndex(uiet, elementZindex);
        }

        private Point simulatePadding(Point pnt)
        {
            if (pnt.X < 5)
            {
                pnt.X = 5;
            }
            else if (pnt.X > canvas.ActualWidth - 5)
            {
                pnt.X = canvas.ActualWidth - 5;
            }

            if (pnt.Y < 5)
            {
                pnt.Y = 5;
            }
            else if (pnt.Y > canvas.ActualHeight - 5)
            {
                pnt.Y = canvas.ActualHeight - 5;
            }
            else if (pnt.X > canvas.ActualWidth || pnt.X < 5
                || pnt.Y > canvas.ActualHeight || pnt.Y < 5)
            {
                if (x_pressed == true)
                {
                    x_pressed_MouseUp();
                }
                else if (y_pressed == true)
                {
                    y_pressed_MouseUp();
                }
            }

            return pnt;
        }

        private void solidColorFill(Shape _shape)
        {
            _shape.Fill = new SolidColorBrush(yrs_color_feature.getColor);
            _shape.Stroke = yrs_color_feature.returnSolidColorBrush(color_2);
        }

        private void solidColorFill_UIE_Textelement(UIE_TextElement uiet)
        {
            uiet.border.Background = new SolidColorBrush(yrs_color_feature.getColor);
            uiet.textbox.Foreground = yrs_color_feature.returnSolidColorBrush(color_1);
        }



        // drag drawing logic
        #region drag drawing logic

        // on mouse down
        private void s_pressed_MouseDown(MouseEventArgs _e)
        {
            if (s_pressed == false)
            {

            }
            else if (s_pressed == true)
            {
                if (_e.LeftButton == MouseButtonState.Pressed)
                    scetchPoint = _e.GetPosition(canvas);
            }
        }

        private void x_pressed_MouseDown(MouseEventArgs _e)
        {
            if (x_pressed == false)
            {

            }
            else if (x_pressed == true)
            {
                dragState = true;

                startPoint_dragRectangle = _e.GetPosition(canvas);

                dragRectangle = new Rectangle
                {
                    Fill = yrs_color_feature.returnSolidColorBrush(color_1),
                    Stroke = yrs_color_feature.returnSolidColorBrush(color_2),
                    StrokeThickness = uic.borderThickness
                };

                Canvas.SetLeft(dragRectangle, startPoint_dragRectangle.X);
                Canvas.SetTop(dragRectangle, startPoint_dragRectangle.Y);

                canvas.Children.Add(dragRectangle);
            }
        }

        private void y_pressed_MouseDown(MouseEventArgs _e)
        {
            if (y_pressed == false)
            {

            }
            else if (y_pressed == true)
            {
                dragState = true;

                startPoint_dragEllipse = _e.GetPosition(canvas);

                dragEllipse = new Ellipse
                {
                    Fill = yrs_color_feature.returnSolidColorBrush(color_1),
                    Stroke = yrs_color_feature.returnSolidColorBrush(color_2),
                    StrokeThickness = uic.borderThickness
                };
                Canvas.SetLeft(dragEllipse, startPoint_dragEllipse.X);
                Canvas.SetTop(dragEllipse, startPoint_dragEllipse.Y);
                canvas.Children.Add(dragEllipse);
            }
        }

        // on mouse move
        private void s_pressed_MouseMove(MouseEventArgs _e)
        {
            if (_e.LeftButton == MouseButtonState.Pressed)
            {
                if (s_pressed == true)
                {
                    Line line = new Line();

                    //line.StrokeThickness = 50;
                    //line.StrokeThickness = 20;
                    line.StrokeThickness = 10;
                    line.Stroke = yrs_color_feature.returnSolidColorBrush(yrs_color_feature.getColor);

                    //line.Stroke = new RadialGradientBrush(color_1, color_2);
                    //line.Stroke = new LinearGradientBrush(color_1, color_2, 0);

                    //line.StrokeDashArray = new DoubleCollection() { 1, 2, 4 };

                    //line.StrokeEndLineCap = PenLineCap.Triangle;
                    line.StrokeEndLineCap = PenLineCap.Flat;
                    //line.StrokeEndLineCap = PenLineCap.Square;
                    //line.StrokeEndLineCap = PenLineCap.Round;

                    line.X1 = scetchPoint.X;
                    line.Y1 = scetchPoint.Y;
                    line.X2 = _e.GetPosition(canvas).X;
                    line.Y2 = _e.GetPosition(canvas).Y;

                    scetchPoint = _e.GetPosition(canvas);

                    setZindexOnShape(line);

                    canvas.Children.Add(line);
                }
            }
        }

        private void x_pressed_MouseMove(MouseEventArgs _e)
        {
            if (x_pressed == false)
            {

            }
            else if (x_pressed == true)
            {
                if (_e.LeftButton == MouseButtonState.Released || dragState == false)
                {
                    if (dragRectangle != null)
                    {
                        dragRectangleID++;

                        dragRectangle.Fill = yrs_color_feature.returnSolidColorBrush(color_1);
                        dragRectangle.Stroke = yrs_color_feature.returnSolidColorBrush(color_2);
                        dragRectangle.StrokeThickness = uic.borderThickness;

                        dragRectangle.Name = $"dragRectangle_{dragRectangleID.ToString()}";

                        dragRectangle.MouseDown += Rectangle_MouseDown;
                        dragRectangle.MouseMove += Rectangle_MouseMove;
                        dragRectangle.MouseUp += Rectangle_MouseUp;
                    }

                    dragState = false;

                    return;
                }

                Point pos = _e.GetPosition(canvas);

                pos = simulatePadding(pos);

                double x = Math.Min(pos.X, startPoint_dragRectangle.X);
                double y = Math.Min(pos.Y, startPoint_dragRectangle.Y);

                double w = Math.Max(pos.X, startPoint_dragRectangle.X) - x;
                double h = Math.Max(pos.Y, startPoint_dragRectangle.Y) - y;

                dragRectangle.Width = w;
                dragRectangle.Height = h;

                Canvas.SetLeft(dragRectangle, x);
                Canvas.SetTop(dragRectangle, y);
            }
        }

        private void y_pressed_MouseMove(MouseEventArgs _e)
        {
            if (y_pressed == false)
            {

            }
            else if (y_pressed == true)
            {
                if (_e.LeftButton == MouseButtonState.Released || dragState == false)
                {

                    if (dragEllipse != null)
                    {
                        dragEllipseID++;

                        dragEllipse.Fill = yrs_color_feature.returnSolidColorBrush(color_1);
                        dragEllipse.Stroke = yrs_color_feature.returnSolidColorBrush(color_2);
                        dragEllipse.StrokeThickness = uic.borderThickness;

                        dragEllipse.Name = $"dragEllipse{dragEllipseID.ToString()}";

                        dragEllipse.MouseDown += Ell_MouseDown;
                        dragEllipse.MouseMove += Ell_MouseMove;
                        dragEllipse.MouseUp += Ell_MouseUp;
                    }

                    dragState = false;

                    //x_pressed = false;
                    return;
                }

                Point pos = _e.GetPosition(canvas);

                pos = simulatePadding(pos);

                double x = Math.Min(pos.X, startPoint_dragEllipse.X);
                double y = Math.Min(pos.Y, startPoint_dragEllipse.Y);

                double w = Math.Max(pos.X, startPoint_dragEllipse.X) - x;
                double h = Math.Max(pos.Y, startPoint_dragEllipse.Y) - y;

                dragEllipse.Width = w;
                dragEllipse.Height = h;

                Canvas.SetLeft(dragEllipse, x);
                Canvas.SetTop(dragEllipse, y);
            }
        }

        // on mouse up
        private void x_pressed_MouseUp()
        {
            drag = false;
            drag_canvas = false;
            drag_ellp = false;

            drag_line = false;
            drag_triangle = false;

            dragging = false;

            if (x_pressed == false)
            {

            }
            else if (x_pressed == true)
            {
                dragRectangleID++;

                dragRectangle.Fill = yrs_color_feature.returnSolidColorBrush(color_1);
                dragRectangle.Stroke = yrs_color_feature.returnSolidColorBrush(color_2);
                dragRectangle.StrokeThickness = uic.borderThickness;

                dragRectangle.Name = $"dragRectangle_{dragRectangleID.ToString()}";

                dragRectangle.MouseDown += Rectangle_MouseDown;
                dragRectangle.MouseMove += Rectangle_MouseMove;
                dragRectangle.MouseUp += Rectangle_MouseUp;

                dragState = false;
            }
        }

        private void y_pressed_MouseUp()
        {

            drag = false;
            drag_canvas = false;
            drag_ellp = false;

            drag_line = false;
            drag_triangle = false;

            dragging = false;

            if (y_pressed == false)
            {

            }
            else if (y_pressed == true)
            {
                dragEllipseID++;

                if (dragEllipse != null)
                {
                    dragEllipse.Fill = yrs_color_feature.returnSolidColorBrush(color_1);
                    dragEllipse.Stroke = yrs_color_feature.returnSolidColorBrush(color_2);
                    dragEllipse.StrokeThickness = uic.borderThickness;
                }

                dragEllipse.Name = $"dragEllipse{dragEllipseID.ToString()}";

                dragEllipse.MouseDown += Ell_MouseDown;
                dragEllipse.MouseMove += Ell_MouseMove;
                dragEllipse.MouseUp += Ell_MouseUp;

                dragState = false;
            }
        }
        #endregion drag drawing logic

        #endregion private methods



        // events
        #region events

        // on canvas
        private void canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                if (s_pressed == false && x_pressed == false && y_pressed == false)
                {
                    // hier gibt es ab und an einen bug wegen irgendwas, gerade vergessen.
                    try
                    {

                    }
                    catch (Exception)
                    {
                    }
                }
                else
                {
                    s_pressed_MouseDown(e);

                    x_pressed_MouseDown(e);

                    y_pressed_MouseDown(e);
                }

                e.Handled = true;
            }
        }

        private void canvas_MouseMove(object sender, MouseEventArgs e)
        {
            s_pressed_MouseMove(e);

            x_pressed_MouseMove(e);

            y_pressed_MouseMove(e);

            e.Handled = true;
        }

        private void canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                x_pressed_MouseUp();

                y_pressed_MouseUp();

                e.Handled = true;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                drag = false;
                drag_canvas = false;
                drag_ellp = false;
                drag_line = false;
                drag_triangle = false;

                dragging = false;

                e.Handled = true;
            }
        }


        // on ellipses
        private void Ell_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Ellipse ellp = (Ellipse)sender;

            Panel.SetZIndex(ellp, 1000);

            if (e.ChangedButton == MouseButton.Middle)
            {
                // start dragging
                drag_ellp = true;
                // save start point of dragging
                startPoint_ellp = Mouse.GetPosition(canvas);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                canvas.Children.Remove(ellp);

                e.Handled = true;

                GC.Collect(0);
            }

            if (e.ChangedButton == MouseButton.Left)
            {
                setColorOnShape(ellp);

                setZindexOnShape(ellp);

                e.Handled = true;
            }
        }

        private void Ell_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag_ellp)
            {
                Ellipse draggedEllipse = sender as Ellipse;
                Point newPoint = Mouse.GetPosition(canvas);
                double left = Canvas.GetLeft(draggedEllipse);
                double top = Canvas.GetTop(draggedEllipse);
                Canvas.SetLeft(draggedEllipse, left + (newPoint.X - startPoint_ellp.X));
                Canvas.SetTop(draggedEllipse, top + (newPoint.Y - startPoint_ellp.Y));

                startPoint_ellp = newPoint;
            }
        }



        private void Ell_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Middle)
            {
                Ellipse ellp = (Ellipse)sender;

                Panel.SetZIndex(ellp, elementZindex);

                disableDragState();

                e.Handled = true;
            }
        }


        // on radiobuttons
        private void rb_linearBrush_Checked(object sender, RoutedEventArgs e)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                rb_orientationBottom.IsEnabled = true;

                rb_orientationTop.IsEnabled = true;
                rb_orientationTop.IsChecked = true;

                rb_orientationLeft.IsEnabled = true;

                rb_orientationRight.IsEnabled = true;
            }
        }

        private void rb_solidBrush_Checked(object sender, RoutedEventArgs e)
        {
            if (rb_solidBrush.IsChecked == true)
            {
                rb_orientationBottom.IsEnabled = false;
                rb_orientationBottom.IsChecked = false;

                rb_orientationTop.IsEnabled = false;
                rb_orientationTop.IsChecked = false;

                rb_orientationLeft.IsEnabled = false;
                rb_orientationLeft.IsChecked = false;

                rb_orientationRight.IsEnabled = false;
                rb_orientationRight.IsChecked = false;
            }
        }

        private void pylin_MouseDown(object sender, MouseButtonEventArgs e)
        {
            selectedShape = sender as Shape;

            Panel.SetZIndex(selectedShape, 1000);

            if (e.ChangedButton == MouseButton.Middle)
            {
                if (dragging == false)
                {
                    dragging = true;
                    clickV = e.GetPosition(selectedShape);
                }

                e.Handled = true;
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                canvas.Children.Remove(selectedShape);

                e.Handled = true;

                GC.Collect(0);
            }

            if (e.ChangedButton == MouseButton.Left)
            {
                setColorOnShape(selectedShape);

                setZindexOnShape(selectedShape);

                e.Handled = true;
            }
        }


        private void pylin_MouseMove(object sender, MouseEventArgs e)
        {
            Polyline pylin = selectedShape as Polyline;

            if (dragging)
            {
                Canvas.SetLeft(pylin, e.GetPosition(canvas).X - geom.avoidNegativity(clickV.X));
                Canvas.SetTop(pylin, e.GetPosition(canvas).Y - geom.avoidNegativity(clickV.Y));
            }
        }

        private void pylin_MouseUp(object sender, MouseButtonEventArgs e)
        {
            selectedShape = sender as Shape;

            if (e.ChangedButton == MouseButton.Middle)
            {
                disableDragState();
            }

            e.Handled = true;
        }



        private void pygon_MouseDown(object sender, MouseButtonEventArgs e)
        {
            selectedShape = sender as Shape;

            Panel.SetZIndex(selectedShape, 1000);

            if (e.ChangedButton == MouseButton.Middle)
            {
                if (dragging == false)
                {
                    dragging = true;
                    clickV = e.GetPosition(selectedShape);
                }

                e.Handled = true;
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                canvas.Children.Remove(selectedShape);

                e.Handled = true;

                GC.Collect(0);
            }

            if (e.ChangedButton == MouseButton.Left)
            {
                setColorOnShape(selectedShape);

                setZindexOnShape(selectedShape);

                e.Handled = true;
            }
        }


        private void pygon_MouseMove(object sender, MouseEventArgs e)
        {
            Polygon pygon = selectedShape as Polygon;

            if (dragging)
            {
                Canvas.SetLeft(pygon, e.GetPosition(canvas).X - geom.avoidNegativity(clickV.X));
                Canvas.SetTop(pygon, e.GetPosition(canvas).Y - geom.avoidNegativity(clickV.Y));
            }
        }

        private void pygon_MouseUp(object sender, MouseButtonEventArgs e)
        {
            selectedShape = sender as Shape;

            if (e.ChangedButton == MouseButton.Middle)
            {
                disableDragState();
            }

            e.Handled = true;
        }


        // on rectangles
        private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Rectangle rect = (Rectangle)sender;

            Panel.SetZIndex(rect, 1000);

            if (e.ChangedButton == MouseButton.Middle)
            {
                // start dragging
                drag = true;
                // save start point of dragging
                startPoint = Mouse.GetPosition(canvas);

                e.Handled = true;
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                e.Handled = true;

                GC.Collect(0);
            }

            if (e.ChangedButton == MouseButton.Left)
            {
                setColorOnShape(rect);
                setZindexOnShape(rect);

                e.Handled = true;
            }
        }

        private void Rectangle_MouseMove(object sender, MouseEventArgs e)
        {
            // if dragging, then adjust rectangle position based on mouse movement
            if (drag)
            {
                Rectangle draggedRectangle = sender as Rectangle;
                Point newPoint = Mouse.GetPosition(canvas);
                double left = Canvas.GetLeft(draggedRectangle);
                double top = Canvas.GetTop(draggedRectangle);
                Canvas.SetLeft(draggedRectangle, left + (newPoint.X - startPoint.X));
                Canvas.SetTop(draggedRectangle, top + (newPoint.Y - startPoint.Y));

                startPoint = newPoint;
            }
        }

        private void Rectangle_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Middle)
            {
                Rectangle rect = (Rectangle)sender;

                disableDragState();

                Panel.SetZIndex(rect, elementZindex);
            }
        }

        // on Scetchboard main window
        private void ScetchboardWindow_Loaded(object sender, RoutedEventArgs e)
        {
            canvasLoad();

            // lbl_colorFeatureVisibilityStatus.Content = "Mode: 'key d pressed ' change colors on buttons";
            d_pressed = false;
        }

        // on buttons
        private void Uie_A_Click(object sender, RoutedEventArgs e)
        {
            drawUIE_TextElement();
        }

        private void Uie_cascade_button_Click(object sender, RoutedEventArgs e)
        {
            drawCascade_Rectangles();
        }

        private void Uie_cascade_ellipses_button_Click(object sender, RoutedEventArgs e)
        {
            drawCascade_Ellipses();
        }

        private void Uie_cascade_triangles_button_Click(object sender, RoutedEventArgs e)
        {
            drawCascade_Triangles();
        }

        private void Uie_circle_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleEllipse();
        }

        private void Uie_line_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleLine();
        }

        private void Uie_rectangle_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleRectangle();
        }

        private void Uie_TextElement_Click(object sender, RoutedEventArgs e)
        {
            drawUIE_TextElement();
        }

        private void Uie_triangle_equilateral_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleTriangle_equilateral();
        }

        private void Uie_triangle_isosceles_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleTriangle_isosceles();
        }

        private void Uie_triangle_rectangular_button_Click(object sender, RoutedEventArgs e)
        {
            drawSimpleTriangle_rectangular();
        }


        // on scetchboard window grid
        private void WindowGrid_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }



        // scetchboard events
        private void ScetchboardWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            yrs_color_feature.colorChoice_saveColors();

            GC.Collect(0);
        }

        private void ScetchboardWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.B)
            {
                canvas.Background = yrs_color_feature.returnSolidColorBrush(yrs_color_feature.getColor);

                e.Handled = false;
            }

            if (e.Key == Key.D)
            {
                if (yrs_color_feature.buttonChecked == false)
                {
                    yrs_color_feature.buttonChecked = true;
                }
                else if (yrs_color_feature.buttonChecked == true)
                {
                    yrs_color_feature.buttonChecked = false;
                }

                e.Handled = false;
            }

            if (e.Key == Key.H)
            {
                if (wrp_colorpicker.Visibility == Visibility.Collapsed)
                {
                    wrpMenu.Visibility = Visibility.Visible;
                    wrpRadioButtons.Visibility = Visibility.Visible;
                    wrpTextBoxes.Visibility = Visibility.Visible;
                    wrp_colorpicker.Visibility = Visibility.Visible;
                }
                else if (wrp_colorpicker.Visibility == Visibility.Visible)
                {
                    wrpMenu.Visibility = Visibility.Collapsed;
                    wrpRadioButtons.Visibility = Visibility.Collapsed;
                    wrpTextBoxes.Visibility = Visibility.Collapsed;
                    wrp_colorpicker.Visibility = Visibility.Collapsed;
                }

                e.Handled = false;
            }


            if (e.Key == Key.F2)
            {
                config.saveScetchboardPictureToPNG(canvas);
            }

            if (e.Key == Key.S)
            {
                e.Handled = false;

                if (x_pressed == true || y_pressed == true)
                {
                    x_pressed = false;
                    y_pressed = false;
                }
            }


            if (e.Key == Key.X)
            {
                //drawSimpleRectangle();
                e.Handled = false;

                if (s_pressed == true || y_pressed == true)
                {
                    s_pressed = false;
                    y_pressed = false;
                }
            }


            if (e.Key == Key.Y)
            {
                //drawSimpleRectangle();
                e.Handled = false;

                if (s_pressed == true || x_pressed == true)
                {
                    s_pressed = false;
                    x_pressed = false;
                }
            }
        }

        private void ScetchboardWindow_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.B)
            {
                e.Handled = true;
            }

            if (e.Key == Key.D)
            {
                if (d_pressed == true)
                {
                    d_pressed = false;

                    lbl_colorFeatureVisibilityStatus.Content = "no key mode active";
                }
                else if (d_pressed == false)
                {
                    d_pressed = true;

                    lbl_colorFeatureVisibilityStatus.Content = "Mode: 'key d pressed ' change colors on buttons";
                }

                e.Handled = true;
            }

            if (e.Key == Key.H)
            {
                if (h_pressed == true)
                {
                    h_pressed = false;

                    lbl_colorFeatureVisibilityStatus.Content = "no key mode active";
                }
                else if (h_pressed == false)
                {
                    h_pressed = true;

                    lbl_colorFeatureVisibilityStatus.Content = "Mode: 'key h pressed ' hide color feature";
                }

                e.Handled = true;
            }


            if (e.Key == Key.S)
            {
                if (s_pressed == true)
                {
                    s_pressed = false;

                    lbl_activeMode.Content = "no key mode active";
                }
                else if (s_pressed == false)
                {
                    s_pressed = true;

                    lbl_activeMode.Content = "Mode: 'key s pressed ' draw free hand scetch line";
                }

                e.Handled = true;
            }

            if (e.Key == Key.X)
            {
                if (x_pressed == true)
                {
                    x_pressed = false;

                    lbl_activeMode.Content = "no key mode active";
                }
                else if (x_pressed == false)
                {
                    x_pressed = true;

                    lbl_activeMode.Content = "Mode: 'key x pressed ' draw free hand rectangle shapes";
                }

                e.Handled = true;
            }

            if (e.Key == Key.Y)
            {
                if (y_pressed == true)
                {
                    y_pressed = false;

                    lbl_activeMode.Content = "no key mode active";
                }
                else if (y_pressed == false)
                {
                    y_pressed = true;

                    lbl_activeMode.Content = "Mode: 'key y pressed ' -> draw free hand ellipse shapes";
                }

                e.Handled = true;
            }
        }

        private void ScetchboardWindow_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                e.Handled = true;

                //Close();
            }
        }

        private void ScetchboardWindow_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                dragState = false;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                disableDragState();
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                GC.Collect(0);

            }

            e.Handled = true;
        }


        private void utex_MouseDown(object sender, MouseButtonEventArgs e)
        {

            if (e.ChangedButton == MouseButton.Middle)
            {
                if (sender is UIE_TextElement)
                {
                    UIE_TextElement utex = (UIE_TextElement)sender;

                    //MessageBox.Show("huhu textelement hier");

                    Panel.SetZIndex(utex, 1000);
                    // start dragging
                    drag_canvas = true;
                    // save start point of dragging
                    startPoint_mycanvas = Mouse.GetPosition(canvas);

                    e.Handled = true;
                }

                else if (sender is UIE_ImageElement)
                {
                    UIE_ImageElement utex = (UIE_ImageElement)sender;

                    //MessageBox.Show("huhu bildelement hier");
                    Panel.SetZIndex(utex, 1000);
                    // start dragging
                    drag_canvas = true;
                    // save start point of dragging
                    startPoint_mycanvas = Mouse.GetPosition(canvas);

                    e.Handled = true;
                }

                else if (sender is YRS_ColorFeature)
                {
                    YRS_ColorFeature utex = (YRS_ColorFeature)sender;

                    //MessageBox.Show("huhu bildelement hier");
                    Panel.SetZIndex(utex, 1000);
                    // start dragging
                    drag_menuElements = true;
                    // save start point of dragging
                    startPoint_menuElements = Mouse.GetPosition(canvas);

                    e.Handled = true;
                }
            }
            if (e.ChangedButton == MouseButton.Right)
            {
                if (sender is UIE_TextElement)
                {
                    UIE_TextElement utex = (UIE_TextElement)sender;

                    canvas.Children.Remove(utex);
                }

                else if (sender is UIE_ImageElement)
                {
                    UIE_ImageElement utex = (UIE_ImageElement)sender;

                    canvas.Children.Remove(utex);
                }

                //else if (sender is YRS_ColorFeature)
                //{
                //    YRS_ColorFeature utex = (YRS_ColorFeature)sender;

                //    canvas.Children.Remove(utex);
                //}

                e.Handled = true;

                GC.Collect(0);
            }

            if (e.ChangedButton == MouseButton.Left)
            {
                if (sender is UIE_TextElement)
                {
                    UIE_TextElement utex = (UIE_TextElement)sender;
                    if (utex.textbox.IsEnabled)
                    {
                        utex.textbox.IsEnabled = false;
                        utex.checkbox.IsChecked = false;
                    }
                    else
                    {
                        utex.textbox.IsEnabled = true;
                        utex.checkbox.IsChecked = true;
                    }

                    rotateUIE_TextElement(utex);
                    setColorOnUIE_TextElement(utex);
                    setZindexOn_UIE_Textelement(utex);
                }

                if (sender is UIE_ImageElement)
                {
                    UIE_ImageElement utex = (UIE_ImageElement)sender;

                    // process uie_imageelement method name

                    //utex.enableTextBox();
                    //rotateUIE_TextElement(utex);
                    setColorOnUIE_ImageElement(utex);
                    //setZindexOn_UIE_Textelement(utex);

                    e.Handled = false;
                }

                else if (sender is YRS_ColorFeature)
                {
                    parseTextboxes();

                    YRS_ColorFeature utex = (YRS_ColorFeature)sender;

                    //canvas.Children.Remove(utex);

                    //utex = new YRS_ColorFeature();

                    //RotateTransform rt = new RotateTransform();
                    //rt.Angle = elementAngle;

                    //utex.RenderTransform = rt;

                    utex.Background = new SolidColorBrush(yrs_color_feature.getColor);

                    //Panel.SetZIndex(utex, elementZindex);

                    //canvas.Children.Add(utex);
                }

                e.Handled = true;
            }
        }

        private void utex_MouseMove(object sender, MouseEventArgs e)
        {
            // if dragging, then adjust rectangle position based on mouse movement
            if (drag_canvas)
            {
                if (sender is UIE_TextElement)
                {
                    UIE_TextElement utex = sender as UIE_TextElement;
                    Point newPoint = Mouse.GetPosition(canvas);
                    double left = Canvas.GetLeft(utex);
                    double top = Canvas.GetTop(utex);
                    Canvas.SetLeft(utex, left + (newPoint.X - startPoint_mycanvas.X));
                    Canvas.SetTop(utex, top + (newPoint.Y - startPoint_mycanvas.Y));

                    startPoint_mycanvas = newPoint;

                }

                else if (sender is UIE_ImageElement)
                {
                    UIE_ImageElement utex = sender as UIE_ImageElement;
                    Point newPoint = Mouse.GetPosition(canvas);
                    double left = Canvas.GetLeft(utex);
                    double top = Canvas.GetTop(utex);
                    Canvas.SetLeft(utex, left + (newPoint.X - startPoint_mycanvas.X));
                    Canvas.SetTop(utex, top + (newPoint.Y - startPoint_mycanvas.Y));

                    startPoint_mycanvas = newPoint;
                }

                else if (sender is YRS_ColorFeature)
                {
                    YRS_ColorFeature utex = sender as YRS_ColorFeature;
                    Point newPoint = Mouse.GetPosition(canvas);
                    double left = Canvas.GetLeft(utex);
                    double top = Canvas.GetTop(utex);
                    Canvas.SetLeft(utex, left + (newPoint.X - startPoint_menuElements.X));
                    Canvas.SetTop(utex, top + (newPoint.Y - startPoint_menuElements.Y));

                    startPoint_menuElements = newPoint;
                }
            }
        }

        private void utex_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Middle)
            {
                if (sender is UIE_TextElement)
                {
                    UIE_TextElement utex = (UIE_TextElement)sender;

                    disableDragState();

                    Panel.SetZIndex(utex, elementZindex);
                }
                else if (sender is UIE_ImageElement)
                {
                    UIE_ImageElement utex = (UIE_ImageElement)sender;

                    disableDragState();

                    Panel.SetZIndex(utex, elementZindex);
                }

                else if (sender is YRS_ColorFeature)
                {
                    YRS_ColorFeature utex = (YRS_ColorFeature)sender;

                    disableDragState();

                    Panel.SetZIndex(utex, elementZindex);
                }

            }
        }


        // on scetchboard window border
        private void WindowBorder_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Border bor = (Border)sender;

            if (e.ChangedButton == MouseButton.Left)
            {
                //if (bor. )
                //{

                //}

                //isLeftMouseButtonDownOnWindow = true;
                //origMouseDownPoint = e.GetPosition(this);

                //this.CaptureMouse();

                e.Handled = true;

            }

            if (e.ChangedButton == MouseButton.Right)
            {

                //OnPreviewMouseRightButtonDown(e);
                //OnPreviewMouseRightButtonUp(e);

                e.Handled = true;

                //this.OnPreviewMouseRightButtonDown(e);
                //this.OnPreviewMouseRightButtonUp(e);
            }

        }
        private void WindowBorder_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                dragState = false;
            }

            e.Handled = true;
        }
        #endregion events

        private UIE_ImageElement canvasDrop_processing(UIE_ImageElement img_, int i_)
        {
            double deltax = 10 * i_;
            double deltay = 10 * i_;

            Canvas.SetLeft(img_, deltax);
            Canvas.SetTop(img_, deltay);

            Panel.SetZIndex(img_, elementZindex);

            return img_;
        }

        private void canvas_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = e.Data.GetData(DataFormats.FileDrop) as string[];

                parseTextboxes();

                for (int i = 0; i < files.Length; i++)
                {
                    string filename = System.IO.Path.GetFileName(files[i]);

                    if (files[i] != null && files[i].Length > 0)
                    {
                        BitmapImage theImage = new BitmapImage
                            (new Uri(filename, UriKind.Relative));

                        ImageBrush myImageBrush = new ImageBrush(theImage);

                        UIE_ImageElement uIE_ImageElement = drawUIE_ImageElement(myImageBrush);

                        canvasDrop_processing(uIE_ImageElement, i);

                        canvas.Children.Add(uIE_ImageElement);
                    }
                }
            }
        }

        private void canvas_PreviewDragOver(object sender, DragEventArgs e)
        {
            e.Handled = true;
        }




        //private void pygon_MouseDown(object sender, MouseButtonEventArgs e)
        //{
        //    selectedShape = sender as Shape;

        //    Panel.SetZIndex(selectedShape, 1000);

        //    if (e.ChangedButton == MouseButton.Middle)
        //    {
        //        if (dragging == false)
        //        {
        //            dragging = true;
        //            clickV = e.GetPosition(selectedShape);
        //        }

        //        e.Handled = true;
        //    }

        //    if (e.ChangedButton == MouseButton.Right)
        //    {
        //        canvas.Children.Remove(selectedShape);

        //        e.Handled = true;

        //        GC.Collect(0);
        //    }

        //    if (e.ChangedButton == MouseButton.Left)
        //    {
        //        setColorOnShape(selectedShape);

        //        setZindexOnShape(selectedShape);

        //        e.Handled = true;
        //    }
        //}


        //private void pygon_MouseMove(object sender, MouseEventArgs e)
        //{
        //    Polygon pygon = selectedShape as Polygon;

        //    if (dragging)
        //    {
        //        Canvas.SetLeft(pygon, e.GetPosition(canvas).X - geom.avoidNegativity(clickV.X));
        //        Canvas.SetTop(pygon, e.GetPosition(canvas).Y - geom.avoidNegativity(clickV.Y));
        //    }
        //}

        //private void pygon_MouseUp(object sender, MouseButtonEventArgs e)
        //{
        //    selectedShape = sender as Shape;

        //    if (e.ChangedButton == MouseButton.Middle)
        //    {
        //        drag = false;
        //        drag_canvas = false;
        //        drag_ellp = false;
        //        drag_line = false;
        //        drag_triangle = false;

        //        dragging = false;
        //    }

        //    e.Handled = true;
        //}




    }
}
/*EOF*/

/* Heutige Erkenntnis:
 * Wer mit Microsoft arbeitet, der wird eher sterben als in der Informatik etwas zu erreichen.  10 verschiedene Funktionen für
 * eine Sache, keine einzige davon funktioniert, die Recherchen gehen katastrophal schleppend voran aufgrund unnötiger Kinderkomplexitäten
 * mentaler Säuglinge, es ist echt sinnlos, auf der Erde im 21. Jahrhundert Software entwickeln zu wollen.
 * Geht den Weg des Shaitans, äh des Scheiterns, ihr Volldeppen. Geht ihn allein, reißt alles mit eurer Dummheit ins Sinnlose,
 * da kennt ihr euch aus und da sollt ihr auf ewig reinkarnieren, im sinnlosesten Leben, aus eurem Schaffen geboren.
 Immerhin die if-Abfragen funktionieren vermutlich, kein Plan was im Hintergrund abl#. */