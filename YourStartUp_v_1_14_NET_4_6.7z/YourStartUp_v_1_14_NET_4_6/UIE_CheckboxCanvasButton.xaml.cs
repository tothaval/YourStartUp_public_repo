﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für UIE_CheckboxCanvasButton.xaml
    /// </summary>
    public partial class UIE_CheckboxCanvasButton : UserControl
    {
        ConfigData config = new ConfigData();
        Style style = new Style();

        public Color color { get; set; }

        private bool checkState = false;

        private bool styleFunc;




        public UIE_CheckboxCanvasButton()
        {
            styleFunc = false;

            InitializeComponent();
        }

        public UIE_CheckboxCanvasButton(Color color_)
        {
            styleFunc = true;

            color = color_;

            Resources.Remove("buttonColor");
            Resources.Remove("buttonFont");
            Resources.Remove("highlight");
            Resources.Remove("radius");

            Resources.Add("buttonColor", new SolidColorBrush(color));
            Resources.Add("buttonFont", config.btnForeColor);
            Resources.Add("highlight", config.highlightColor);
            Resources.Add("radius", new CornerRadius(config.borderRadius));
                                  

            InitializeComponent();


            uie_ckbcnvbtn_button.Style = style;
            uie_ckbcnvbtn_button_border.Height = 40;
            uie_ckbcnvbtn_button_border.Width = 100;
        }

        private Style getStyle()
        {
            Style style = this.FindResource("buttonStyle") as Style;

            return style;
        }

        private void checkReaction()
        {
            if (checkState == false)
            {
                checkState = true;
                uie_chx_choice_confirmer.IsChecked = true;
            }
            else if (checkState == true)
            {
                checkState = false;
                uie_chx_choice_confirmer.IsChecked = false;
            }
        }

        public Color returnColor()
        {
            if (color == null)
            {
                return Color.FromArgb(0, 0, 0, 0);
            }

            return color;
        }

        public void uie_ckbcnvbtn_button_Click(object sender, RoutedEventArgs e)
        {
            checkReaction();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (styleFunc == true)
            {
                uie_ckbcnvbtn_button.Style = getStyle();
            }            
        }
    }
}
