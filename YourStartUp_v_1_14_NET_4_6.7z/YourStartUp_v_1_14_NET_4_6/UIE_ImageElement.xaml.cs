﻿/* YourStartUp scetchboard tool  
 * 
 * Pur:         scetchboard window image element functionality
 * Int:         draws dragable image on canvas
 * Toc:         2022 (august <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      taranis.sk@gmail.com
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für UIE_ImageElement.xaml
    /// </summary>
    public partial class UIE_ImageElement : UserControl
    {
        double width = 50;
        double height = 50;

        int caching;

        public UIE_ImageElement(double width_, double height_)
        {
            width = width_;

            height = height_;

            InitializeComponent();
        }

        private void ImageElement_Loaded(object sender, RoutedEventArgs e)
        {

            border.Width = width;

            border.Height = height;

            border.Padding = new Thickness(5.51);

        }

        private void ImageElement_MouseDown(object sender, MouseButtonEventArgs e)
        {
            caching++;
        }
    }
}
