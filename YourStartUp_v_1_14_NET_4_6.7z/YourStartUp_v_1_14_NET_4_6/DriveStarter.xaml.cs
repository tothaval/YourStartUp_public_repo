﻿/* YourStartUp drive starter tool  
 * 
 * Pur:         displays system drives, user can add buttons to quick access a folder or a drive
 * Toc:         2022 (may <> july)
 * Dev:         Stephan Kammel
 * E-Mail:      taranis.sk@gmail.com
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Diagnostics;
using System.IO;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für DriveStarter.xaml
    /// </summary>
    public partial class DriveStarter : Window
    {
        private readonly System.Windows.Threading.DispatcherTimer _timer = new System.Windows.Threading.DispatcherTimer();
        private readonly System.Windows.Threading.DispatcherTimer _pulse = new System.Windows.Threading.DispatcherTimer();
        ConfigData config = new ConfigData();

        // globals
        public List<string> directory = new List<string>();
        List<Button> btnDrvs = new List<Button>();
        List<Button> btnFlds = new List<Button>();

        //List<CheckBox> cbxDrvs = new List<CheckBox>();

        DriveInfo[] allDrives = DriveInfo.GetDrives();        

        int count = 0; // counter (_timer)
        int refresh = 0; // counter (_pulse)
        int gigabyte = 1024 * 1024 * 1024;

        bool deleteState = false;

        public DriveStarter()
        {
            InitializeComponent();
            //_timer.Interval = TimeSpan.FromSeconds(0.2); //wait for the other click for 200ms
            //_timer.Tick += Timer_Tick;

            this.driveStarterWindow.WindowStartupLocation = WindowStartupLocation.Manual;            

            _pulse.Interval = TimeSpan.FromSeconds(1);
            _pulse.Tick += _pulse_Tick;
        }

        private void newDriveInfo()
        {
            allDrives = DriveInfo.GetDrives();
        }

        // methods _public
        public void saveFolderConfig()
        {
            StreamWriter sw_config = new StreamWriter(config.path_folders, false);

            for (int i = 0; i < directory.Count; i++)
            {
                sw_config.WriteLine(directory[i]);
            }
            sw_config.Close();
        }

        // methods _private
        private void buildFolderButton(string _configuration)
        {
            directory.Add(_configuration);

            Button btnFolder = new Button();
            btnFolder.Name = "btnFolder" + btnFlds.Count.ToString();
            btnFolder.Background = config.btnBackColor;
            btnFolder.Foreground = config.btnForeColor;
            btnFolder.FontFamily = config.font;
            btnFolder.FontSize = config.fontSize;
            btnFolder.Height = config.btnHeight;
            btnFolder.Width = config.btnWidth;
            btnFolder.Margin = new Thickness(2, 6, 2, 2);
            btnFolder.ToolTip = "Click to open folder.\n" +
                "Double click next to a button to enter delete state, indicated by a color change.\n" +
                "In delete state a click on a button will delete it.\n" +
                "Double click next to a button to leave delete state.\n" +
                "Right click next to a button to add a new confiurable button to assign a folder to.";

            btnFolder.Content = _configuration;

            btnFolder.Click += BtnFolder_Click;

            btnFlds.Add(btnFolder);

            wrpFolders.Children.Add(btnFolder);
        }
        private void buildSelectionButton(int count, DriveInfo d)
        {
            Button btnDrive = new Button();
            btnDrive.Name = "btnDrive" + btnDrvs.Count.ToString();
            btnDrive.Background = config.btnBackColor;
            btnDrive.Foreground = config.btnForeColor;
            btnDrive.FontFamily = config.font;
            btnDrive.FontSize = config.fontSize;
            btnDrive.Height = config.btnHeight;
            btnDrive.Width = config.btnWidth;
            btnDrive.Margin = new Thickness(2, 6, 2, 2);

            if (d.IsReady)
            {
                btnDrive.Content = $"{d.Name}\nfree: {d.TotalFreeSpace/gigabyte} GB";                   
                
                btnDrive.HorizontalAlignment = HorizontalAlignment.Left;
                btnDrive.VerticalContentAlignment = VerticalAlignment.Center;                

                btnDrive.ToolTip = $"{d.TotalSize/gigabyte} GB Total Storage Capacity\n\n" +
                    $"{d.Name}{d.VolumeLabel}\n\n" +
                    $"{d.DriveFormat}{d.DriveType}\n\ndrive is ready";                                       
            }
            else
            {
                btnDrive.Content = d.Name + " - not ready -";

                if(d.IsReady == false)
                {
                    string tooltipText = $"empty\n\n" +
                        $"{d.Name}\n\n + {d.DriveType}";

                    btnDrive.ToolTip = tooltipText;
                }                                
            }


            btnDrive.Click += BtnDrive_Click;

            wrpDrives.Children.Add(btnDrive);

            btnDrvs.Add(btnDrive);
        }
        private void delete()
        {
            if (deleteState == true)
            {
                deleteState = false;
                for (int i = 0; i < btnFlds.Count; i++)
                {
                    btnFlds[i].Background = config.btnBackColor;
                    btnFlds[i].Foreground = config.btnForeColor;
                }
            }
            else
            {
                deleteState = true;
                for (int i = 0; i < btnFlds.Count; i++)
                {
                    btnFlds[i].Background = config.deleteState;
                    btnFlds[i].Foreground = config.deleteStateFont;
                }
            }
        }
        private void insertPath()
        {
            TextBox txtInsertUrl = new TextBox();
            txtInsertUrl.Height = config.btnHeight;
            txtInsertUrl.Width = config.btnWidth;
            txtInsertUrl.Visibility = Visibility.Visible;
            txtInsertUrl.Text = "insert path";
            txtInsertUrl.Background = config.resetState;
            txtInsertUrl.Foreground = config.resetStateFont;
            txtInsertUrl.HorizontalContentAlignment = HorizontalAlignment.Center;
            txtInsertUrl.VerticalContentAlignment = VerticalAlignment.Center;
            txtInsertUrl.Margin = new Thickness(2, 2, 2, 2);

            txtInsertUrl.KeyDown += TxtInsertUrl_KeyDown;
            txtInsertUrl.MouseDoubleClick += TxtInsertUrl_MouseDoubleClick;
            txtInsertUrl.MouseDown += TxtInsertUrl_MouseDown;
            txtInsertUrl.TextChanged += TxtInsertUrl_TextChanged;

            wrpFolders.Children.Add(txtInsertUrl);
        }
        private void loadConfig()
        {
            // Read the file line by line.  
            foreach (string line in System.IO.File.ReadLines(config.path_folders))
            {
                buildFolderButton(line);
            }
        }
        private void loadUIConfig()
        {
            btnAll.Content = "all";
            btnAll.Background = config.btnBackColor;
            btnAll.Foreground = config.btnForeColor;
            btnAll.FontFamily = config.font;
            btnAll.FontSize = config.fontSize;
            btnAll.Height = config.btnHeight;
            btnAll.Width = config.btnWidth;
            //btnAll.Margin = new Thickness(2, 6, 2, 2);
            btnAll.ToolTip = "Open every drive at once, drives must be ready in order to be opened.";

            driveStarterWindow.Background = config.backColor;
            driveStarterWindow.Foreground = config.foreColor;
            driveStarterWindow.FontFamily = config.font;
            driveStarterWindow.FontSize = config.fontSize;

            Background = config.backColor;
            Foreground = config.foreColor;
            BorderBrush = config.foreColor;
            BorderThickness = new Thickness(3);

            //driveStarterWindow.Height = (2 * config.btnHeight) + 25;
            //driveStarterWindow.Width = (allDrives.Length + 2) * config.btnWidth + 40;
            //driveStarterWindow.MinHeight = (2 * config.btnHeight) + 25;
            //driveStarterWindow.MinWidth = (allDrives.Length + 2) * config.btnWidth + 40;

            //wrpDrives.MaxHeight = config.btnHeight + 4;
            //wrpDrives.Margin = new Thickness(5, 0, 5, 5);

            ////wrpFolders.MaxHeight = config.getButtonHeight()+4;
            //wrpFolders.Margin = new Thickness(5, 0, 5, 5);

            for (int i = 0; i < allDrives.Length; i++)
            {
                buildSelectionButton(i, allDrives[i]);
            }
        }
        private void openFolder(int index)
        {
            Process.Start("explorer.exe", directory[index]);
        }

        // events _private

        private void btnAll_Click(object sender, RoutedEventArgs e)
        {
            //OpenFileDialog openFD = new OpenFileDialog();            

            for (int i = 0; i < allDrives.Length; i++)
            {
                if (allDrives[i].IsReady)
                {
                    Process.Start("explorer.exe", allDrives[i].Name);
                }
            }
        }
        private void BtnDrive_Click(object sender, EventArgs e)
        {
            Button btnDrive = (Button)sender;
            int index = btnDrvs.IndexOf(btnDrive);

            if (allDrives[index].IsReady)
            {
                Process.Start("explorer.exe", allDrives[index].Name);
            }

            if (!allDrives[index].IsReady)
            {
                MessageBox.Show("Drive not ready");
            }

        }
        private void BtnFolder_Click(object sender, RoutedEventArgs e)
        {
            Button btnFolder = (Button)sender;

            int index = btnFlds.IndexOf(btnFolder);

            if (deleteState == true)
            {
                wrpFolders.Children.Remove(btnFolder);
                directory.RemoveAt(index);
                btnFlds.RemoveAt(index);
            }
            if (deleteState == false)
            {
                Process.Start("explorer.exe", directory[index]);
            }            
        }
        
        private void driveStarterWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            _pulse.Stop();
        }
        private void driveStarterWindow_Loaded(object sender, RoutedEventArgs e)
        {
            loadConfig();
            loadUIConfig();            
            _pulse.Start();
        }
        private void driveStarterWindow_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            delete();
        }
        private void driveStarterWindow_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                insertPath();
            }
        }
        private void _pulse_Tick(object sender, EventArgs e)
        {
            refresh++;
            if (refresh == 2)
            {
                for (int i = 0; i < btnDrvs.Count; i++)
                {
                    wrpDrives.Children.Clear();
                    btnDrvs.Clear();
                }
                
                loadUIConfig();
                wrpDrives.Children.Add(btnAll);

                refresh = 0;

                saveFolderConfig();
                newDriveInfo();
            }
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            count++;
            //MessageBox.Show("Single Click!"); //handle the single click event here...           

        }
        private void TxtInsertUrl_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox txtBtn = (TextBox)sender;

            if (e.Key == Key.Enter)
            {
                Keyboard.ClearFocus();

                string config = txtBtn.Text;
                //MessageBox.Show(config);

                buildFolderButton(config);

                wrpFolders.Children.Remove(txtBtn);
            }
        }
        private void TxtInsertUrl_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // hier btn löschen , achne, muss aufs btnevent
            TextBox txtBtn = (TextBox)sender;
            txtBtn.Text = "";
        }
        private void TxtInsertUrl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                //this.DragMove();
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                //insertPath();
            }
        }
        private void TxtInsertUrl_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

    }
}
/* drive starter tool  
* 
* End of File
*/