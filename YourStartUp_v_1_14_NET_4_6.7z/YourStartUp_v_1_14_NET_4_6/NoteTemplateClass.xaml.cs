﻿/* YourStartUp notes template class
 * 
 * Pur:         template for note function
 * Toc:         2022 (may <> august)
 * Dev:         Stephan Kammel
 * E-Mail:      taranis.sk@gmail.com
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für NoteTemplateClass.xaml
    /// </summary>
    public partial class NoteTemplateClass : UserControl
    {
        ConfigData config = new ConfigData();

        public double btnHeight;
        public double btnWidth;

        private string time;

        public NoteTemplateClass(string txtTime)
        {
            InitializeComponent();

            time = txtTime;

            NoteTemplate();                       
        }

        private void NoteTemplate()
        {            
            noteText.Height = config.btnHeight * 4;
            noteText.Width = config.btnWidth * 2;
            noteText.FontFamily = config.font;
            noteText.FontSize = config.fontSize;
            noteText.Background = config.textBox;
            noteText.Foreground = config.textBoxFont;
            noteText.Margin = new Thickness(0, 2, 5, 0);            
            
            noteText.SetValue(Paragraph.LineHeightProperty, 5.0);
            noteText.AppendText(time + "\n");                  
        }

        private void NotesTemplateUC_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = this;

            btnHeight = Convert.ToDouble(config.btnHeight);
            btnWidth = Convert.ToDouble(config.btnWidth);

            NotesTemplateUC.Resources.Add("btnHeight", btnHeight);
            NotesTemplateUC.Resources.Add("btnWidth", btnWidth);

            NotesTemplateUC.Height = 4 * config.btnHeight;
            NotesTemplateUC.Width = 2 * config.btnWidth;
                        
            //// nice
            //TextRange textRange = new TextRange(noteText.Document.ContentStart, noteText.Document.ContentEnd);
            ////MessageBox.Show(textRange.Text);

        }
    }
}
