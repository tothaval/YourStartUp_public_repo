﻿/*  purpose: managing language elements of main window
 * 
 * written: september 2022
 * by: stephan kammel
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YourStartUp
{
    class MainWindowTexts
    {
        public string language { get; set; }

        // constructor
        public MainWindowTexts(string _language = "english")
        {
            language = _language;
        }

        // content
        #region content       
        public StringBuilder btnAdd_content()
        {
            if (language == "english")
            {
                string value = "add";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnAll_content()
        {
            if (language == "english")
            {
                string value = "all";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnDelete_content()
        {
            if (language == "english")
            {
                string value = "delete";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnInfo_content()
        {
            if (language == "english")
            {
                string value = "info page";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnNotes_content()
        {
            if (language == "english")
            {
                string value = "notes";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnQuit_content()
        {
            if (language == "english")
            {
                string value = "quit";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnRename_content()
        {
            if (language == "english")
            {
                string value = "rename";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnReset_content()
        {
            if (language == "english")
            {
                string value = "reset";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnScetchboard_content()
        {
            if (language == "english")
            {
                string value = "scetchboard";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnSettings_content()
        {
            if (language == "english")
            {
                string value = "settings";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnShutdown_content()
        {
            if (language == "english")
            {
                string value = "shutdown";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnTimer_content()
        {
            if (language == "english")
            {
                string value = "timer";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        #endregion content

        // strings
        #region strings
        public StringBuilder driveNotReadyMessage()
        {
            if (language == "english")
            {
                string value = "drive not ready";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder pathExcetptionMessage()
        {
            if (language == "english")
            {
                string value = "could not open path \n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder shutdownQuestion()
        {
            if (language == "english")
            {
                string value = "Are you sure you want to shutdown your computer?";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }        
        }
        public StringBuilder shutdownTitle()
        {
            if (language == "english")
            {
                string value = "PC Shutdown";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        #endregion strings


        // texts
        #region texts
        public StringBuilder hideButtonContent()
        {
            string value = ".\n" +
                ".\n" +
                ".\n";

            StringBuilder sb = new StringBuilder(value);

            return sb;
        }
        public StringBuilder insertUrl()
        {
            if (language == "english")
            {
                string value = "insert URL";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        #endregion texts


        // tooltips
        #region tooltips
        public StringBuilder btnAdd_toolTip()
        {
            if (language == "english")
            {
                string value = "Click to add a new configurable button to your configuration.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnAll_toolTip0()
        {
            if (language == "english")
            {
                string value = "Open every drive at once, drives must be ready in order to be opened.\n\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnAll_toolTip1()
        {
            if (language == "english")
            {
                string value = "drives ready\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnAll_toolTip2()
        {
            if (language == "english")
            {
                string value = "GB total storage capacity";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder btnDelete_toolTip()
        {
            if (language == "english")
            {
                string value = "Click to enable delete state.\n" +
                    "Buttons will change color.\n" +
                    "Click on a button to delete it from your configuration.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnInfo_toolTip()
        {
            if (language == "english")
            {
                string value = "Click to open info window.\n" +
                "The info window informs you about the program version,\n" +
                " license terms and offers a manual.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnNotes_toolTip()
        {
            if (language == "english")
            {
                string value = "Click to open notes window.\n" +
                "Write down your thoughts, ideas, tasks, whatever. Make notes.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnQuit_toolTip()
        {
            if (language == "english")
            {
                string value = "Click to quit YourStartUp Application.\n" +
                "This will close the programm and all of its currently open windows.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnRename_toolTip()
        {
            if (language == "english")
            {
                string value = "Click to enable rename state.\n" +
                "Buttons will change color.\n" +
                "Click on a button to rename its displayed text.\n" +
                "Caution: there is no undo feature.\n" +
                "Double click will delete any text.\n" +
                "If you delete the text and confirm by hitting enter,\n" +
                "the result will be an empty button, use it as a spacer.\n\n" +
                "If you name your button 'www' or 'http' or 'https' you can \n" +
                "configure it as an url button if you enter reset state.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnReset_toolTip()
        {
            if (language == "english")
            {
                string value = "Click to enable reset state.\n" +
                "Buttons will change color.\n" +
                "Click on a button to reset your configuration, \n" +
                "you can alter the file binding or the url upon click.\n" +
                "Confirm url changes with enter key.\n" +
                "Double click on an url to delete it.\n" +
                "Any button whos text starts with 'http', 'https' or 'url'\n" +
                " will be considered a url button. Change file bindings by \n" +
                "clicking on any other button, upon file dialog opening choose \n" +
                "a file and confirm by clicking on Ok.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnScetchboard_toolTip()
        {
            if (language == "english")
            {
                string value = "Click to open scetchboard window.\n" +
                "Not yet implemented.\n" +
                "Once it is, it offers a mindmap and scetchboard functionality.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnSettings_toolTip()
        {
            if (language == "english")
            {
                string value = "Click to open settings window.\n" +
                "Within settings window you can change the appearence of most GUI elements to your liking.\n" +
                "You can change the colors, the font and its size, you can change button size and you can \n" +
                "set a background window. \n" +
                "You can add or hide features.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnShutdown_toolTip()
        {
            if (language == "english")
            {
                string value = "Click to shutdown your computer.\n" +
                "If you confirm the presented dialog, your computer will shut down.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnTimer_toolTip()
        {
            if (language == "english")
            {
                string value = "Click to open timer window.\n" +
                "Shows current system time.\n" +
                "Shows a stopwatch clock to indicate time passed since program start\n" +
                "logs up to 10 break intervalls.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnHideMenu_toolTip()
        {
            if (language == "english")
            {
                string value = "Click to hide menu. Click to show menu if collapsed.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder btnHideButtonMap_toolTip()
        {
            if (language == "english")
            {
                string value = "Click to hide your button configuration.\n" +
                    "Click to show your configuration if collapsed.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder btnDrive_tooltip0()
        {
            if (language == "english")
            {
                string value = "\nfree:";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder btnDrive_tooltip1()
        {
            if (language == "english")
            {
                string value = "GB Total Storage Capacity\n\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder btnDrive_tooltip2()
        {
            if (language == "english")
            {
                string value = "\n\ndrive is ready";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder btnDrive_tooltip3()
        {
            if (language == "english")
            {
                string value = " - not ready -";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }

        public StringBuilder btnDrive_tooltip4()
        {
            if (language == "english")
            {
                string value = "empty\n\n";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder empty_tooltip()
        {
            if (language == "english")
            {
                string value = "empty\nreset or rename to change blank state";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder mainWindow_tooltip()
        {
            if (language == "english")
            {
                string value = "Start up apps and files as you please.";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        public StringBuilder unset_tooltip()
        {
            if (language == "english")
            {
                string value = "path\nclick to choose a file to bind to this button";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }
        }
        #endregion tooltips

    }

}