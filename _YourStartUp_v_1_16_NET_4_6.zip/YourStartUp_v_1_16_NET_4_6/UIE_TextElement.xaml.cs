﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für UIE_TextElement.xaml
    /// </summary>
    public partial class UIE_TextElement : UserControl
    {
        private bool checkState = true;

        private bool loader = true;

        public UIE_TextElement()
        {
            InitializeComponent();
        }

        private void checkbox_Checked(object sender, RoutedEventArgs e)
        {
            //e.Handled = false;

            //if (checkState == true && loader == false)
            //{
            //    textbox.IsEnabled = true;

            //    checkState = false;
            //}
            //else if (checkState == false && loader == false)
            //{
            //    textbox.IsEnabled = false;

            //    checkState = true;
            //}

            //e.Handled = true;
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            textbox.IsEnabled = true;
            checkbox.IsChecked = true;

            checkState = true;

            loader = false;
        }
    }
}
