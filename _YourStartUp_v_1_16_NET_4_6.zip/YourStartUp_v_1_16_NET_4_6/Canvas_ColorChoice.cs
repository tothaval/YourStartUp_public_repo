﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace YourStartUp
{
    class Canvas_ColorChoice
    {
        public List<Color> colorLST = new List<Color>();

        public List<Color> colorLST_load = new List<Color>();

        Color color = Color.FromArgb(0, 0, 0, 0);

        private string absolute_path = $@"{Directory.GetCurrentDirectory()}";

        private string file = @"\files\save.colorChoice";

        string filePath;


        // constructor
        public Canvas_ColorChoice()
        {
            determineFilePath();

            createDefaults();
        }


        // publics
        public bool loadColorsFromFile()
        {
            List<string> stringList = new List<string>();

            StreamReader sr = new StreamReader(filePath);

            string line;

            while ((line = sr.ReadLine()) != null)
            {
                stringList.Add(line);
            }
            sr.Close();

            for (int i = 0; i < stringList.Count; i++)
            {
                colorLST_load.Add(colorConverter(stringList[i]).Color);
            }

            if (colorLST_load.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void saveColorsToFile(List<Color> colors)
        {
            StreamWriter sw_colorChoice = new StreamWriter(filePath, false);

            for (int i = 0; i < colors.Count; i++)
            {
                sw_colorChoice.WriteLine($"{colors[i].ToString()}");
            }

            sw_colorChoice.Close();
        }



        // privates

        private void checkExistence(string path_)
        {
            if (!Directory.Exists(path_))
            {
                Directory.CreateDirectory(path_);
            }
        }

        private SolidColorBrush colorConverter(string color)
        {
            SolidColorBrush convertedColor;
            byte a, r, g, b;

            color.Trim();

            a = byte.Parse(color.Substring(1, 2), System.Globalization.NumberStyles.HexNumber);
            r = byte.Parse(color.Substring(3, 2), System.Globalization.NumberStyles.HexNumber);
            g = byte.Parse(color.Substring(5, 2), System.Globalization.NumberStyles.HexNumber);
            b = byte.Parse(color.Substring(7, 2), System.Globalization.NumberStyles.HexNumber);

            Color argb = Color.FromArgb(a, r, g, b);
            convertedColor = new SolidColorBrush(argb);

            return convertedColor;
        }

        private void createDefaults()
        {
            checkExistence(file);

            //MessageBox.Show($"{file} fuck you pc\n{absolute_path}\n{filePath}");

            if (!File.Exists(filePath))
            {
                StreamWriter sw_config = new StreamWriter($"{filePath}", false);

                for (int i = 0; i < 28; i++)
                {
                    if (i == 0)
                    {
                        sw_config.WriteLine(Color.FromArgb(175, 0, 255, 0).ToString());
                    }
                    else if (i == 1)
                    {
                        sw_config.WriteLine(Color.FromArgb(175, 0, 0, 255).ToString());
                    }
                    else
                    {
                        sw_config.WriteLine(Color.FromArgb(175, (byte)(50 + 2 * i), 0, 0).ToString());
                    }
                }

                sw_config.Close();
            }
        }

        private void determineFilePath()
        {
            filePath = $@"{absolute_path}{file}";
        }
    }
}
