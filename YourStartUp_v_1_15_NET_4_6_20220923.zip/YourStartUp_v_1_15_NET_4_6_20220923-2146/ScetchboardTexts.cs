﻿/*  purpose: managing language elements of scetchboard window
 * 
 * written: september 2022
 * by: stephan kammel
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YourStartUp
{
    class ScetchboardTexts
    {
        public string language { get; set; }

        public ScetchboardTexts(string _language = "english")
        {
            language = _language;
        }


        // exception texts
        public StringBuilder textbox_parseFail_exception()
        {
            if (language == "english")
            {
                string value = "\nelements will be drawn with standard values (5, 50, 150, 0, 0)";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else if (language == "deutsch")
            {
                string value = "\nElemente werden mit Standardwerten(5, 50, 150) gezeichnet";

                StringBuilder sb = new StringBuilder(value);

                return sb;
            }
            else
            {
                return new StringBuilder("language selection error");
            }

        }

    }
}
