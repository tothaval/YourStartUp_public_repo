﻿/* YourStartUp UserInterfaceElement Cascade Button
 * 
 * Pur:         button class for menu buttons and alike
 * Toc:         2022 (august <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      kammel@posteo.de
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für UIE_CascadeButton.xaml
    /// </summary>
    public partial class UIE_CascadeButton : UserControl
    {
        Canvas_BasicGeometry geom = new Canvas_BasicGeometry();
        Canvas_UIConfig uic = new Canvas_UIConfig();

        private int blockCounter = 0;
        private int elliCounter = 0;
        private int lettCounter = 0;
        private int lineCounter = 0;
        private int rectCounter = 0;
        private int triCounter = 0;

        public UIE_CascadeButton()
        {
            InitializeComponent();
        }

        // publics
        public void changeIconTo_A()
        {
            clearCanvas();

            TextBlock tb = new TextBlock();

            tb.Name = $"lett{lettCounter}";
            lettCounter++;

            tb.Text = "ABC";
            tb.FontSize = 16;

            tb.TextAlignment = TextAlignment.Justify;
                        
            tb.VerticalAlignment = VerticalAlignment.Top;

            tb.MinHeight = 20;
            tb.MinWidth = 20;

            Canvas.SetLeft(tb, 5);
            Canvas.SetTop(tb, 0);
                        
            uie_cascade_button_canvas.Children.Add(tb);
        }

        public void changeIconTo_cascadingEllipses()
        {
            clearCanvas();


            Ellipse elli = geom.drawSimpleEllipse(30, 10);
            elli.Name = $"uie_cnv_elli{elliCounter}";
            elliCounter++;
            styleShape(elli);
            styleCascade(elli, 0);

            Ellipse elli1 = geom.drawSimpleEllipse(30, 10);
            elli1.Name = $"uie_cnv_elli{elliCounter}";
            elliCounter++;
            styleShape(elli1);
            styleCascade(elli1, 1);

            Ellipse elli2 = geom.drawSimpleEllipse(30, 10);
            elli2.Name = $"uie_cnv_elli{elliCounter}";
            elliCounter++;
            styleShape(elli2);
            styleCascade(elli2, 2);


            uie_cascade_button_canvas.Children.Add(elli);
            uie_cascade_button_canvas.Children.Add(elli1);
            uie_cascade_button_canvas.Children.Add(elli2);
        }

        public void changeIconTo_cascadingRectangles()
        {
            clearCanvas();


            Rectangle rect = geom.drawSimpleRectangle(30, 10);
            rect.Name = $"uie_cnv_rect{rectCounter}";
            rectCounter++;
            styleShape(rect);
            styleCascade(rect, 0);

            Rectangle rect1 = geom.drawSimpleRectangle(30, 10);
            rect1.Name = $"uie_cnv_rect{rectCounter}";
            rectCounter++;
            styleShape(rect1);
            styleCascade(rect1, 1);

            Rectangle rect2 = geom.drawSimpleRectangle(30, 10);
            rect2.Name = $"uie_cnv_rect{rectCounter}";
            rectCounter++;
            styleShape(rect2);
            styleCascade(rect2, 2);


            uie_cascade_button_canvas.Children.Add(rect);
            uie_cascade_button_canvas.Children.Add(rect1);
            uie_cascade_button_canvas.Children.Add(rect2);
        }

        public void changeIconTo_cascadingTriangles()
        {
            clearCanvas();


            Polygon tri = geom.drawSimpleTriangle_rectangular(20, 15);
            tri.Name = $"uie_cnv_tria{triCounter}";
            triCounter++;
            styleShape(tri);
            Canvas.SetLeft(tri, 7);
            Canvas.SetTop(tri, -2);
            Panel.SetZIndex(tri, 60);

            Polygon tri1 = geom.drawSimpleTriangle_rectangular(20, 15);
            tri1.Name = $"uie_cnv_tria{triCounter}";
            triCounter++;
            styleShape(tri1);
            Canvas.SetLeft(tri1, 10);
            Canvas.SetTop(tri1, 1);
            Panel.SetZIndex(tri1, 40);

            Polygon tri2 = geom.drawSimpleTriangle_rectangular(20, 15);
            tri2.Name = $"uie_cnv_tria{triCounter}";
            triCounter++;
            styleShape(tri2);
            Canvas.SetLeft(tri2, 13);
            Canvas.SetTop(tri2, 4);
            Panel.SetZIndex(tri2, 20);


            uie_cascade_button_canvas.Children.Add(tri);
            uie_cascade_button_canvas.Children.Add(tri1);
            uie_cascade_button_canvas.Children.Add(tri2);
        }

        public void changeIconTo_Line()
        {
            clearCanvas();

            Polygon line_diago = geom.drawSimpleLine(14, 14);
            line_diago.Name = $"uie_cnv_line_diago{lineCounter}";
            lineCounter++;
            styleShape(line_diago);
            Canvas.SetLeft(line_diago, 5);
            Canvas.SetTop(line_diago, 0);
            Canvas.SetZIndex(line_diago, 60);

            Polygon line_horiz = geom.drawSimpleLine(20, 0);
            line_horiz.Name = $"uie_cnv_line_horiz{lineCounter}";
            lineCounter++;
            styleShape(line_horiz);
            Canvas.SetLeft(line_horiz, 5);
            Canvas.SetTop(line_horiz, 0);
            Canvas.SetZIndex(line_horiz, 20);

            Polygon line_verti = geom.drawSimpleLine(0, 20);
            line_verti.Name = $"uie_cnv_line_verti{lineCounter}";
            lineCounter++;
            styleShape(line_verti);
            Canvas.SetLeft(line_verti, 5);
            Canvas.SetTop(line_verti, 0);
            Canvas.SetZIndex(line_verti, 40);

            uie_cascade_button_canvas.Children.Add(line_diago);
            uie_cascade_button_canvas.Children.Add(line_horiz);
            uie_cascade_button_canvas.Children.Add(line_verti);
        }

        public void changeIconTo_singularEllipse()
        {
            clearCanvas();

            Ellipse elli = geom.drawSimpleEllipse(40, 20);

            elli.Name = $"uie_cnv_elli{elliCounter}";
            elliCounter++;

            styleShape(elli);

            styleCascade(elli, -1);

            uie_cascade_button_canvas.Children.Add(elli);
        }

        public void changeIconTo_singularRectangle()
        {
            clearCanvas();

            Rectangle rect = geom.drawSimpleRectangle(40, 20);
            rect.Name = $"uie_cnv_rect{rectCounter}";
            rectCounter++;

            styleShape(rect);

            styleCascade(rect, -1);

            uie_cascade_button_canvas.Children.Add(rect);
        }
        public void changeIconTo_singularTriangle()
        {
            clearCanvas();

            Polygon tria = geom.drawSimpleTriangle_rectangular(30, 20);
            tria.Name = $"uie_cnv_tria_rec{triCounter}";
            triCounter++;
            styleShape(tria);
            Canvas.SetLeft(tria, 5);

            uie_cascade_button_canvas.Children.Add(tria);
        }

        public void changeIconTo_singularTriangle_isosceles()
        {
            clearCanvas();

            Polygon tria = geom.drawSimpleTriangle_isosceles(30, 20);
            tria.Name = $"uie_cnv_tria_iso{triCounter}";
            triCounter++;
            styleShape(tria);
            Canvas.SetLeft(tria, 5);
            Canvas.SetTop(tria, 2);

            uie_cascade_button_canvas.Children.Add(tria);
        }

        public void changeIconTo_singularTriangle_equilateral()
        {
            clearCanvas();

            Polygon tria = geom.drawSimpleTriangle_equilateral(30, 20);
            tria.Name = $"uie_cnv_tria_equ{triCounter}";
            triCounter++;
            styleShape(tria);
            Canvas.SetLeft(tria, 5);
            Canvas.SetTop(tria, 2);

            uie_cascade_button_canvas.Children.Add(tria);
        }

        public void changeIconTo_Text(string text)
        {
            clearCanvas();

            TextBlock block = new TextBlock();
            block.Name = $"uie_cnv_tria_equ{blockCounter}";
            blockCounter++;

            block.Text = text;

            block.HorizontalAlignment = HorizontalAlignment.Center;
            block.VerticalAlignment = VerticalAlignment.Center;

            block.ClipToBounds = true;

            block.Margin = new Thickness(7);
            block.Padding = new Thickness(7);

            block.Background = new SolidColorBrush(Colors.Transparent);
            block.ClipToBounds = true;

            block.TextAlignment = TextAlignment.Center;

            uie_cascade_button_canvas.Children.Add(block);
        }

        // privates
        private void clearCanvas()
        {
            blockCounter = 0;
            elliCounter = 0;
            lineCounter = 0;
            rectCounter = 0;
            triCounter = 0;

            uie_cascade_button_canvas.Children.Clear();
            uie_cascade_button_canvas.MinHeight = 20;
        }
        private void styleCascade(Shape _shape, int _factor)
        {
            if (_factor == -1)
            {
                Canvas.SetLeft(_shape, 0);
                Canvas.SetTop(_shape, 0);
                Panel.SetZIndex(_shape, 40);
            }

            if (_factor == 0)
            {
                Canvas.SetLeft(_shape, 0);
                Canvas.SetTop(_shape, 0);
                Panel.SetZIndex(_shape, 60);
            }

            if (_factor == 1)
            {
                Canvas.SetLeft(_shape, 5);
                Canvas.SetTop(_shape, 5);
                Panel.SetZIndex(_shape, 40);
            }

            if (_factor == 2)
            {
                Canvas.SetLeft(_shape, 10);
                Canvas.SetTop(_shape, 10);
                Panel.SetZIndex(_shape, 20);
            }
        }

        private void styleShape(Shape _shape)
        {
            _shape.Fill = uic.button;
            _shape.Stroke = uic.borderBrush;
            _shape.StrokeThickness = uic.borderThickness;
        }
    }
}
