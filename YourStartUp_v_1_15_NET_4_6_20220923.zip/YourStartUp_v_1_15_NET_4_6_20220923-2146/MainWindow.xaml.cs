﻿/* YourStartUp buttonmap tool  
 * 
 * Pur:         main window, collapsable main menu, collapsable button area, user can bind files and urls to buttons
 * Toc:         2022 (may <> september)
 * Dev:         Stephan Kammel
 * E-Mail:      kammel@posteo.de
 */
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Point = System.Windows.Point;

namespace YourStartUp
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // classes
        #region classes
        private Canvas_BasicGeometry cnv_geo;
        private Canvas_ColorChoice cnv_clr;
        private Canvas_GoldPaletteModule gold;
        private Canvas_PicturePaletteModule pic;
        private Canvas_PlacementAndDesignElement ppe;
        private Canvas_UIConfig uic;

        private ConfigData config;
        private MainWindowTexts texts = new MainWindowTexts();

        private Scetchboard scetchboard = new Scetchboard();
        private ScetchboardTexts scetchboardTexts = new ScetchboardTexts();

        private UIE_AlphabetElement abc;
        private UIE_CalculatorElement cal;
        private UIE_CoordinatesElement cor;
        private UIE_DiceElement dic;
        private UIE_DrivesElement dri;
        private UIE_GroupingElement gro;
        private UIE_HealthTool_BMI_Element hea;       

        private UIE_ImageElement UIE_image_element;

        private UIE_InfoElement inf;
        private UIE_LicenseElement lic;

        private UIE_MainWindowMenuElement UIE_menu_element;

        private UIE_MathElement mat;
        private UIE_MeasureElement mea;
        private UIE_NameElement nam;
        private UIE_NotesElement not;
        private UIE_OptionsElement opt;
        private UIE_PCHandlingTrainerElement pch;
        
        private UIE_ScetchboardElement UIE_scetchboard_element;        
        private UIE_SelectionBindingElement UIE_selection_binding_element;

        private UIE_TextEditorElement tee;
        private UIE_TextElement txe;

        private UIE_TimerElement UIE_timer_element;
               

        private YRS_GeometryElement geo;
        private YRS_Time_Jobs tim;
        //private YRS_ColorFeature -> wurde zu Cancas_ColorChoice
        #endregion classes

        #region  private globals
        private bool loaded = false;


        // boolian drag states
        private bool drag_image_element;
        private bool drag_menu_element;
        private bool drag_scetchboard_element;
        private bool drag_selection_binding_element;
        private bool drag_timer_element;

        private bool h_pressed = false;
        private bool s_pressed = false;

        // success of textbox parsing
        private bool parseFail = false;

        // colors
        private SolidColorBrush color1;
        private SolidColorBrush color2;

        // drawn objects dimensions, angle, z-index, cascade count and psbly text
        private double elementAngle = 0;

        private int cascadeAmount = 3;
        private int elementHeight = 100;
        private int elementWidth = 200;
        private int elementZindex = 100;

        private double x = 0;
        private double y = 0;


        // visual object lists
        private List<UIE_ImageElement> listOfImageElements =
            new List<UIE_ImageElement>();

        private List<UIE_MainWindowMenuElement> listOfMenuElements =
            new List<UIE_MainWindowMenuElement>();

        private List<UIE_ScetchboardElement> listOfScetchboardElements =
            new List<UIE_ScetchboardElement>();        
        
        private List<UIE_SelectionBindingElement> listOfSelectionBindingElements =
            new List<UIE_SelectionBindingElement>();

        private List<UIE_TimerElement> listOfTimerElements =
            new List<UIE_TimerElement>();

        // drawn object amounts
        private long drawMainWindowMenuElement = 0;
        private long drawImageElement = 0;
        private long drawScetchboardElement = 0;
        private long drawSelectionBindingElement = 0;
        private long drawTimerElement = 0;

        // coordinate points
        private Point drag_point_image_element = new Point();        
        private Point drag_point_menu_element = new Point();
        private Point drag_point_scetchboard_element = new Point();
        private Point drag_point_selection_binding_element = new Point();
        private Point drag_point_timer_element = new Point();

        // line drawing moving mouse position
        private Point scetchPoint = new Point();

        // z-indices
        private int zindex_image_element = 100;
        private int zindex_menu_element = 100;
        private int zindex_scetchboard_element = 100;
        private int zindex_selection_binding_element = 100;
        private int zindex_timer_element = 100;

        #endregion private globals

        //Drop="grdMainWindow_Drop" XAML kram
        //  PreviewDragOver="grdMainWindow_PreviewDragOver"

        // globals _public
        #region globals _public
        public int showCount = 0;

        // globals _public        
        public List<Button> btnSetList = new List<Button>();
        public List<Button> btnMenuList = new List<Button>();

        public List<Border> brdSetList = new List<Border>();
        public List<Border> brdMenuList = new List<Border>();
        #endregion globals _public


        // globals _private
        #region globals _private

        private ImageBrush image = new ImageBrush();

        private int refresh = 0; // counter (_pulse)

        private List<TextBox> txtBoxList = new List<TextBox>();
        private List<string> setList = new List<string>();
        private List<string> configList = new List<string>();
        private List<Button> btnDrvs = new List<Button>();

        private readonly System.Windows.Threading.DispatcherTimer _pulse = new System.Windows.Threading.DispatcherTimer();

        private string configuration = "+;path";

        private int _height = 0;
        private int _width = 0;
        #endregion globals _private


        // constructors
        #region constructors
        public MainWindow()
        {
            InitializeComponent();

            _pulse.Interval = TimeSpan.FromSeconds(1);
            _pulse.Tick += _pulse_Tick;
        }
        #endregion constructors


        // time methods
        #region time methods
        private void _pulse_Tick(object sender, EventArgs e)
        {
            refresh++;
            if (refresh == 2)
            {
                //    for (int i = 0; i < btnDrvs.Count; i++)
                //    {
                //        wrpDrives.Children.Clear();
                //        btnDrvs.Clear();
                //    }

                //    setupDrives();

                //    refresh = 0;

                //    config.newDriveInfo();
            }

            GC.Collect(0);
        }
        #endregion time methods

        // design
        #region design
        private void modulateMainWindow()
        {            

            double _h = config.mainWindowHeight - 30;
            double _w = config.mainWindowWidth - 30;

            MainWindowCanvas.Height = _h;
            MainWindowCanvas.Width = _w;
            border.Padding = new Thickness(4);
                       
            _height = (int)Height; _width = (int)Width;

            Background = new SolidColorBrush(Colors.Transparent);

            // button map colors
            border.Background = config.backColor;
            Foreground = config.foreColor;

            border.CornerRadius = new CornerRadius(config.borderRadius);
            border.BorderThickness = new Thickness(3);
            border.BorderBrush = config.foreColor;
            border.Background = config.backColor;

            MainWindowCanvas.Background = config.btnBackColor;

            rb_linearBrush.IsChecked = true;
        }

        private void parseTextboxes()
        {
            string message = "";

            try
            {
                cascadeAmount = Int32.Parse(tbxAmount.Text);

                elementWidth = Int32.Parse(tbxWidth.Text);
                elementHeight = Int32.Parse(tbxHeight.Text);
                
                elementZindex = Int32.Parse(tbxZindex.Text);
                elementAngle = Double.Parse(tbxAngle.Text);
                         
                x = Double.Parse(tbxX.Text);
                y = Double.Parse(tbxY.Text);

                parseFail = false;
            }
            catch (Exception e)
            {
                parseFail = true;
                message = e.Message;

                if (parseFail == true)
                {
                    MessageBox.Show($"{message}{scetchboardTexts.textbox_parseFail_exception()}");
                }
            }
        }

        // rotate element upon creation
        private void rotateShape(Shape shape)
        {
            //if (parseFail == false)
            //{
            //    RotateTransform rt = new RotateTransform();

            //    rt.CenterX = elementWidth * 0.5;
            //    rt.CenterY = elementHeight * 0.5;

            //    rt.Angle = elementAngle;

            //    shape.Height = geom.avoidNegativity(elementHeight);
            //    shape.Width = geom.avoidNegativity(elementWidth);

            //    shape.RenderTransform = rt;
            //}
            //else if (parseFail == true)
            //{
            //    shape.Width = 100;
            //    shape.Height = 50;
            //}
        }

        private void rotateUIE_TextElement(UIE_TextElement uiet)
        {
            //if (parseFail == false)
            //{
            //    RotateTransform rt = new RotateTransform();

            //    rt.CenterX = elementWidth * 0.5;
            //    rt.CenterY = elementHeight * 0.5;

            //    rt.Angle = elementAngle;

            //    uiet.Height = geom.avoidNegativity(elementHeight);
            //    uiet.Width = geom.avoidNegativity(elementWidth);

            //    uiet.RenderTransform = rt;
            //}
            //else if (parseFail == true)
            //{
            //    //uiet.Width = 100;
            //    //uiet.Height = 50;
            //}
        }


        #endregion design

        // modules
        #region module creation
        private UIE_ImageElement modul_ImageElement(ImageBrush ib_)
        {
            parseTextboxes();

            UIE_image_element = new UIE_ImageElement(elementWidth, elementHeight);

            UIE_image_element.Name = $"uimg{drawImageElement}";
            drawImageElement++;

            UIE_image_element.border.BorderBrush = config.foreColor;
            UIE_image_element.border.BorderThickness = new Thickness(3);
            UIE_image_element.border.CornerRadius = new CornerRadius(config.borderRadius);
            UIE_image_element.canvas.Background = ib_;

            //rotateUIE_TextElement(uimg);
            //determineColorScheme_UIE_TextElement(uimg);

            Canvas.SetLeft(UIE_image_element, x);
            Canvas.SetTop(UIE_image_element, y);
            Panel.SetZIndex(UIE_image_element, elementZindex);

            //if (loaded == true)
            //{
                UIE_image_element.Width = elementWidth;
                UIE_image_element.Height = elementHeight;
            //}
            //else
            //{
            //    UIE_image_element.Width = 400;
            //    UIE_image_element.Height = 200;
            //}
            
            RotateTransform rt = new RotateTransform();

            rt.CenterX = elementWidth * 0.5;
            rt.CenterY = elementHeight * 0.5;

            rt.Angle = elementAngle;

            UIE_image_element.RenderTransform = rt;

            UIE_image_element.MouseDown += UIE_image_element_MouseDown;
            UIE_image_element.MouseMove += UIE_image_element_MouseMove;
            UIE_image_element.MouseUp += UIE_image_element_MouseUp;

            listOfImageElements.Add(UIE_image_element);

            return UIE_image_element;
        }

        private UIE_MainWindowMenuElement modul_MainWindowMenuElement()
        {
            parseTextboxes();

            UIE_menu_element = new UIE_MainWindowMenuElement();

            UIE_menu_element.Name = $"uime{drawMainWindowMenuElement}";
            drawMainWindowMenuElement++;

            UIE_menu_element.generate_Menu_Module();

            Canvas.SetLeft(UIE_menu_element, x);
            Canvas.SetTop(UIE_menu_element, y);
            Panel.SetZIndex(UIE_menu_element, elementZindex);

            RotateTransform rt = new RotateTransform();

            rt.CenterX = elementWidth * 0.5;
            rt.CenterY = elementHeight * 0.5;

            rt.Angle = elementAngle;

            UIE_menu_element.RenderTransform = rt;

            UIE_menu_element.MouseDown += UIE_menu_element_MouseDown;
            UIE_menu_element.MouseMove += UIE_menu_element_MouseMove;
            UIE_menu_element.MouseUp += UIE_menu_element_MouseUp;

            listOfMenuElements.Add(UIE_menu_element);

            return UIE_menu_element;
        }

        public UIE_ScetchboardElement modul_ScetchboardElement()
        {
            parseTextboxes();

            UIE_scetchboard_element = new UIE_ScetchboardElement();

            UIE_scetchboard_element.Name = $"uisc{drawScetchboardElement}";
            drawScetchboardElement++;

            Canvas.SetLeft(UIE_scetchboard_element, x);
            Canvas.SetTop(UIE_scetchboard_element, y);
            Panel.SetZIndex(UIE_scetchboard_element, elementZindex);

            UIE_scetchboard_element.Width = elementWidth;
            UIE_scetchboard_element.Height = elementHeight;

            RotateTransform rt = new RotateTransform();

            rt.Angle = elementAngle;

            UIE_scetchboard_element.RenderTransform = rt;

            UIE_scetchboard_element.MouseDown += UIE_scetchboard_element_MouseDown;
            UIE_scetchboard_element.MouseMove += UIE_scetchboard_element_MouseMove;
            UIE_scetchboard_element.MouseUp += UIE_scetchboard_element_MouseUp;

            listOfScetchboardElements.Add(UIE_scetchboard_element);

            return UIE_scetchboard_element;
        }

        public UIE_SelectionBindingElement modul_SelectionBindingElement()
        {
            parseTextboxes();

            UIE_selection_binding_element = new UIE_SelectionBindingElement();

            UIE_selection_binding_element.Name = $"uime{drawSelectionBindingElement}";
            drawMainWindowMenuElement++;

            Canvas.SetLeft(UIE_selection_binding_element, x);
            Canvas.SetTop(UIE_selection_binding_element, y);
            Panel.SetZIndex(UIE_selection_binding_element, elementZindex);

            UIE_selection_binding_element.Width = elementWidth;
            UIE_selection_binding_element.Height = elementHeight;

            RotateTransform rt = new RotateTransform();

            if (loaded == true)
            {
                UIE_selection_binding_element.Width = elementWidth;
                UIE_selection_binding_element.Height = elementHeight;
            }
            else
            {
                UIE_selection_binding_element.Width = 400;
                UIE_selection_binding_element.Height = 200;
            }

            rt.Angle = elementAngle;

            UIE_selection_binding_element.RenderTransform = rt;

            UIE_selection_binding_element.MouseDown += UIE_selection_binding_element_MouseDown;
            UIE_selection_binding_element.MouseMove += UIE_selection_binding_element_MouseMove;
            UIE_selection_binding_element.MouseUp += UIE_selection_binding_element_MouseUp;

            listOfSelectionBindingElements.Add(UIE_selection_binding_element);

            return UIE_selection_binding_element;
        }

        public UIE_TimerElement modul_TimerElement()
        {
            parseTextboxes();

            UIE_timer_element = new UIE_TimerElement();

            UIE_timer_element.Name = $"uime{drawTimerElement}";
            drawTimerElement++;

            Canvas.SetLeft(UIE_timer_element, x);
            Canvas.SetTop(UIE_timer_element, y);
            Panel.SetZIndex(UIE_timer_element, elementZindex);

            RotateTransform rt = new RotateTransform();

            rt.CenterX = elementWidth * 0.5;
            rt.CenterY = elementHeight * 0.5;

            rt.Angle = elementAngle;

            UIE_timer_element.RenderTransform = rt;


            UIE_timer_element.MouseDown += UIE_timer_element_MouseDown;
            UIE_timer_element.MouseMove += UIE_timer_element_MouseMove;
            UIE_timer_element.MouseUp += UIE_timer_element_MouseUp;

            listOfTimerElements.Add(UIE_timer_element);

            return UIE_timer_element;
        }
        #endregion module creation


        // processing
        #region processing
        private UIE_ImageElement mainWindowCanvas_Drop_processing(UIE_ImageElement img_, int i_)
        {
            double deltax = x * i_;
            double deltay = y * i_;

            Canvas.SetLeft(img_, deltax);
            Canvas.SetTop(img_, deltay);

            Panel.SetZIndex(img_, elementZindex);

            return img_;
        }

        public void mainWindow_Shutdown_processing()
        {
            _pulse.Stop();

            config.mainWindowHeight = (int)Height;
            config.mainWindowWidth = (int)Width;

            config.saveConfig(btnSetList, setList, configList);
            config.saveSettings();

            Application.Current.Shutdown();
        }

        private LinearGradientBrush linearGradientOrientation_processing()
        {
            LinearGradientBrush Line = new LinearGradientBrush();

            if (rb_orientationBottom.IsChecked == true)
            {
                Line = new LinearGradientBrush(
                    config.backColor.Color,
                    config.foreColor.Color,
                    90);

                return Line;
            }
            else if (rb_orientationTop.IsChecked == true)
            {
                Line = new LinearGradientBrush(
                    config.foreColor.Color,
                    config.backColor.Color,
                    90);

                return Line;
            }
            else if (rb_orientationLeft.IsChecked == true)
            {
                Line = new LinearGradientBrush(
                    config.backColor.Color,
                    config.foreColor.Color,
                    0
                    );

                return Line;
            }
            else if (rb_orientationRight.IsChecked == true)
            {
                Line = new LinearGradientBrush(
                    config.foreColor.Color,
                    config.backColor.Color,
                    0
                    );

                return Line;
            }
            return Line;
        }
        #endregion processing

        private string filenameCheck(string filename_)
        {
            string filetype = "file";

            if (filename_.EndsWith("png") || filename_.EndsWith("jpg") || filename_.EndsWith("jpeg"))
            {
                filetype = "image";

                return filetype;
            }
            else if (filename_.EndsWith("wav") || filename_.EndsWith("mpeg") || filename_.EndsWith("mp3"))
            {
                filetype = "sound";

                return filetype;
            }
            else return filetype;
        }


        // events
        private void MainWindowCanvas_Drop(object sender, DragEventArgs e)
        {
            parseTextboxes();

            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = e.Data.GetData(DataFormats.FileDrop) as string[];

                for (int i = 0; i < files.Length; i++)
                {
                    string filename = System.IO.Path.GetFileName(files[i]);

                    string filepath = System.IO.Path.GetFullPath(files[i]);

                    string filetype = filenameCheck(filename);


                    if (filetype == "image" && files[i] != null && files[i].Length > 0)
                    {
                        BitmapImage theImage = new BitmapImage
                            (new Uri(filepath, UriKind.Absolute));

                        ImageBrush myImageBrush = new ImageBrush(theImage);

                        UIE_ImageElement uIE_ImageElement = modul_ImageElement(myImageBrush);

                        mainWindowCanvas_Drop_processing(uIE_ImageElement, i);

                        MainWindowCanvas.Children.Add(uIE_ImageElement);
                    }

                    else if (filetype == "file" && files[i] != null && files[i].Length > 0)
                    {
                        UIE_SelectionBindingElement uIE_sBElement = modul_SelectionBindingElement();                        

                        uIE_sBElement.SelectionBindingElement.filepath = filepath;
                        uIE_sBElement.SelectionBindingElement.filename = filename;

                        ImageSource imso = uIE_sBElement.SelectionBindingElement.GetIcon(filepath);
                        uIE_sBElement.SelectionBindingElement.imageUICtrl.Source = imso;

                        uIE_sBElement.SelectionBindingElement.tb.Text = filename;
                        uIE_sBElement.SelectionBindingElement.tb.TextAlignment = TextAlignment.Center;

                        uIE_sBElement.SelectionBindingElement.btn.ToolTip = $"{filename}";

                        MainWindowCanvas.Children.Add(uIE_sBElement);
                    }
                }
            }
        }
        private void MainWindowCanvas_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void MainWindowCanvas_KeyUp(object sender, KeyEventArgs e)
        {

        }

        private void MainWindowCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            loaded = true;


            MainWindowCanvas.Children.Add(modul_MainWindowMenuElement());

            //MainWindowCanvas.Children.Add(modul_NotesElement());

            MainWindowCanvas.Children.Add(modul_ScetchboardElement());

            MainWindowCanvas.Children.Add(modul_SelectionBindingElement());
            
            MainWindowCanvas.Children.Add(modul_TimerElement());

            modulateMainWindow();

        }



        private void MainWindowCanvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                if (s_pressed == false)
                {
                    // hier gibt es ab und an einen bug wegen irgendwas, gerade vergessen.
                    try
                    {
                        ButtonMap.DragMove();
                    }
                    catch (Exception)
                    {
                    }
                }
                else
                {
                    s_pressed_MouseDown(e);
                }

                e.Handled = true;
            }
        }

        private void MainWindowCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            s_pressed_MouseMove(e);

            e.Handled = true;
        }

        private void MainWindowCanvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                e.Handled = true;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                drag_image_element = false;
                drag_menu_element = false;
                drag_scetchboard_element = false;
                drag_selection_binding_element = false;
                drag_timer_element = false;

                e.Handled = true;
            }
        }


        private void MainWindowCanvas_PreviewDragOver(object sender, DragEventArgs e)
        {
            e.Handled = true;
        }


        // mouse ups
        #region mouse ups
        private void UIE_image_element_MouseUp(object sender, MouseButtonEventArgs e)
        {
            UIE_ImageElement uiie = (UIE_ImageElement)sender;

            if (e.ChangedButton == MouseButton.Middle)
            {
                drag_image_element = false;

                Panel.SetZIndex(uiie, zindex_image_element);
            }

            e.Handled = true;
        }
        private void UIE_menu_element_MouseUp(object sender, MouseButtonEventArgs e)
        {
            UIE_MainWindowMenuElement uime = (UIE_MainWindowMenuElement)sender;

            if (e.ChangedButton == MouseButton.Middle)
            {
                drag_menu_element = false;

                Panel.SetZIndex(uime, zindex_menu_element);
            }

            e.Handled = true;
        }
        private void UIE_scetchboard_element_MouseUp(object sender, MouseButtonEventArgs e)
        {
            UIE_ScetchboardElement uise = (UIE_ScetchboardElement)sender;

            if (e.ChangedButton == MouseButton.Middle)
            {
                drag_scetchboard_element = false;

                Panel.SetZIndex(uise, zindex_scetchboard_element);
            }

            e.Handled = true;
        }
        private void UIE_selection_binding_element_MouseUp(object sender, MouseButtonEventArgs e)
        {
            UIE_SelectionBindingElement usbe = (UIE_SelectionBindingElement)sender;

            if (e.ChangedButton == MouseButton.Middle)
            {
                drag_selection_binding_element = false;

                Panel.SetZIndex(usbe, zindex_selection_binding_element);
            }

            e.Handled = true;
        }
        private void UIE_timer_element_MouseUp(object sender, MouseButtonEventArgs e)
        {
            UIE_TimerElement uite = (UIE_TimerElement)sender;

            if (e.ChangedButton == MouseButton.Middle)
            {
                drag_timer_element = false;

                Panel.SetZIndex(uite, zindex_timer_element);
            }

            e.Handled = true;
        }
        #endregion mouse ups


        // mouse moves
        #region mouse move
        private void UIE_image_element_MouseMove(object sender, MouseEventArgs e)
        {
            UIE_ImageElement uime = sender as UIE_ImageElement;

            // if dragging, then adjust rectangle position based on mouse movement
            if (drag_image_element)
            {
                Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                double left = Canvas.GetLeft(uime);
                double top = Canvas.GetTop(uime);
                Canvas.SetLeft(uime, left + (newPoint.X - drag_point_image_element.X));
                Canvas.SetTop(uime, top + (newPoint.Y - drag_point_image_element.Y));

                drag_point_image_element = newPoint;
            }
        }

        private void UIE_menu_element_MouseMove(object sender, MouseEventArgs e)
        {
            UIE_MainWindowMenuElement uime = sender as UIE_MainWindowMenuElement;

            // if dragging, then adjust rectangle position based on mouse movement
            if (drag_menu_element)
            {
                Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                double left = Canvas.GetLeft(uime);
                double top = Canvas.GetTop(uime);
                Canvas.SetLeft(uime, left + (newPoint.X - drag_point_menu_element.X));
                Canvas.SetTop(uime, top + (newPoint.Y - drag_point_menu_element.Y));

                drag_point_menu_element = newPoint;
            }
        }

        private void UIE_scetchboard_element_MouseMove(object sender, MouseEventArgs e)
        {
            UIE_ScetchboardElement uise = sender as UIE_ScetchboardElement;

            // if dragging, then adjust rectangle position based on mouse movement
            if (drag_scetchboard_element)
            {
                Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                double left = Canvas.GetLeft(uise);
                double top = Canvas.GetTop(uise);
                Canvas.SetLeft(uise, left + (newPoint.X - drag_point_scetchboard_element.X));
                Canvas.SetTop(uise, top + (newPoint.Y - drag_point_scetchboard_element.Y));

                drag_point_scetchboard_element = newPoint;
            }
        }

        private void UIE_selection_binding_element_MouseMove(object sender, MouseEventArgs e)
        {
            UIE_SelectionBindingElement usbe = sender as UIE_SelectionBindingElement;

            // if dragging, then adjust rectangle position based on mouse movement
            if (drag_selection_binding_element)
            {
                Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                double left = Canvas.GetLeft(usbe);
                double top = Canvas.GetTop(usbe);
                Canvas.SetLeft(usbe, left + (newPoint.X - drag_point_selection_binding_element.X));
                Canvas.SetTop(usbe, top + (newPoint.Y - drag_point_selection_binding_element.Y));

                drag_point_selection_binding_element = newPoint;
            }
        }
        private void UIE_timer_element_MouseMove(object sender, MouseEventArgs e)
        {
            UIE_TimerElement uite = sender as UIE_TimerElement;

            // if dragging, then adjust rectangle position based on mouse movement
            if (drag_timer_element)
            {
                Point newPoint = Mouse.GetPosition(MainWindowCanvas);
                double left = Canvas.GetLeft(uite);
                double top = Canvas.GetTop(uite);
                Canvas.SetLeft(uite, left + (newPoint.X - drag_point_timer_element.X));
                Canvas.SetTop(uite, top + (newPoint.Y - drag_point_timer_element.Y));

                drag_point_timer_element = newPoint;
            }
        }
        #endregion mouse moves


        #region mouse downs
        // Mouse Downs
        private void UIE_image_element_MouseDown(object sender, MouseButtonEventArgs e)
        {
            UIE_ImageElement uiie = (UIE_ImageElement)sender;

            if (e.ChangedButton == MouseButton.Left)
            {
                uiie.border.Background = linearGradientOrientation_processing();
                uiie.BorderBrush = MainWindowCanvas.Background;
                //uiie.BorderThickness = 

                parseTextboxes();

                uiie.Width = elementWidth;
                uiie.Height = elementHeight;

                Canvas.SetLeft(uiie, x);
                Canvas.SetTop(uiie, y);

                Panel.SetZIndex(MainWindowCanvas, elementZindex);

                RotateTransform rt = new RotateTransform();
                rt.Angle = elementAngle;

                uiie.RenderTransform = rt;

            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                Panel.SetZIndex(uiie, 1000);

                // start dragging
                drag_image_element = true;

                // save start point of dragging
                drag_point_image_element = Mouse.GetPosition(MainWindowCanvas);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(uiie);

                GC.Collect(0);
            }

            e.Handled = true;
        }

        private void UIE_menu_element_MouseDown(object sender, MouseButtonEventArgs e)
        {
            UIE_MainWindowMenuElement uime = (UIE_MainWindowMenuElement)sender;

            if (e.ChangedButton == MouseButton.Left)
            {
                uime.border.Background = linearGradientOrientation_processing();
                uime.BorderBrush = MainWindowCanvas.Background;
                //uiie.BorderThickness = 

                parseTextboxes();

                uime.Width = elementWidth;
                uime.Height = elementHeight;

                Canvas.SetLeft(uime, x);
                Canvas.SetTop(uime, y);

                Panel.SetZIndex(MainWindowCanvas, elementZindex);

                RotateTransform rt = new RotateTransform();
                rt.Angle = elementAngle;

                uime.RenderTransform = rt;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                Panel.SetZIndex(uime, 1000);

                // start dragging
                drag_menu_element = true;

                // save start point of dragging
                drag_point_menu_element = Mouse.GetPosition(MainWindowCanvas);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(uime);

                GC.Collect(0);
            }

            e.Handled = true;
        }

        private void UIE_scetchboard_element_MouseDown(object sender, MouseButtonEventArgs e)
        {
            UIE_ScetchboardElement uise = (UIE_ScetchboardElement)sender;

            if (e.ChangedButton == MouseButton.Left)
            {
                uise.WindowBorder.Background = linearGradientOrientation_processing();
                uise.BorderBrush = MainWindowCanvas.Background;
                //uiie.BorderThickness = 

                parseTextboxes();

                uise.Width = elementWidth;
                uise.Height = elementHeight;

                Canvas.SetLeft(uise, x);
                Canvas.SetTop(uise, y);

                Panel.SetZIndex(MainWindowCanvas, elementZindex);

                RotateTransform rt = new RotateTransform();
                rt.Angle = elementAngle;

                uise.RenderTransform = rt;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                Panel.SetZIndex(uise, 1000);

                // start dragging
                drag_scetchboard_element = true;

                // save start point of dragging
                drag_point_scetchboard_element = Mouse.GetPosition(MainWindowCanvas);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(uise);

                GC.Collect(0);
            }

            e.Handled = true;
        }

        private void UIE_selection_binding_element_MouseDown(object sender, MouseButtonEventArgs e)
        {
            UIE_SelectionBindingElement usbe = (UIE_SelectionBindingElement)sender;

            if (e.ChangedButton == MouseButton.Left)
            {
                //colorSelectionMethodApplication(); // not yet in existance/ existing .
                usbe.border.Background = linearGradientOrientation_processing();
                usbe.BorderBrush = MainWindowCanvas.Background;
                //uiie.BorderThickness = 

                parseTextboxes();

                usbe.Width = elementWidth;
                usbe.Height = elementHeight;

                Canvas.SetLeft(usbe, x);
                Canvas.SetTop(usbe, y);

                Panel.SetZIndex(MainWindowCanvas, elementZindex);

                RotateTransform rt = new RotateTransform();
                rt.Angle = elementAngle;

                usbe.RenderTransform = rt;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                Panel.SetZIndex(usbe, 1000);

                // start dragging
                drag_selection_binding_element = true;

                // save start point of dragging
                drag_point_selection_binding_element = Mouse.GetPosition(MainWindowCanvas);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(usbe);

                GC.Collect(0);
            }

            e.Handled = true;
        }

        private void UIE_timer_element_MouseDown(object sender, MouseButtonEventArgs e)
        {
            UIE_TimerElement uite = (UIE_TimerElement)sender;

            if (e.ChangedButton == MouseButton.Left)
            {
                //colorSelectionMethodApplication(); // not yet in existance/ existing .
                uite.border.Background = linearGradientOrientation_processing();
                uite.BorderBrush = MainWindowCanvas.Background;
                //uiie.BorderThickness = 

                parseTextboxes();

                uite.Width = elementWidth;
                uite.Height = elementHeight;

                Canvas.SetLeft(uite, x);
                Canvas.SetTop(uite, y);

                Panel.SetZIndex(MainWindowCanvas, elementZindex);

                RotateTransform rt = new RotateTransform();
                rt.Angle = elementAngle;

                uite.RenderTransform = rt;
            }

            if (e.ChangedButton == MouseButton.Middle)
            {
                Panel.SetZIndex(uite, 1000);

                // start dragging
                drag_timer_element = true;

                // save start point of dragging
                drag_point_timer_element = Mouse.GetPosition(MainWindowCanvas);
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                MainWindowCanvas.Children.Remove(uite);

                GC.Collect(0);
            }

            e.Handled = true;
        }
        #endregion mouse downs        


        #region s_pressed
        private void s_pressed_MouseDown(MouseEventArgs _e)
        {
            if (s_pressed == false)
            {
                //parseTextboxes();

                //uiie.Width = elementWidth;
                //uiie.Height = elementHeight;

                //Canvas.SetLeft(uiie, x);
                //Canvas.SetTop(uiie, y);

                //Panel.SetZIndex(MainWindowCanvas, elementZindex);

                //RotateTransform rt = new RotateTransform();
                //rt.Angle = elementAngle;

                //uiie.RenderTransform = rt;
            }
            else if (s_pressed == true)
            {    
                if (_e.LeftButton == MouseButtonState.Pressed)
                { 
                    scetchPoint = _e.GetPosition(MainWindowCanvas);
                }
            }
        }

        // on mouse move
        private void s_pressed_MouseMove(MouseEventArgs _e)
        {
            if (_e.LeftButton == MouseButtonState.Pressed)
            {
                if (s_pressed == true)
                {
                    Line line = new Line();

                    //line.StrokeThickness = 50;
                    //line.StrokeThickness = 20;
                    line.StrokeThickness = 10;
                    //line.Stroke = config.foreColor;

                    //line.Stroke = new RadialGradientBrush(color_1, color_2);

                    if (rb_linearBrush.IsChecked == true)
                    {
                        line.Stroke = linearGradientOrientation_processing();
                    }
                    else if (rb_solidBrush.IsChecked == true)
                    {
                        line.Stroke = config.foreColor;
                    }                   

                    //else if (rb_radialBrush.IsChecked == true)
                    //{
                    //    line.Stroke = new RadialGradientBrush(config.btnBackColor.Color, config.btnForeColor.Color);
                    //}

                    //line.StrokeDashArray = new DoubleCollection() { 1, 2, 4 };

                    //line.StrokeEndLineCap = PenLineCap.Triangle;
                    line.StrokeEndLineCap = PenLineCap.Round;
                    //line.StrokeEndLineCap = PenLineCap.Square;
                    //line.StrokeEndLineCap = PenLineCap.Round;

                    line.X1 = scetchPoint.X;
                    line.Y1 = scetchPoint.Y;
                    line.X2 = _e.GetPosition(MainWindowCanvas).X;
                    line.Y2 = _e.GetPosition(MainWindowCanvas).Y;

                    //if (_e.GetPosition(MainWindowCanvas).X < 5)
                    //{
                    //    line.X2 = 5;
                    //}
                    //else if (line.X2 > MainWindowCanvas.ActualWidth - 5)
                    //{
                    //    line.X2 = _e.GetPosition(MainWindowCanvas).X;
                    //}

                    //if (_e.GetPosition(MainWindowCanvas).Y < 5)
                    //{
                    //    line.Y2 = 5;
                    //}
                    //else if (line.Y2 > MainWindowCanvas.ActualHeight - 5)
                    //{
                    //    line.Y2 = _e.GetPosition(MainWindowCanvas).Y;
                    //}

                    //line. = scetchboard._exportfunction_simulatePadding(_e.GetPosition(MainWindowCanvas), MainWindowCanvas);

                    scetchPoint = _e.GetPosition(MainWindowCanvas);

                    Panel.SetZIndex(line, 221);

                    MainWindowCanvas.Children.Add(line);
                }
            }
        }

        #endregion s_pressed


        // main window events
        #region main window events
        private void ButtonMap_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            GC.Collect();
        }
        private void ButtonMap_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.M)
            {
                MainWindowCanvas.Children.Add(modul_MainWindowMenuElement());
            }


            if (e.Key == Key.B)
            {
                if (MainWindowCanvas.Background == config.backColor)
                {
                    MainWindowCanvas.Background = config.foreColor;
                }
                else if (MainWindowCanvas.Background == config.foreColor)
                {
                    MainWindowCanvas.Background = config.backColor;
                }

                e.Handled = false;
            }

            if (e.Key == Key.H)
            {
                if (h_pressed == true)
                {
                    foreach (UIE_MainWindowMenuElement module in listOfMenuElements)
                    {
                        module.Visibility = Visibility.Hidden;
                    }
                }
                else if (h_pressed == false)
                {
                    foreach (UIE_MainWindowMenuElement module in listOfMenuElements)
                    {
                        module.Visibility = Visibility.Visible;
                    }
                }

                e.Handled = false;
            }


            if (e.Key == Key.F2)
            {
                config.saveScetchboardPictureToPNG(MainWindowCanvas);
            }

            // explosives Canvas mit zwei Sprungwerten per F3?

            if (e.Key == Key.S)
            {
                e.Handled = false;

                //if (x_pressed == true || y_pressed == true)
                //{
                //    x_pressed = false;
                //    y_pressed = false;
                //}
            }


            //if (e.Key == Key.X)
            //{
            //    //drawSimpleRectangle();
            //    e.Handled = false;

            //    if (s_pressed == true || y_pressed == true)
            //    {
            //        s_pressed = false;
            //        y_pressed = false;
            //    }
            //}


            //if (e.Key == Key.Y)
            //{
            //    //drawSimpleRectangle();
            //    e.Handled = false;

            //    if (s_pressed == true || x_pressed == true)
            //    {
            //        s_pressed = false;
            //        x_pressed = false;
            //    }
            //}


        }
        private void ButtonMap_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.B)
            {
                e.Handled = true;
            }

            if (e.Key == Key.H)
            {
                if (h_pressed == true)
                {
                    //lbl_colorFeatureVisibilityStatus.Content = "Mode: 'key h pressed ' hide color feature";

                    h_pressed = false;

                    //lbl_colorFeatureVisibilityStatus.Content = scetchboardTexts. "no key mode active";
                    lbl_colorFeatureVisibilityStatus.Content = "no key mode active";
                }
                else if (h_pressed == false)
                {

                    //lbl_colorFeatureVisibilityStatus.Content = "no key mode active";

                    h_pressed = true;

                    lbl_colorFeatureVisibilityStatus.Content = "Mode: 'key h pressed ' hide color feature";
                }

                e.Handled = true;
            }

            if (e.Key == Key.M)
            {
                e.Handled = true;
            }

            if (e.Key == Key.S)
            {
                if (s_pressed == true)
                {
                    s_pressed = false;

                    lbl_activeMode.Content = "Mode: 'key s pressed ' draw free hand scetch line";
                }
                else if (s_pressed == false)
                {
                    lbl_colorFeatureVisibilityStatus.Content = "no key mode active";

                    s_pressed = true;

                    //lbl_activeMode.Content = "Mode: 'key s pressed ' draw free hand scetch line";
                }

                e.Handled = true;
            }

            //if (e.Key == Key.X)
            //{
            //    if (x_pressed == true)
            //    {
            //        x_pressed = false;

            //        lbl_activeMode.Content = "no key mode active";
            //    }
            //    else if (x_pressed == false)
            //    {
            //        x_pressed = true;

            //        lbl_activeMode.Content = "Mode: 'key x pressed ' draw free hand rectangle shapes";
            //    }

            //    e.Handled = true;
            //}

            //if (e.Key == Key.Y)
            //{
            //    if (y_pressed == true)
            //    {
            //        y_pressed = false;

            //        lbl_activeMode.Content = "no key mode active";
            //    }
            //    else if (y_pressed == false)
            //    {
            //        y_pressed = true;

            //        lbl_activeMode.Content = "Mode: 'key y pressed ' -> draw free hand ellipse shapes";
            //    }

            //    e.Handled = true;
            //}

        }
        private void ButtonMap_Loaded(object sender, RoutedEventArgs e)
        {
            loaded = true;

            config = new ConfigData();
            config.loadConfig();

            GC.Collect(0);
        }
        private void ButtonMap_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                ButtonMap.DragMove();
            }

            if (e.ChangedButton == MouseButton.Right)
            {
                string question = texts.quitQuestion().ToString();
                string title = texts.quitTitle().ToString();

                MessageBoxResult result = MessageBox.Show(question, title, MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (result == MessageBoxResult.Yes)
                {
                    mainWindow_Shutdown_processing();
                }
            }
        }
        private void ButtonMap_MouseMove(object sender, MouseEventArgs e)
        {

        }
        private void ButtonMap_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
            }

            if (e.ChangedButton == MouseButton.Right)
            {

            }

            e.Handled = true;
        }
        #endregion main window events


        #region radiobutton events

        // on radiobuttons
        private void rb_linearBrush_Checked(object sender, RoutedEventArgs e)
        {
            if (rb_linearBrush.IsChecked == true)
            {
                rb_orientationBottom.IsEnabled = true;

                rb_orientationTop.IsEnabled = true;
                rb_orientationTop.IsChecked = true;

                rb_orientationLeft.IsEnabled = true;

                rb_orientationRight.IsEnabled = true;
            }
        }

        private void rb_solidBrush_Checked(object sender, RoutedEventArgs e)
        {
            if (rb_solidBrush.IsChecked == true)
            {
                rb_orientationBottom.IsEnabled = false;
                rb_orientationBottom.IsChecked = false;

                rb_orientationTop.IsEnabled = false;
                rb_orientationTop.IsChecked = false;

                rb_orientationLeft.IsEnabled = false;
                rb_orientationLeft.IsChecked = false;

                rb_orientationRight.IsEnabled = false;
                rb_orientationRight.IsChecked = false;
            }
        }
        #endregion radiobutton events
    }
}
/* YourStartUp buttonmap tool  
 * 
 * End of File
 */